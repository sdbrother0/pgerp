-- =====================================================================
-- Пример "Чат": команды в UI из базы через NOTIFY (V25).
--
--  * "Отправить" — сообщение сохраняется, и обработчик сам вызывает
--    ui_push_to('chat', ui_refresh_grid('chat_grid')): таблица сообщений обновляется во всех
--    вкладках, где открыт чат, — без запроса с их стороны.
--  * "Объявить всем" — ui_push(ui_message(...)): окно с объявлением во всех открытых вкладках
--    PgERP, на любой форме.
--
-- Для сравнения: в заказах тот же механизм вызывается из триггера (orders_push, V25).
-- =====================================================================

CREATE TABLE chat_messages (
    id         BIGSERIAL    PRIMARY KEY,
    author     VARCHAR(50)  NOT NULL,
    text       VARCHAR(500) NOT NULL,
    created_at TIMESTAMPTZ  NOT NULL DEFAULT now()
);

CREATE VIEW chat_messages_v AS
SELECT id, author, text, to_char(created_at, 'DD.MM HH24:MI:SS') AS sent_at
FROM chat_messages;

-- Новые сообщения — сверху
CREATE FUNCTION chat_page(p_data JSON)
RETURNS JSON AS $$
    SELECT ui_grid_page('chat_page', p_data, 'chat_messages_v', NULL, 'sent_at', 'desc');
$$ LANGUAGE sql;

CREATE FUNCTION chat_send(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_author TEXT := ui_text(p_data, 'author');
    v_text   TEXT := ui_text(p_data, 'message');
BEGIN
    PERFORM ui_require(v_author IS NOT NULL, 'Представьтесь — укажите имя');
    PERFORM ui_require(v_text IS NOT NULL, 'Напишите сообщение');

    INSERT INTO chat_messages (author, text) VALUES (left(v_author, 50), left(v_text, 500));

    -- Таблица обновится у всех, где открыт чат, в том числе у отправителя.
    -- Команда уйдёт при фиксации транзакции — когда сообщение уже видно в базе.
    PERFORM ui_push_to('chat', ui_refresh_grid('chat_grid'));

    RETURN ui_ok(ui_clear_fields('message'));
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION chat_announce(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_author TEXT := ui_text(p_data, 'author');
    v_text   TEXT := ui_text(p_data, 'message');
BEGIN
    PERFORM ui_require(v_author IS NOT NULL, 'Представьтесь — укажите имя');
    PERFORM ui_require(v_text IS NOT NULL, 'Напишите текст объявления');

    PERFORM ui_push(ui_message(format('Объявление от %s: %s', v_author, left(v_text, 500))));

    RETURN ui_ok(ui_clear_fields('message'));
END;
$$ LANGUAGE plpgsql;

INSERT INTO erp.ui_actions (action_name, function_name, description) VALUES
    ('chat_page',     'chat_page',     'Чат: сообщения, новые сверху'),
    ('chat_send',     'chat_send',     'Чат: отправить сообщение — таблица обновится у всех (ui_push_to)'),
    ('chat_announce', 'chat_announce', 'Чат: объявление во всех открытых вкладках (ui_push)');

INSERT INTO erp.grid_columns (action_name, display_order, field_name, column_title, cell_type, sort_column) VALUES
    ('chat_page', 1, 'sent_at', 'Время',     'datetime', 'id'),
    ('chat_page', 2, 'author',  'Автор',     'text',     'author'),
    ('chat_page', 3, 'text',    'Сообщение', 'text',     'text');

INSERT INTO erp.forms (form_name, title, folder)
VALUES ('chat', 'Чат', 'Примеры');

INSERT INTO erp.form_components (form_name, sort_order, component_type, component_name, label, action_event) VALUES
    ('chat', 1, 'input',  'author',       'Имя',           NULL),
    ('chat', 2, 'grid',   'chat_grid',    'Сообщения',     'chat_page'),
    ('chat', 3, 'input',  'message',      'Сообщение',     NULL),
    ('chat', 4, 'button', 'btn_send',     'Отправить',     'chat_send'),
    ('chat', 5, 'button', 'btn_announce', 'Объявить всем', 'chat_announce'),
    ('chat', 6, 'label',  'help',
        'Откройте чат в двух вкладках: сообщение сразу появится в обеих (NOTIFY). '
        '«Объявить всем» покажет окно во всех вкладках PgERP, на любой форме.', NULL);
