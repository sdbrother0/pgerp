-- =====================================================================
-- Схема ядра erp → pgerp (имя pg_erp недопустимо: префикс pg_ зарезервирован PostgreSQL).
--
-- Таблицы, представления, последовательности, внешние ключи и ссылки REGPROC (pgerp.ui_actions)
-- ссылаются на объекты по OID и переименование переживают сами. Тела функций хранятся текстом,
-- поэтому функции, где схема указана явно (erp.forms, erp.ui_ok ...), пересоздаются с pgerp.
-- search_path = public, pgerp — у базы (для новых подключений) и у маршрутизатора.
--
-- Приложение: erp.dispatcher.function-name=pgerp.handle_ui_event; Flyway получает
-- search_path = public, pgerp, erp — erp нужна миграциям V23–V26 при установке с нуля.
-- =====================================================================

ALTER SCHEMA erp RENAME TO pgerp;

DO $$
BEGIN
    EXECUTE format('ALTER DATABASE %I SET search_path = public, pgerp', current_database());
END;
$$;
SET search_path = public, pgerp;

-- Функции с явной схемой erp в теле или в search_path (маршрутизатор): пересоздаются с pgerp.
-- \m — начало слова: "pgerp." и "erp_ui" не затрагиваются.
DO $$
DECLARE
    v_function REGPROCEDURE;
    v_source   TEXT;
BEGIN
    FOR v_function IN
        SELECT p.oid
        FROM pg_proc p
        WHERE p.pronamespace IN ('public'::regnamespace, 'pgerp'::regnamespace)
          AND p.prokind = 'f'
          AND (p.prosrc ~ '\merp\.' OR array_to_string(p.proconfig, ' ') ~ '\merp\M')
    LOOP
        v_source := pg_get_functiondef(v_function);
        v_source := regexp_replace(v_source, '\merp\.', 'pgerp.', 'g');
        v_source := regexp_replace(v_source, '(SET search_path TO .*)''erp''', '\1''pgerp''');
        EXECUTE v_source;
    END LOOP;
END;
$$;

-- Проверка: ссылок на старую схему не осталось
DO $$
DECLARE
    v_left TEXT;
BEGIN
    SELECT string_agg(p.oid::REGPROCEDURE::TEXT, ', ') INTO v_left
    FROM pg_proc p
    WHERE p.pronamespace IN ('public'::regnamespace, 'pgerp'::regnamespace)
      AND (p.prosrc ~ '\merp\.' OR array_to_string(p.proconfig, ' ') ~ '\merp\M');
    IF v_left IS NOT NULL THEN
        RAISE EXCEPTION 'Остались ссылки на схему erp: %', v_left;
    END IF;
END;
$$;
