-- =====================================================================
-- Сортировка таблиц по колонкам.
-- Клиент присылает {"sort_field": "<поле колонки>", "sort_dir": "asc|desc"};
-- допустимость поля и реальная колонка сортировки берутся из метаданных.
-- =====================================================================

-- Колонка источника, по которой сортируется поле (NULL — не сортируется).
-- Нужна, когда отображаемое значение не годится для сортировки:
-- "Дата" показывается строкой DD.MM.YYYY, а сортируется по created_at.
ALTER TABLE erp_grid_columns ADD COLUMN sort_column VARCHAR(63);

UPDATE erp_grid_columns SET sort_column = CASE field_name
        WHEN 'id'         THEN 'id'
        WHEN 'order_date' THEN 'created_at'
        WHEN 'customer'   THEN 'customer_name'
        WHEN 'product'    THEN 'product_name'
        WHEN 'quantity'   THEN 'quantity'
        WHEN 'total'      THEN 'total'
        WHEN 'status'     THEN 'status'
    END
WHERE action_name = 'orders_page';


-- Колонки теперь сообщают клиенту, можно ли по ним сортировать.
CREATE OR REPLACE FUNCTION ui_grid_columns(p_action VARCHAR)
RETURNS JSON AS $$
    SELECT COALESCE(json_agg(json_build_object(
               'field', field_name,
               'title', column_title,
               'type', cell_type,
               'sortable', sort_column IS NOT NULL)
           ORDER BY display_order), '[]'::json)
    FROM erp_grid_columns
    WHERE action_name = p_action;
$$ LANGUAGE sql STABLE;


-- Проверенная сортировка: запрошенное поле, если оно сортируемое, иначе поле по умолчанию.
CREATE FUNCTION ui_grid_sort(p_action VARCHAR, p_data JSON, p_default_field VARCHAR, p_default_dir VARCHAR)
RETURNS TABLE (field VARCHAR, dir VARCHAR, sort_column VARCHAR) AS $$
    SELECT c.field_name,
           CASE WHEN lower(p_data->>'sort_dir') IN ('asc', 'desc') AND c.field_name = p_data->>'sort_field'
                THEN lower(p_data->>'sort_dir')
                ELSE p_default_dir
           END,
           c.sort_column
    FROM erp_grid_columns c
    WHERE c.action_name = p_action
      AND c.sort_column IS NOT NULL
      AND c.field_name IN (p_data->>'sort_field', p_default_field)
    -- Запрошенное поле приоритетнее поля по умолчанию
    ORDER BY c.field_name = p_data->>'sort_field' DESC NULLS LAST
    LIMIT 1;
$$ LANGUAGE sql STABLE;


CREATE OR REPLACE FUNCTION orders_page(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_limit       INT := ui_page_param(p_data, 'limit', 10, 100);
    v_page        INT := ui_page_param(p_data, 'page', 1, 1000000);
    v_sort        RECORD;
    v_total_rows  INT;
    v_total_pages INT;
    v_rows        JSON;
BEGIN
    SELECT * INTO v_sort FROM ui_grid_sort('orders_page', p_data, 'id', 'desc');

    SELECT count(*) INTO v_total_rows FROM erp_orders;

    v_total_pages := GREATEST(CEIL(v_total_rows::NUMERIC / v_limit)::INT, 1);
    v_page := LEAST(v_page, v_total_pages);

    -- Колонка сортировки взята из метаданных и экранирована %I, направление — только asc/desc.
    -- id добавлен вторым ключом, чтобы порядок строк с равными значениями был стабильным между страницами.
    EXECUTE format($sql$
        SELECT json_agg(t)
        FROM (
            SELECT id,
                   to_char(created_at, 'DD.MM.YYYY HH24:MI') AS order_date,
                   customer_name                            AS customer,
                   product_name                             AS product,
                   quantity,
                   total,
                   status
            FROM (SELECT o.*, o.quantity * o.price AS total FROM erp_orders o) o
            ORDER BY %I %s, id %s
            LIMIT $1
            OFFSET $2
        ) t
        $sql$, v_sort.sort_column, v_sort.dir, v_sort.dir)
    INTO v_rows
    USING v_limit, (v_page - 1) * v_limit;

    RETURN json_build_object(
        'status', 'success',
        'meta', json_build_object(
            'current_page', v_page,
            'limit', v_limit,
            'total_rows', v_total_rows,
            'total_pages', v_total_pages,
            'sort', json_build_object('field', v_sort.field, 'dir', v_sort.dir)),
        'columns', ui_grid_columns('orders_page'),
        'row_actions', ui_grid_row_actions('orders_page'),
        'rows', COALESCE(v_rows, '[]'::json));
END;
$$ LANGUAGE plpgsql;
