-- =====================================================================
-- Деление на ноль — ошибка ввода, как и остальные проверки: RAISE EXCEPTION,
-- клиент показывает окно ошибки.
-- =====================================================================

CREATE OR REPLACE FUNCTION division_run(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_a NUMERIC := division_parse(p_data->>'a', 'a');
    v_b NUMERIC := division_parse(p_data->>'b', 'b');
BEGIN
    IF v_b = 0 THEN
        RAISE EXCEPTION 'Деление на ноль невозможно';
    END IF;

    RETURN ui_ok(ui_set_values(jsonb_build_object(
        'result', replace(trim_scale(round(v_a / v_b, 10))::TEXT, '.', ','))));
END;
$$ LANGUAGE plpgsql;
