-- =====================================================================
-- Создание заказа — отдельная форма order_new, открываемая модально.
-- Новые инструкции UI: open_form {form, modal} и close_form.
-- =====================================================================

-- Универсальное действие "Отмена/Закрыть" для кнопок модальных форм.
CREATE FUNCTION ui_form_close(p_data JSON)
RETURNS JSON AS $$
BEGIN
    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_object('command', 'close_form'));
END;
$$ LANGUAGE plpgsql;

-- Кнопка "Новый заказ": база решает, какую форму и как открыть
-- (здесь же можно проверить права пользователя).
CREATE FUNCTION order_new_open(p_data JSON)
RETURNS JSON AS $$
BEGIN
    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_object(
            'command', 'open_form',
            'form', 'order_new',
            'modal', TRUE));
END;
$$ LANGUAGE plpgsql;

-- После создания заказа: закрыть модальное окно, обновить таблицу под ним, сообщить номер.
CREATE OR REPLACE FUNCTION order_create(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_customer VARCHAR := NULLIF(trim(p_data->>'customer_name'), '');
    v_product  VARCHAR := NULLIF(trim(p_data->>'product_name'), '');
    v_quantity VARCHAR := trim(p_data->>'quantity');
    v_price    VARCHAR := replace(replace(trim(p_data->>'price'), ' ', ''), ',', '.');
    v_id       BIGINT;
BEGIN
    IF v_customer IS NULL THEN
        RAISE EXCEPTION 'Укажите клиента';
    END IF;
    IF v_product IS NULL THEN
        RAISE EXCEPTION 'Укажите товар';
    END IF;
    IF v_quantity IS NULL OR v_quantity !~ '^[1-9]\d{0,5}$' THEN
        RAISE EXCEPTION 'Количество — целое число больше нуля';
    END IF;
    IF v_price IS NULL OR v_price !~ '^\d{1,10}(\.\d{1,2})?$' THEN
        RAISE EXCEPTION 'Цена — число, например 1500 или 99,90';
    END IF;

    INSERT INTO erp_orders (customer_name, product_name, quantity, price)
    VALUES (v_customer, v_product, v_quantity::INT, v_price::NUMERIC)
    RETURNING id INTO v_id;

    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_array(
            json_build_object('command', 'close_form'),
            json_build_object('command', 'refresh_grid', 'grid', 'orders_grid'),
            json_build_object('command', 'show_message', 'text', format('Заказ №%s создан', v_id))));
END;
$$ LANGUAGE plpgsql;

INSERT INTO erp_ui_actions (action_name, function_name, description) VALUES
    ('form_close',     'ui_form_close',  'Закрыть модальную форму'),
    ('order_new_open', 'order_new_open', 'Открыть форму нового заказа в модальном окне');

-- Модальная форма ввода заказа
INSERT INTO erp_forms (form_name, title)
VALUES ('order_new', 'Новый заказ');

INSERT INTO erp_form_components (form_name, sort_order, component_type, component_name, label, action_event) VALUES
    ('order_new', 1, 'input',  'customer_name', 'Клиент',     NULL),
    ('order_new', 2, 'input',  'product_name',  'Товар',      NULL),
    ('order_new', 3, 'input',  'quantity',      'Количество', NULL),
    ('order_new', 4, 'input',  'price',         'Цена',       NULL),
    ('order_new', 5, 'button', 'btn_create',    'Создать',    'order_create'),
    ('order_new', 6, 'button', 'btn_cancel',    'Отмена',     'form_close');

-- Форма "Заказы": только кнопка открытия и таблица
DELETE FROM erp_form_components WHERE form_name = 'orders';

INSERT INTO erp_form_components (form_name, sort_order, component_type, component_name, label, action_event) VALUES
    ('orders', 1, 'button', 'btn_new',     'Новый заказ',    'order_new_open'),
    ('orders', 2, 'grid',   'orders_grid', 'Список заказов', 'orders_page');

UPDATE erp_forms SET updated_at = now() WHERE form_name = 'orders';
