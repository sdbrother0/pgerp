-- =====================================================================
-- Вкладки в формах.
-- Компоненты с одинаковым значением tab выводятся на одной вкладке; блок вкладок
-- встаёт на место первого такого компонента. Карточка заказа: детали на вкладках.
-- =====================================================================

ALTER TABLE erp_form_components ADD COLUMN tab VARCHAR(100);

CREATE OR REPLACE FUNCTION ui_form_get(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_form_name VARCHAR := p_data->>'form';
    v_form      JSON;
BEGIN
    SELECT json_build_object(
               'name', f.form_name,
               'title', f.title,
               'components', COALESCE((
                   SELECT json_agg(json_build_object(
                              'type', c.component_type,
                              'name', c.component_name,
                              'label', c.label,
                              'action', c.action_event,
                              'master', c.master_field,
                              'tab', c.tab)
                          ORDER BY c.sort_order)
                   FROM erp_form_components c
                   WHERE c.form_name = f.form_name), '[]'::json))
    INTO v_form
    FROM erp_forms f
    WHERE f.form_name = v_form_name;

    IF v_form IS NULL THEN
        RAISE EXCEPTION 'Форма "%" не найдена', v_form_name;
    END IF;

    RETURN json_build_object('status', 'success', 'form', v_form);
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION ui_form_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_form_name  VARCHAR := p_data->>'name';
    v_title      VARCHAR := NULLIF(trim(p_data->>'title'), '');
    v_components JSON    := COALESCE(p_data->'components', '[]'::json);
    v_comp       RECORD;
BEGIN
    IF v_form_name IS NULL OR v_form_name !~ '^[a-z_][a-z0-9_]*$' THEN
        RAISE EXCEPTION 'Имя формы: латинские буквы в нижнем регистре, цифры и "_"';
    END IF;

    FOR v_comp IN
        SELECT c->>'type' AS type, c->>'name' AS name, NULLIF(c->>'action', '') AS action,
               NULLIF(c->>'master', '') AS master, n
        FROM json_array_elements(v_components) WITH ORDINALITY AS t(c, n)
    LOOP
        IF v_comp.type IS NULL OR NOT v_comp.type = ANY (ui_component_types()) THEN
            RAISE EXCEPTION 'Компонент №%: неизвестный тип "%"', v_comp.n, v_comp.type;
        END IF;
        IF v_comp.name IS NULL OR v_comp.name !~ '^[a-z_][a-z0-9_]*$' THEN
            RAISE EXCEPTION 'Компонент №%: имя — латинские буквы в нижнем регистре, цифры и "_"', v_comp.n;
        END IF;
        IF v_comp.type = 'grid' AND v_comp.action IS NULL THEN
            RAISE EXCEPTION 'Таблица "%": выберите действие-источник данных', v_comp.name;
        END IF;
        IF v_comp.type = 'lookup' AND v_comp.action IS NULL THEN
            RAISE EXCEPTION 'Поле выбора "%": выберите действие открытия списка', v_comp.name;
        END IF;
        IF v_comp.action IS NOT NULL
           AND NOT EXISTS (SELECT 1 FROM erp_ui_actions WHERE action_name = v_comp.action AND NOT is_system) THEN
            RAISE EXCEPTION 'Компонент "%": действие "%" не зарегистрировано', v_comp.name, v_comp.action;
        END IF;
        IF v_comp.type = 'grid' AND v_comp.master IS NOT NULL
           AND NOT EXISTS (SELECT 1 FROM json_array_elements(v_components) c
                           WHERE c->>'name' = v_comp.master AND c->>'type' IN ('input', 'hidden', 'lookup')) THEN
            RAISE EXCEPTION 'Таблица "%": поле-мастер "%" не найдено среди полей формы', v_comp.name, v_comp.master;
        END IF;
    END LOOP;

    IF (SELECT count(*) <> count(DISTINCT c->>'name') FROM json_array_elements(v_components) c) THEN
        RAISE EXCEPTION 'Имена компонентов должны быть уникальны';
    END IF;

    INSERT INTO erp_forms (form_name, title)
    VALUES (v_form_name, COALESCE(v_title, v_form_name))
    ON CONFLICT (form_name) DO UPDATE
        SET title = EXCLUDED.title, updated_at = now();

    DELETE FROM erp_form_components WHERE form_name = v_form_name;

    INSERT INTO erp_form_components
        (form_name, sort_order, component_type, component_name, label, action_event, master_field, tab)
    SELECT v_form_name, n, c->>'type', c->>'name', c->>'label', NULLIF(c->>'action', ''),
           CASE WHEN c->>'type' = 'grid' THEN NULLIF(c->>'master', '') END,
           CASE WHEN c->>'type' <> 'hidden' THEN NULLIF(trim(c->>'tab'), '') END
    FROM json_array_elements(v_components) WITH ORDINALITY AS t(c, n);

    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_object(
            'command', 'show_message',
            'text', format('Форма "%s" сохранена', v_form_name)));
END;
$$ LANGUAGE plpgsql;


-- Карточка заказа: кнопка и таблица каждой детали — на своей вкладке.
-- Заголовок таблицы не нужен: его роль выполняет ярлык вкладки.
UPDATE erp_form_components SET tab = 'Позиции'
WHERE form_name = 'order_new' AND component_name IN ('btn_add_line', 'order_lines_grid');

UPDATE erp_form_components SET tab = 'Оплаты'
WHERE form_name = 'order_new' AND component_name IN ('btn_add_payment', 'order_payments_grid');

UPDATE erp_form_components SET label = NULL
WHERE form_name = 'order_new' AND component_name IN ('order_lines_grid', 'order_payments_grid');

UPDATE erp_forms SET updated_at = now() WHERE form_name = 'order_new';
