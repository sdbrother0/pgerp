-- =====================================================================
-- Аутентификация и авторизация.
--
--  * Пользователи — pgerp.users: логин, пароль (bcrypt через pgcrypto), признак «сменить пароль»,
--    блокировка на 5 минут после 5 неудачных попыток входа подряд.
--    Вход проверяет pgerp.auth_login(login, password); сессию и CSRF держит Spring Security.
--  * Права: роль → формы (pgerp.role_forms). Действия, которые можно вызывать, база выводит сама:
--      - действия компонентов разрешённых форм (кнопки, источники таблиц, деревьев, списков, таймеры,
--        поля выбора), кнопки строк их таблиц и действие отмены формы;
--      - формы, которые эти действия открывают (ui_open_form('имя', ...) в коде функции), разрешаются
--        автоматически вместе с их действиями — карточки и окна выбора не нужно выдавать отдельно.
--    Роль admin — все формы и действия, включая редактор форм и меню.
--    Действия с ui_actions.everyone доступны любому вошедшему (меню, структура разрешённой формы,
--    смена пароля).
--  * Маршрутизатор получает логин от сервера: pgerp.handle_ui_event(user, action, data).
--    Пользователь отключён — ошибка U0002 (HTTP 401), нет прав — U0003 (HTTP 403).
--    Обработчики узнают пользователя через ui_user(), ui_user_id(), ui_has_role('роль').
--  * Команды из базы адресно: ui_push_to_user('логин', ...), ui_push_to_role('роль', ...).
--  * Первый вход: admin / admin, пароль нужно сменить сразу.
-- =====================================================================

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ---------------------------------------------------------------------
-- Пользователи и роли
-- ---------------------------------------------------------------------
CREATE TABLE pgerp.users (
    id                   BIGSERIAL    PRIMARY KEY,
    login                VARCHAR(50)  NOT NULL UNIQUE CHECK (login ~ '^[a-z0-9][a-z0-9_.@-]*$'),
    full_name            VARCHAR(200),
    password_hash        TEXT         NOT NULL,
    is_active            BOOLEAN      NOT NULL DEFAULT TRUE,
    must_change_password BOOLEAN      NOT NULL DEFAULT TRUE,
    failed_attempts      INT          NOT NULL DEFAULT 0,
    locked_until         TIMESTAMPTZ,
    last_login_at        TIMESTAMPTZ,
    created_at           TIMESTAMPTZ  NOT NULL DEFAULT now()
);

CREATE TABLE pgerp.roles (
    id        BIGSERIAL    PRIMARY KEY,
    role_name VARCHAR(50)  NOT NULL UNIQUE CHECK (role_name ~ '^[a-z_][a-z0-9_]*$'),
    title     VARCHAR(200) NOT NULL CHECK (trim(title) <> '')
);

CREATE TABLE pgerp.user_roles (
    id      BIGSERIAL PRIMARY KEY,
    user_id BIGINT    NOT NULL REFERENCES pgerp.users ON DELETE CASCADE,
    role_id BIGINT    NOT NULL REFERENCES pgerp.roles ON DELETE CASCADE,
    UNIQUE (user_id, role_id)
);
CREATE INDEX ON pgerp.user_roles (role_id);

CREATE TABLE pgerp.role_forms (
    id        BIGSERIAL   PRIMARY KEY,
    role_id   BIGINT      NOT NULL REFERENCES pgerp.roles ON DELETE CASCADE,
    form_name VARCHAR(50) NOT NULL REFERENCES pgerp.forms ON UPDATE CASCADE ON DELETE CASCADE,
    UNIQUE (role_id, form_name)
);
CREATE INDEX ON pgerp.role_forms (form_name);

-- Действие доступно любому вошедшему пользователю, без выдачи формы
ALTER TABLE pgerp.ui_actions ADD COLUMN everyone BOOLEAN NOT NULL DEFAULT FALSE;


-- ---------------------------------------------------------------------
-- Текущий пользователь (задаёт маршрутизатор на время транзакции)
-- ---------------------------------------------------------------------
CREATE FUNCTION pgerp.ui_user()
RETURNS VARCHAR AS $$
    SELECT NULLIF(current_setting('pgerp.user', TRUE), '');
$$ LANGUAGE sql STABLE;

CREATE FUNCTION pgerp.ui_user_id()
RETURNS BIGINT AS $$
    SELECT id FROM pgerp.users WHERE login = pgerp.ui_user();
$$ LANGUAGE sql STABLE;

CREATE FUNCTION pgerp.auth_has_role(p_user_id BIGINT, p_role VARCHAR)
RETURNS BOOLEAN AS $$
    SELECT EXISTS (
        SELECT 1 FROM pgerp.user_roles ur JOIN pgerp.roles r ON r.id = ur.role_id
        WHERE ur.user_id = p_user_id AND r.role_name = p_role);
$$ LANGUAGE sql STABLE;

-- У текущего пользователя есть роль p_role
CREATE FUNCTION pgerp.ui_has_role(p_role VARCHAR)
RETURNS BOOLEAN AS $$
    SELECT pgerp.auth_has_role(pgerp.ui_user_id(), p_role);
$$ LANGUAGE sql STABLE;

CREATE FUNCTION pgerp.auth_is_admin(p_user_id BIGINT)
RETURNS BOOLEAN AS $$
    SELECT pgerp.auth_has_role(p_user_id, 'admin');
$$ LANGUAGE sql STABLE;

-- Есть ли активный администратор — последнего нельзя отключить или лишить роли
CREATE FUNCTION pgerp.auth_admin_exists()
RETURNS BOOLEAN AS $$
    SELECT EXISTS (SELECT 1 FROM pgerp.users u WHERE u.is_active AND pgerp.auth_is_admin(u.id));
$$ LANGUAGE sql STABLE;


-- ---------------------------------------------------------------------
-- Права: роль → формы, действия выводятся из форм
-- ---------------------------------------------------------------------
-- Действия, которые вызывает форма
CREATE VIEW pgerp.form_actions AS
SELECT form_name, action_event AS action_name
FROM pgerp.form_components
WHERE action_event IS NOT NULL
UNION
SELECT c.form_name, r.row_action
FROM pgerp.form_components c
JOIN pgerp.grid_row_actions r ON r.source_action = c.action_event
WHERE c.component_type = 'grid'
UNION
SELECT form_name, cancel_action
FROM pgerp.forms
WHERE cancel_action IS NOT NULL;

-- Формы, которые открывает действие: ui_open_form('имя', ...) в коде его функции.
-- Имя формы, вычисляемое во время работы, сюда не попадает — такую форму выдают роли явно.
CREATE VIEW pgerp.action_forms AS
-- prosrc — текст каталога с правилом сортировки "C": имя приводится к обычному
SELECT DISTINCT a.action_name, m[1]::VARCHAR COLLATE "default" AS form_name
FROM pgerp.ui_actions a
JOIN pg_proc p ON p.oid = a.function_name::OID
CROSS JOIN LATERAL regexp_matches(p.prosrc, 'ui_open_form\s*\(\s*''([a-z_][a-z0-9_]*)''', 'g') AS m
WHERE EXISTS (SELECT 1 FROM pgerp.forms f WHERE f.form_name = m[1]);

-- Формы пользователя: выданные его ролям и открываемые из них, транзитивно.
-- Администратору — все. Смена пароля — всем.
CREATE FUNCTION pgerp.auth_user_forms(p_user_id BIGINT)
RETURNS SETOF VARCHAR AS $$
    WITH RECURSIVE granted(form_name) AS (
        SELECT f.form_name::VARCHAR
        FROM pgerp.forms f
        WHERE pgerp.auth_is_admin(p_user_id)
           OR f.form_name = 'password_change'
           OR EXISTS (SELECT 1
                      FROM pgerp.role_forms rf
                      JOIN pgerp.user_roles ur ON ur.role_id = rf.role_id
                      WHERE ur.user_id = p_user_id AND rf.form_name = f.form_name)
        UNION
        SELECT af.form_name
        FROM granted g
        JOIN pgerp.form_actions fa ON fa.form_name = g.form_name
        JOIN pgerp.action_forms af ON af.action_name = fa.action_name
    )
    SELECT form_name FROM granted;
$$ LANGUAGE sql STABLE;

CREATE FUNCTION pgerp.auth_form_allowed(p_user_id BIGINT, p_form VARCHAR)
RETURNS BOOLEAN AS $$
    SELECT p_form IN (SELECT pgerp.auth_user_forms(p_user_id));
$$ LANGUAGE sql STABLE;

CREATE FUNCTION pgerp.auth_action_allowed(p_user_id BIGINT, p_action VARCHAR)
RETURNS BOOLEAN AS $$
    SELECT pgerp.auth_is_admin(p_user_id)
        OR EXISTS (SELECT 1 FROM pgerp.ui_actions WHERE action_name = p_action AND everyone)
        OR EXISTS (SELECT 1
                   FROM pgerp.form_actions fa
                   WHERE fa.action_name = p_action
                     AND fa.form_name IN (SELECT pgerp.auth_user_forms(p_user_id)));
$$ LANGUAGE sql STABLE;


-- ---------------------------------------------------------------------
-- Маршрутизатор: пользователь и проверка прав
-- ---------------------------------------------------------------------
DROP FUNCTION pgerp.handle_ui_event(VARCHAR, JSON);

-- Единственная точка входа из Java. p_user — логин из сессии сервера (браузер его не задаёт).
CREATE FUNCTION pgerp.handle_ui_event(p_user VARCHAR, p_action VARCHAR, p_form_data JSON)
RETURNS JSON AS $$
DECLARE
    v_user         pgerp.users%ROWTYPE;
    v_action       pgerp.ui_actions%ROWTYPE;
    v_result       JSON;
    v_message      TEXT;
    v_instructions TEXT;
BEGIN
    SELECT * INTO v_user FROM pgerp.users WHERE login = p_user AND is_active;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Сеанс завершён — войдите снова' USING ERRCODE = 'U0002';
    END IF;
    -- До конца транзакции: обработчики, триггеры и ui_push видят пользователя через ui_user()
    PERFORM set_config('pgerp.user', v_user.login, TRUE);

    SELECT * INTO v_action FROM pgerp.ui_actions WHERE action_name = p_action;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Неизвестное действие: %', p_action;
    END IF;

    IF NOT v_action.everyone THEN
        IF v_user.must_change_password THEN
            RAISE EXCEPTION 'Смените пароль, чтобы продолжить работу' USING ERRCODE = 'U0003';
        END IF;
        IF NOT pgerp.auth_action_allowed(v_user.id, p_action) THEN
            RAISE EXCEPTION 'Нет доступа к действию «%»', COALESCE(v_action.description, p_action)
                USING ERRCODE = 'U0003';
        END IF;
    END IF;

    BEGIN
        -- regproc при выводе даёт корректно экранированное имя функции
        EXECUTE format('SELECT %s($1)', v_action.function_name) INTO v_result USING p_form_data;
    EXCEPTION WHEN SQLSTATE 'U0001' THEN
        GET STACKED DIAGNOSTICS v_message = MESSAGE_TEXT, v_instructions = PG_EXCEPTION_DETAIL;
        RETURN json_build_object(
            'status', 'error',
            'message', v_message,
            'ui_instructions', v_instructions::JSON);
    END;
    RETURN v_result;
END;
$$ LANGUAGE plpgsql
SET search_path = public, pgerp;


-- ---------------------------------------------------------------------
-- Пароли и вход
-- ---------------------------------------------------------------------
CREATE FUNCTION pgerp.auth_hash(p_password TEXT)
RETURNS TEXT AS $$
    SELECT crypt(p_password, gen_salt('bf', 10));
$$ LANGUAGE sql VOLATILE;

CREATE FUNCTION pgerp.auth_password_ok(p_password TEXT, p_hash TEXT)
RETURNS BOOLEAN AS $$
    SELECT crypt(COALESCE(p_password, ''), p_hash) = p_hash;
$$ LANGUAGE sql STABLE;

-- Требования к новому паролю
CREATE FUNCTION pgerp.auth_check_password(p_login VARCHAR, p_password TEXT)
RETURNS VOID AS $$
BEGIN
    PERFORM ui_require(length(p_password) >= 8, 'Пароль — не короче 8 символов');
    PERFORM ui_require(length(p_password) <= 72, 'Пароль — не длиннее 72 символов');
    PERFORM ui_require(lower(p_password) <> lower(p_login), 'Пароль не должен совпадать с логином');
END;
$$ LANGUAGE plpgsql;

-- Вход. Ошибка — в error_message (текст для пользователя), иначе логин и роли.
-- Неудачные попытки считаются; после 5 подряд вход закрыт на 5 минут.
CREATE FUNCTION pgerp.auth_login(p_login VARCHAR, p_password TEXT)
RETURNS TABLE (user_login VARCHAR, user_roles VARCHAR[], error_message TEXT) AS $$
DECLARE
    c_attempts CONSTANT INT      := 5;
    c_lock     CONSTANT INTERVAL := '5 minutes';
    v_user     pgerp.users%ROWTYPE;
BEGIN
    SELECT * INTO v_user FROM pgerp.users u WHERE u.login = lower(trim(p_login)) FOR UPDATE;
    IF NOT FOUND THEN
        -- Время ответа как у существующего логина: по нему нельзя подобрать логины
        PERFORM pgerp.auth_hash(COALESCE(p_password, ''));
        RETURN QUERY SELECT NULL::VARCHAR, NULL::VARCHAR[], 'Неверный логин или пароль'::TEXT;
        RETURN;
    END IF;

    IF v_user.locked_until > now() THEN
        RETURN QUERY SELECT NULL::VARCHAR, NULL::VARCHAR[],
            format('Слишком много неудачных попыток входа. Повторите через %s мин.',
                   ceil(extract(epoch FROM v_user.locked_until - now()) / 60))::TEXT;
        RETURN;
    END IF;

    IF NOT pgerp.auth_password_ok(p_password, v_user.password_hash) THEN
        UPDATE pgerp.users u
        SET failed_attempts = CASE WHEN u.failed_attempts + 1 >= c_attempts THEN 0 ELSE u.failed_attempts + 1 END,
            locked_until    = CASE WHEN u.failed_attempts + 1 >= c_attempts THEN now() + c_lock END
        WHERE u.id = v_user.id;
        RETURN QUERY SELECT NULL::VARCHAR, NULL::VARCHAR[], 'Неверный логин или пароль'::TEXT;
        RETURN;
    END IF;

    IF NOT v_user.is_active THEN
        RETURN QUERY SELECT NULL::VARCHAR, NULL::VARCHAR[],
            'Учётная запись отключена — обратитесь к администратору'::TEXT;
        RETURN;
    END IF;

    UPDATE pgerp.users u
    SET failed_attempts = 0, locked_until = NULL, last_login_at = now()
    WHERE u.id = v_user.id;

    RETURN QUERY
    SELECT v_user.login,
           ARRAY(SELECT r.role_name FROM pgerp.user_roles ur JOIN pgerp.roles r ON r.id = ur.role_id
                 WHERE ur.user_id = v_user.id ORDER BY r.role_name)::VARCHAR[],
           NULL::TEXT;
END;
$$ LANGUAGE plpgsql;


-- ---------------------------------------------------------------------
-- Инструкция logout и сеанс
-- ---------------------------------------------------------------------
-- Завершить сеанс: клиент выходит и открывает страницу входа
CREATE FUNCTION pgerp.ui_logout()
RETURNS JSONB AS $$
    SELECT pgerp.ui_instruction('logout');
$$ LANGUAGE sql STABLE;

-- Действие session_get: кто вошёл — для шапки и обязательной смены пароля
CREATE FUNCTION pgerp.ui_session_get(p_data JSON)
RETURNS JSON AS $$
    SELECT json_build_object(
        'status', 'success',
        'user', json_build_object(
            'login', u.login,
            'full_name', u.full_name,
            'roles', ARRAY(SELECT r.role_name FROM pgerp.user_roles ur JOIN pgerp.roles r ON r.id = ur.role_id
                           WHERE ur.user_id = u.id ORDER BY r.role_name),
            'is_admin', pgerp.auth_is_admin(u.id),
            'must_change_password', u.must_change_password))
    FROM pgerp.users u
    WHERE u.id = pgerp.ui_user_id();
$$ LANGUAGE sql STABLE;

-- Действие form_get: структура формы, если она доступна пользователю.
-- Без пользователя (вызов из консоли базы) — без ограничений.
CREATE FUNCTION pgerp.ui_form_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_form    VARCHAR := p_data->>'form';
    v_user_id BIGINT  := pgerp.ui_user_id();
    v_title   VARCHAR;
BEGIN
    IF v_user_id IS NOT NULL THEN
        IF (SELECT must_change_password FROM pgerp.users WHERE id = v_user_id) THEN
            IF v_form IS DISTINCT FROM 'password_change' THEN
                RAISE EXCEPTION 'Смените пароль, чтобы продолжить работу' USING ERRCODE = 'U0003';
            END IF;
        ELSIF NOT pgerp.auth_form_allowed(v_user_id, v_form) THEN
            SELECT title INTO v_title FROM pgerp.forms WHERE form_name = v_form;
            RAISE EXCEPTION 'Нет доступа к форме «%»', COALESCE(v_title, v_form) USING ERRCODE = 'U0003';
        END IF;
    END IF;
    RETURN pgerp.ui_form_get(p_data);
END;
$$ LANGUAGE plpgsql;

UPDATE pgerp.ui_actions SET function_name = 'pgerp.ui_form_open'::REGPROC, everyone = TRUE
WHERE action_name = 'form_get';


-- ---------------------------------------------------------------------
-- Меню: только доступные формы
-- ---------------------------------------------------------------------
-- p_forms — формы, которые показываются (NULL — все). Пункт с недоступной формой остаётся группой, если
-- в нём есть доступные подпункты; пустые группы скрываются.
CREATE FUNCTION pgerp.ui_menu_level(p_parent BIGINT, p_forms VARCHAR[])
RETURNS JSON AS $$
BEGIN
    RETURN COALESCE((
        SELECT json_agg(json_build_object('id', t.id, 'title', t.title, 'form', t.form, 'items', t.items)
                        ORDER BY t.sort_order, t.id)
        FROM (
            SELECT m.id, m.title, m.sort_order,
                   CASE WHEN p_forms IS NULL OR m.form_name = ANY (p_forms) THEN m.form_name END AS form,
                   pgerp.ui_menu_level(m.id, p_forms) AS items
            FROM pgerp.menu_items m
            WHERE m.parent_id IS NOT DISTINCT FROM p_parent
        ) t
        WHERE p_forms IS NULL OR t.form IS NOT NULL OR json_array_length(t.items) > 0), '[]'::json);
END;
$$ LANGUAGE plpgsql STABLE;

-- В меню — формы, выданные ролям пользователя напрямую; карточки и окна выбора, доступные
-- через них, в меню не попадают
CREATE OR REPLACE FUNCTION pgerp.ui_menu_get(p_data JSON)
RETURNS JSON AS $$
    SELECT json_build_object('status', 'success', 'items', pgerp.ui_menu_level(NULL,
        CASE WHEN pgerp.ui_user_id() IS NULL OR pgerp.auth_is_admin(pgerp.ui_user_id()) THEN NULL
             ELSE ARRAY(SELECT rf.form_name
                        FROM pgerp.role_forms rf
                        JOIN pgerp.user_roles ur ON ur.role_id = rf.role_id
                        WHERE ur.user_id = pgerp.ui_user_id())::VARCHAR[] END));
$$ LANGUAGE sql STABLE;

DROP FUNCTION pgerp.ui_menu_level(BIGINT);

UPDATE pgerp.ui_actions SET everyone = TRUE WHERE action_name = 'menu_get';


-- ---------------------------------------------------------------------
-- Команды из базы: адресная отправка
-- ---------------------------------------------------------------------
-- Сообщение {"form", "ui_instructions", "users"?}: users — логины адресатов, без него — всем.
-- Пустой список адресатов — ничего не отправляется.
CREATE FUNCTION pgerp.ui_push_send(p_form VARCHAR, p_users VARCHAR[], p_instructions JSONB[])
RETURNS VOID AS $$
DECLARE
    v_message TEXT;
BEGIN
    IF p_users IS NOT NULL AND cardinality(p_users) = 0 THEN
        RETURN;
    END IF;
    v_message := (jsonb_build_object(
        'form', p_form,
        'ui_instructions', pgerp.ui_ok(VARIADIC p_instructions)->'ui_instructions')
        || CASE WHEN p_users IS NOT NULL THEN jsonb_build_object('users', p_users) ELSE '{}' END)::TEXT;
    IF octet_length(v_message) > 7900 THEN
        RAISE EXCEPTION 'ui_push: сообщение длиннее 8000 байт — передайте в нём меньше данных';
    END IF;
    PERFORM pg_notify('erp_ui', v_message);
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION pgerp.ui_push_to(p_form VARCHAR, VARIADIC p_instructions JSONB[])
RETURNS VOID AS $$
    SELECT pgerp.ui_push_send(p_form, NULL, p_instructions);
$$ LANGUAGE sql;

-- Во вкладки пользователя с логином p_user
CREATE FUNCTION pgerp.ui_push_to_user(p_user VARCHAR, VARIADIC p_instructions JSONB[])
RETURNS VOID AS $$
    SELECT pgerp.ui_push_send(NULL, ARRAY[lower(p_user)]::VARCHAR[], p_instructions);
$$ LANGUAGE sql;

-- Во вкладки активных пользователей с ролью p_role
CREATE FUNCTION pgerp.ui_push_to_role(p_role VARCHAR, VARIADIC p_instructions JSONB[])
RETURNS VOID AS $$
    SELECT pgerp.ui_push_send(NULL, ARRAY(
        SELECT u.login FROM pgerp.users u
        WHERE u.is_active AND pgerp.auth_has_role(u.id, p_role))::VARCHAR[], p_instructions);
$$ LANGUAGE sql;


-- ---------------------------------------------------------------------
-- Смена пароля
-- ---------------------------------------------------------------------
CREATE FUNCTION pgerp.ui_password_change(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_user   pgerp.users%ROWTYPE;
    v_old    TEXT := p_data->>'old_password';
    v_new    TEXT := p_data->>'new_password';
    v_repeat TEXT := p_data->>'new_password_repeat';
BEGIN
    SELECT * INTO v_user FROM pgerp.users WHERE id = pgerp.ui_user_id() FOR UPDATE;
    PERFORM ui_require(FOUND, 'Пользователь не найден');
    PERFORM ui_require(pgerp.auth_password_ok(v_old, v_user.password_hash), 'Текущий пароль указан неверно');
    PERFORM ui_require(v_new = v_repeat, 'Новый пароль и повтор не совпадают');
    PERFORM pgerp.auth_check_password(v_user.login, v_new);
    PERFORM ui_require(v_new <> v_old, 'Новый пароль должен отличаться от текущего');

    UPDATE pgerp.users
    SET password_hash = pgerp.auth_hash(v_new), must_change_password = FALSE
    WHERE id = v_user.id;

    RETURN ui_ok(ui_close_form(), ui_message('Пароль изменён'));
END;
$$ LANGUAGE plpgsql;

-- Отмена: при обязательной смене пароля — выход, иначе закрыть окно
CREATE FUNCTION pgerp.ui_password_change_cancel(p_data JSON)
RETURNS JSON AS $$
    SELECT CASE WHEN (SELECT must_change_password FROM pgerp.users WHERE id = pgerp.ui_user_id())
                THEN ui_ok(pgerp.ui_logout())
                ELSE ui_ok(ui_close_form()) END;
$$ LANGUAGE sql STABLE;


-- ---------------------------------------------------------------------
-- Администрирование: пользователи
-- ---------------------------------------------------------------------
CREATE VIEW pgerp.users_v AS
SELECT u.id, u.login, u.full_name,
       (SELECT string_agg(r.title, ', ' ORDER BY r.title)
        FROM pgerp.user_roles ur JOIN pgerp.roles r ON r.id = ur.role_id
        WHERE ur.user_id = u.id) AS roles,
       CASE WHEN NOT u.is_active          THEN 'Отключён'
            WHEN u.locked_until > now()   THEN 'Вход заблокирован'
            WHEN u.must_change_password   THEN 'Должен сменить пароль'
            ELSE 'Активен' END AS status,
       to_char(u.last_login_at, 'DD.MM.YYYY HH24:MI') AS last_login,
       u.last_login_at
FROM pgerp.users u;

CREATE VIEW pgerp.user_roles_v AS
SELECT ur.id, ur.user_id, r.role_name, r.title
FROM pgerp.user_roles ur
JOIN pgerp.roles r ON r.id = ur.role_id;

CREATE FUNCTION pgerp.users_page(p_data JSON)
RETURNS JSON AS $$
    SELECT ui_grid_page('users_page', p_data, 'pgerp.users_v', NULL, 'login', 'asc',
                        'login', p_data->>'user_filter');
$$ LANGUAGE sql;

CREATE FUNCTION pgerp.user_roles_page(p_data JSON)
RETURNS JSON AS $$
    SELECT ui_grid_page('user_roles_page', p_data, 'pgerp.user_roles_v', 'user_id', 'title', 'asc');
$$ LANGUAGE sql;

CREATE FUNCTION pgerp.user_states_combo(p_data JSON)
RETURNS JSON AS $$
    SELECT json_build_object('status', 'success', 'items', json_build_array(
        json_build_object('id', 'active',   'label', 'Активен'),
        json_build_object('id', 'disabled', 'label', 'Отключён')));
$$ LANGUAGE sql IMMUTABLE;

CREATE FUNCTION pgerp.roles_combo(p_data JSON)
RETURNS JSON AS $$
    SELECT ui_combo_items('pgerp.roles', 'title');
$$ LANGUAGE sql STABLE;

CREATE FUNCTION pgerp.user_new_open(p_data JSON)
RETURNS JSON AS $$
    SELECT ui_ok(ui_open_form('user', p_title => 'Новый пользователь',
                              p_data => jsonb_build_object('state', 'active')));
$$ LANGUAGE sql;

CREATE FUNCTION pgerp.user_edit_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_user pgerp.users%ROWTYPE;
BEGIN
    SELECT * INTO v_user FROM pgerp.users WHERE id = ui_parse_id(p_data->>'id');
    PERFORM ui_require(FOUND, 'Пользователь не найден — возможно, он удалён');

    RETURN ui_ok(ui_open_form('user',
        p_title => v_user.login,
        p_data  => jsonb_build_object(
            'id', v_user.id::TEXT,
            'login', v_user.login,
            'full_name', COALESCE(v_user.full_name, ''),
            'state', CASE WHEN v_user.is_active THEN 'active' ELSE 'disabled' END)));
END;
$$ LANGUAGE plpgsql;

-- Новый пароль задаёт администратор — пользователь сменит его при входе.
-- Новый пользователь остаётся в карточке: на вкладке «Роли» ему назначают роли.
CREATE FUNCTION pgerp.user_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_id        BIGINT  := ui_parse_id(p_data->>'id');
    v_login     VARCHAR := lower(ui_text(p_data, 'login'));
    v_full_name VARCHAR := ui_text(p_data, 'full_name');
    v_state     VARCHAR := ui_text(p_data, 'state');
    v_password  TEXT    := NULLIF(p_data->>'password', '');
BEGIN
    PERFORM ui_require(v_login ~ '^[a-z0-9][a-z0-9_.@-]*$',
                       'Логин: латинские буквы, цифры и символы _ . @ -, начинается с буквы или цифры');
    PERFORM ui_require(length(v_login) <= 50, 'Логин — не длиннее 50 символов');
    PERFORM ui_require(v_state IN ('active', 'disabled'), 'Выберите состояние учётной записи');
    PERFORM ui_require(
        NOT EXISTS (SELECT 1 FROM pgerp.users WHERE login = v_login AND id IS DISTINCT FROM v_id),
        format('Логин «%s» уже занят', v_login));
    IF v_password IS NOT NULL THEN
        PERFORM pgerp.auth_check_password(v_login, v_password);
    END IF;

    IF ui_is_new(p_data) THEN
        PERFORM ui_require(v_password IS NOT NULL, 'Задайте пароль — пользователь сменит его при первом входе');
        INSERT INTO pgerp.users (login, full_name, password_hash, is_active)
        VALUES (v_login, v_full_name, pgerp.auth_hash(v_password), v_state = 'active')
        RETURNING id INTO v_id;

        RETURN ui_ok(
            ui_set_values(jsonb_build_object('id', v_id::TEXT, 'password', '')),
            ui_set_title(v_login),
            ui_refresh_grid('user_roles_grid'),
            ui_refresh_grid('users_grid', p_keep_page => TRUE),
            ui_message('Пользователь создан. Назначьте ему роли на вкладке «Роли»'));
    END IF;

    PERFORM ui_require(v_state = 'active' OR v_id IS DISTINCT FROM pgerp.ui_user_id(),
                       'Нельзя отключить свою учётную запись');
    UPDATE pgerp.users
    SET login     = v_login,
        full_name = v_full_name,
        is_active = v_state = 'active',
        -- Включение снимает и блокировку после неудачных попыток входа
        failed_attempts = CASE WHEN v_state = 'active' THEN 0 ELSE failed_attempts END,
        locked_until    = CASE WHEN v_state = 'active' THEN NULL ELSE locked_until END,
        password_hash        = COALESCE(pgerp.auth_hash(v_password), password_hash),
        must_change_password = must_change_password OR v_password IS NOT NULL
    WHERE id = v_id;
    PERFORM ui_require(FOUND, 'Пользователь не найден — возможно, он удалён');
    PERFORM ui_require(pgerp.auth_admin_exists(), 'Должен остаться хотя бы один активный администратор');

    RETURN ui_ok(ui_close_form(), ui_refresh_grid('users_grid', p_keep_page => TRUE));
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION pgerp.user_role_add(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_user_id BIGINT := ui_parse_id(p_data->>'id');
    v_role_id BIGINT := ui_parse_id(p_data->>'role_to_add');
BEGIN
    PERFORM ui_require(v_user_id IS NOT NULL, 'Сначала сохраните пользователя');
    PERFORM ui_require(v_role_id IS NOT NULL, 'Выберите роль');
    INSERT INTO pgerp.user_roles (user_id, role_id) VALUES (v_user_id, v_role_id)
    ON CONFLICT (user_id, role_id) DO NOTHING;

    RETURN ui_ok(
        ui_set_values(jsonb_build_object('role_to_add', '')),
        ui_refresh_grid('user_roles_grid'),
        ui_refresh_grid('users_grid', p_keep_page => TRUE));
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION pgerp.user_role_remove(p_data JSON)
RETURNS JSON AS $$
BEGIN
    DELETE FROM pgerp.user_roles WHERE id = ui_parse_id(p_data->>'id');
    PERFORM ui_require(pgerp.auth_admin_exists(), 'Должен остаться хотя бы один активный администратор');

    RETURN ui_ok(
        ui_refresh_grid('user_roles_grid', p_keep_page => TRUE),
        ui_refresh_grid('users_grid', p_keep_page => TRUE));
END;
$$ LANGUAGE plpgsql;


-- ---------------------------------------------------------------------
-- Администрирование: роли
-- ---------------------------------------------------------------------
CREATE VIEW pgerp.roles_v AS
SELECT r.id, r.role_name, r.title,
       (SELECT count(*) FROM pgerp.user_roles ur WHERE ur.role_id = r.id) AS users_count,
       CASE WHEN r.role_name = 'admin' THEN 'Все формы'
            ELSE (SELECT string_agg(f.title, ', ' ORDER BY f.title)
                  FROM pgerp.role_forms rf JOIN pgerp.forms f ON f.form_name = rf.form_name
                  WHERE rf.role_id = r.id) END AS forms
FROM pgerp.roles r;

CREATE VIEW pgerp.role_forms_v AS
SELECT rf.id, rf.role_id, rf.form_name, f.title, f.folder
FROM pgerp.role_forms rf
JOIN pgerp.forms f ON f.form_name = rf.form_name;

-- Формы для выбора: "Папка / Заголовок"
CREATE VIEW pgerp.forms_combo_v AS
SELECT form_name, concat_ws(' / ', folder, title) AS label
FROM pgerp.forms;

CREATE FUNCTION pgerp.roles_page(p_data JSON)
RETURNS JSON AS $$
    SELECT ui_grid_page('roles_page', p_data, 'pgerp.roles_v', NULL, 'title', 'asc');
$$ LANGUAGE sql;

CREATE FUNCTION pgerp.role_forms_page(p_data JSON)
RETURNS JSON AS $$
    SELECT ui_grid_page('role_forms_page', p_data, 'pgerp.role_forms_v', 'role_id', 'title', 'asc');
$$ LANGUAGE sql;

CREATE FUNCTION pgerp.forms_combo(p_data JSON)
RETURNS JSON AS $$
    SELECT ui_combo_items('pgerp.forms_combo_v', 'label', 'form_name');
$$ LANGUAGE sql STABLE;

CREATE FUNCTION pgerp.role_new_open(p_data JSON)
RETURNS JSON AS $$
    SELECT ui_ok(ui_open_form('role', p_title => 'Новая роль'));
$$ LANGUAGE sql;

CREATE FUNCTION pgerp.role_edit_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_role pgerp.roles%ROWTYPE;
BEGIN
    SELECT * INTO v_role FROM pgerp.roles WHERE id = ui_parse_id(p_data->>'id');
    PERFORM ui_require(FOUND, 'Роль не найдена — возможно, она удалена');

    RETURN ui_ok(ui_open_form('role',
        p_title => v_role.title,
        p_data  => jsonb_build_object(
            'id', v_role.id::TEXT,
            'role_name', v_role.role_name,
            'title', v_role.title)));
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION pgerp.role_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_id        BIGINT  := ui_parse_id(p_data->>'id');
    v_role_name VARCHAR := lower(ui_text(p_data, 'role_name'));
    v_title     VARCHAR := ui_text(p_data, 'title');
BEGIN
    PERFORM ui_require(v_role_name ~ '^[a-z_][a-z0-9_]*$',
                       'Код роли: латинские буквы в нижнем регистре, цифры и "_"');
    PERFORM ui_require(v_title IS NOT NULL, 'Укажите название роли');
    PERFORM ui_require(
        NOT EXISTS (SELECT 1 FROM pgerp.roles WHERE role_name = v_role_name AND id IS DISTINCT FROM v_id),
        format('Роль с кодом «%s» уже есть', v_role_name));

    IF ui_is_new(p_data) THEN
        INSERT INTO pgerp.roles (role_name, title) VALUES (v_role_name, v_title)
        RETURNING id INTO v_id;

        RETURN ui_ok(
            ui_set_values(jsonb_build_object('id', v_id::TEXT)),
            ui_set_title(v_title),
            ui_refresh_grid('role_forms_grid'),
            ui_refresh_grid('roles_grid', p_keep_page => TRUE),
            ui_message('Роль создана. Добавьте формы, к которым она даёт доступ'));
    END IF;

    PERFORM ui_require(
        NOT EXISTS (SELECT 1 FROM pgerp.roles WHERE id = v_id AND role_name = 'admin' AND v_role_name <> 'admin'),
        'Код роли администратора менять нельзя');
    UPDATE pgerp.roles SET role_name = v_role_name, title = v_title WHERE id = v_id;
    PERFORM ui_require(FOUND, 'Роль не найдена — возможно, она удалена');

    RETURN ui_ok(ui_close_form(), ui_refresh_grid('roles_grid', p_keep_page => TRUE));
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION pgerp.role_delete(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_role pgerp.roles%ROWTYPE;
BEGIN
    SELECT * INTO v_role FROM pgerp.roles WHERE id = ui_parse_id(p_data->>'id');
    PERFORM ui_require(FOUND, 'Роль не найдена — возможно, она удалена');
    PERFORM ui_require(v_role.role_name <> 'admin', 'Роль администратора удалить нельзя');

    IF NOT ui_confirmed(p_data) THEN
        RETURN ui_ok(ui_confirm(
            format('Удалить роль «%s»? Её пользователи потеряют доступ к её формам.', v_role.title),
            'role_delete', jsonb_build_object('id', v_role.id, 'confirmed', TRUE),
            p_confirm_label => 'Удалить'));
    END IF;

    DELETE FROM pgerp.roles WHERE id = v_role.id;
    RETURN ui_ok(ui_refresh_grid('roles_grid', p_keep_page => TRUE),
                 ui_refresh_grid('users_grid', p_keep_page => TRUE));
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION pgerp.role_form_add(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_role_id BIGINT  := ui_parse_id(p_data->>'id');
    v_form    VARCHAR := ui_text(p_data, 'form_to_add');
BEGIN
    PERFORM ui_require(v_role_id IS NOT NULL, 'Сначала сохраните роль');
    PERFORM ui_require(v_form IS NOT NULL, 'Выберите форму');
    PERFORM ui_require(
        NOT EXISTS (SELECT 1 FROM pgerp.roles WHERE id = v_role_id AND role_name = 'admin'),
        'Администратору доступны все формы');
    INSERT INTO pgerp.role_forms (role_id, form_name) VALUES (v_role_id, v_form)
    ON CONFLICT (role_id, form_name) DO NOTHING;

    RETURN ui_ok(
        ui_set_values(jsonb_build_object('form_to_add', '')),
        ui_refresh_grid('role_forms_grid'),
        ui_refresh_grid('roles_grid', p_keep_page => TRUE));
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION pgerp.role_form_remove(p_data JSON)
RETURNS JSON AS $$
BEGIN
    DELETE FROM pgerp.role_forms WHERE id = ui_parse_id(p_data->>'id');
    RETURN ui_ok(
        ui_refresh_grid('role_forms_grid', p_keep_page => TRUE),
        ui_refresh_grid('roles_grid', p_keep_page => TRUE));
END;
$$ LANGUAGE plpgsql;


-- ---------------------------------------------------------------------
-- Метаданные
-- ---------------------------------------------------------------------
INSERT INTO pgerp.ui_actions (action_name, function_name, description, is_system, everyone) VALUES
    ('session_get',            'pgerp.ui_session_get',            'Текущий пользователь',               TRUE,  TRUE),
    ('password_change',        'pgerp.ui_password_change',        'Смена своего пароля',                FALSE, TRUE),
    ('password_change_cancel', 'pgerp.ui_password_change_cancel', 'Отмена смены пароля',                FALSE, TRUE),
    ('users_page',             'pgerp.users_page',                'Таблица: пользователи',              FALSE, FALSE),
    ('user_roles_page',        'pgerp.user_roles_page',           'Таблица: роли пользователя',         FALSE, FALSE),
    ('user_states_combo',      'pgerp.user_states_combo',         'Список: состояния учётной записи',   FALSE, FALSE),
    ('roles_combo',            'pgerp.roles_combo',               'Список: роли',                       FALSE, FALSE),
    ('user_new_open',          'pgerp.user_new_open',             'Новый пользователь',                 FALSE, FALSE),
    ('user_edit_open',         'pgerp.user_edit_open',            'Карточка пользователя',              FALSE, FALSE),
    ('user_save',              'pgerp.user_save',                 'Сохранение пользователя',            FALSE, FALSE),
    ('user_role_add',          'pgerp.user_role_add',             'Назначение роли пользователю',       FALSE, FALSE),
    ('user_role_remove',       'pgerp.user_role_remove',          'Снятие роли с пользователя',         FALSE, FALSE),
    ('roles_page',             'pgerp.roles_page',                'Таблица: роли',                      FALSE, FALSE),
    ('role_forms_page',        'pgerp.role_forms_page',           'Таблица: формы роли',                FALSE, FALSE),
    ('forms_combo',            'pgerp.forms_combo',               'Список: формы',                      FALSE, FALSE),
    ('role_new_open',          'pgerp.role_new_open',             'Новая роль',                         FALSE, FALSE),
    ('role_edit_open',         'pgerp.role_edit_open',            'Карточка роли',                      FALSE, FALSE),
    ('role_save',              'pgerp.role_save',                 'Сохранение роли',                    FALSE, FALSE),
    ('role_delete',            'pgerp.role_delete',               'Удаление роли',                      FALSE, FALSE),
    ('role_form_add',          'pgerp.role_form_add',             'Добавление формы в роль',            FALSE, FALSE),
    ('role_form_remove',       'pgerp.role_form_remove',          'Удаление формы из роли',             FALSE, FALSE);

INSERT INTO pgerp.grid_columns (action_name, display_order, field_name, column_title, cell_type, sort_column) VALUES
    ('users_page',      1, 'login',       'Логин',          'text',   'login'),
    ('users_page',      2, 'full_name',   'Имя',            'text',   'full_name'),
    ('users_page',      3, 'roles',       'Роли',           'text',   NULL),
    ('users_page',      4, 'status',      'Состояние',      'text',   'status'),
    ('users_page',      5, 'last_login',  'Последний вход', 'text',   'last_login_at'),
    ('user_roles_page', 1, 'title',       'Роль',           'text',   'title'),
    ('user_roles_page', 2, 'role_name',   'Код',            'text',   'role_name'),
    ('roles_page',      1, 'title',       'Название',       'text',   'title'),
    ('roles_page',      2, 'role_name',   'Код',            'text',   'role_name'),
    ('roles_page',      3, 'users_count', 'Пользователей',  'number', 'users_count'),
    ('roles_page',      4, 'forms',       'Формы',          'text',   NULL),
    ('role_forms_page', 1, 'title',       'Форма',          'text',   'title'),
    ('role_forms_page', 2, 'folder',      'Папка',          'text',   'folder');

INSERT INTO pgerp.grid_row_actions (source_action, sort_order, row_action, label, style) VALUES
    ('users_page',      1, 'user_edit_open',   'Изменить', 'default'),
    ('user_roles_page', 1, 'user_role_remove', 'Убрать',   'danger'),
    ('roles_page',      1, 'role_edit_open',   'Изменить', 'default'),
    ('roles_page',      2, 'role_delete',      'Удалить',  'danger'),
    ('role_forms_page', 1, 'role_form_remove', 'Убрать',   'danger');

INSERT INTO pgerp.forms (form_name, title, folder, cancel_action) VALUES
    ('users',           'Пользователи',  'Администрирование', NULL),
    ('user',            'Пользователь',  'Администрирование', NULL),
    ('roles',           'Роли',          'Администрирование', NULL),
    ('role',            'Роль',          'Администрирование', NULL),
    ('password_change', 'Смена пароля',  'Администрирование', 'password_change_cancel');

INSERT INTO pgerp.form_components
    (form_name, sort_order, component_type, component_name, label, action_event, master_field, tab, options) VALUES
    ('users', 1, 'input',  'user_filter',  'Логин',              NULL,            NULL, NULL, '{"refresh": "users_grid"}'),
    ('users', 2, 'button', 'btn_user_new', 'Новый пользователь', 'user_new_open', NULL, NULL, NULL),
    ('users', 3, 'grid',   'users_grid',   'Пользователи',       'users_page',    NULL, NULL, NULL),

    ('user',  1, 'hidden',   'id',              NULL,                             NULL,                NULL, NULL,             NULL),
    ('user',  2, 'input',    'login',           'Логин',                          NULL,                NULL, 'Учётная запись', NULL),
    ('user',  3, 'input',    'full_name',       'Имя',                            NULL,                NULL, 'Учётная запись', NULL),
    ('user',  4, 'combobox', 'state',           'Состояние',                      'user_states_combo', NULL, 'Учётная запись', '{"placeholder": "—"}'),
    ('user',  5, 'input',    'password',        'Новый пароль (пусто — не менять)', NULL,              NULL, 'Учётная запись', '{"type": "password"}'),
    ('user',  6, 'label',    'password_hint',   'Пользователь сменит заданный пароль при следующем входе.', NULL, NULL, 'Учётная запись', NULL),
    ('user',  7, 'combobox', 'role_to_add',     'Роль',                           'roles_combo',       NULL, 'Роли',           NULL),
    ('user',  8, 'button',   'btn_role_add',    'Назначить роль',                 'user_role_add',     NULL, 'Роли',           NULL),
    ('user',  9, 'grid',     'user_roles_grid', 'Роли пользователя',              'user_roles_page',   'id', 'Роли',           NULL),
    ('user', 10, 'button',   'btn_save',        'Сохранить',                      'user_save',         NULL, NULL,             NULL),
    ('user', 11, 'button',   'btn_cancel',      'Закрыть',                        'form_close',        NULL, NULL,             NULL),

    ('roles', 1, 'button', 'btn_role_new', 'Новая роль', 'role_new_open', NULL, NULL, NULL),
    ('roles', 2, 'grid',   'roles_grid',   'Роли',       'roles_page',    NULL, NULL, NULL),

    ('role',  1, 'hidden',   'id',              NULL,               NULL,              NULL, NULL, NULL),
    ('role',  2, 'input',    'role_name',       'Код',              NULL,              NULL, NULL, NULL),
    ('role',  3, 'input',    'title',           'Название',         NULL,              NULL, NULL, NULL),
    ('role',  4, 'label',    'forms_hint',      'Пользователи роли видят эти формы в меню и выполняют их действия. Формы, которые открываются из них (карточки, окна выбора), доступны автоматически.', NULL, NULL, NULL, NULL),
    ('role',  5, 'combobox', 'form_to_add',     'Форма',            'forms_combo',     NULL, NULL, NULL),
    ('role',  6, 'button',   'btn_form_add',    'Добавить форму',   'role_form_add',   NULL, NULL, NULL),
    ('role',  7, 'grid',     'role_forms_grid', 'Формы роли',       'role_forms_page', 'id', NULL, NULL),
    ('role',  8, 'button',   'btn_save',        'Сохранить',        'role_save',       NULL, NULL, NULL),
    ('role',  9, 'button',   'btn_cancel',      'Закрыть',          'form_close',      NULL, NULL, NULL),

    ('password_change', 1, 'label',  'hint',                'Пароль — не короче 8 символов.', NULL, NULL, NULL, NULL),
    ('password_change', 2, 'input',  'old_password',        'Текущий пароль',     NULL,                     NULL, NULL, '{"type": "password"}'),
    ('password_change', 3, 'input',  'new_password',        'Новый пароль',       NULL,                     NULL, NULL, '{"type": "password"}'),
    ('password_change', 4, 'input',  'new_password_repeat', 'Повтор пароля',      NULL,                     NULL, NULL, '{"type": "password"}'),
    ('password_change', 5, 'button', 'btn_change',          'Сменить пароль',     'password_change',        NULL, NULL, NULL),
    ('password_change', 6, 'button', 'btn_cancel',          'Отмена',             'password_change_cancel', NULL, NULL, NULL);

-- Меню: группа «Администрирование» в конце
WITH grp AS (
    INSERT INTO pgerp.menu_items (parent_id, sort_order, title)
    VALUES (NULL, (SELECT COALESCE(max(sort_order), 0) + 1 FROM pgerp.menu_items WHERE parent_id IS NULL),
            'Администрирование')
    RETURNING id
)
INSERT INTO pgerp.menu_items (parent_id, sort_order, title, form_name)
SELECT grp.id, v.sort_order, v.title, v.form_name
FROM grp, (VALUES (1, 'Пользователи', 'users'), (2, 'Роли', 'roles')) AS v(sort_order, title, form_name);


-- ---------------------------------------------------------------------
-- Первый администратор: admin / admin, пароль нужно сменить при входе
-- ---------------------------------------------------------------------
INSERT INTO pgerp.roles (role_name, title) VALUES ('admin', 'Администратор');
INSERT INTO pgerp.users (login, full_name, password_hash, must_change_password)
VALUES ('admin', 'Администратор', pgerp.auth_hash('admin'), TRUE);
INSERT INTO pgerp.user_roles (user_id, role_id)
SELECT u.id, r.id FROM pgerp.users u, pgerp.roles r WHERE u.login = 'admin' AND r.role_name = 'admin';
