-- =====================================================================
-- Фильтр таблицы полем формы.
--   * Источник таблицы получает значения полей формы (как источник дерева) — по ним можно фильтровать.
--   * Поле ввода с options.refresh = "<таблица>" перечитывает таблицу при вводе (с паузой).
--   * pgerp.ui_grid_page: p_search_column, p_search — строки, где колонка содержит текст
--     (без учёта регистра). Пустой p_search — без фильтра.
--
-- "Заказы": над таблицей поле «Клиент» — фильтр заказов по клиенту.
-- =====================================================================

-- Новые параметры меняют сигнатуру: старая функция удаляется, иначе вызовы с умолчаниями
-- стали бы неоднозначными. Источники на LANGUAGE sql хранят тело текстом и найдут новую функцию.
DROP FUNCTION pgerp.ui_grid_page(VARCHAR, JSON, REGCLASS, VARCHAR, VARCHAR, VARCHAR);

-- Универсальный источник данных таблицы: пагинация, сортировка, фильтр по мастеру и поиск.
--   p_source        — таблица/представление (задаётся кодом функции-источника, не клиентом);
--   p_master_column — колонка связи с мастером; без master_id в запросе строк нет (новая запись);
--   p_search_column — колонка поиска, p_search — искомый текст (обычно значение поля-фильтра).
-- В строки попадают все поля источника: кроме колонок таблицы они доступны действиям
-- строк и режиму выбора (например, подстановка цены товара).
CREATE FUNCTION pgerp.ui_grid_page(p_action VARCHAR, p_data JSON, p_source REGCLASS,
                                   p_master_column VARCHAR DEFAULT NULL,
                                   p_default_sort VARCHAR DEFAULT 'id', p_default_dir VARCHAR DEFAULT 'desc',
                                   p_search_column VARCHAR DEFAULT NULL, p_search TEXT DEFAULT NULL)
RETURNS JSON AS $$
DECLARE
    v_limit       INT    := ui_page_param(p_data, 'limit', 10, 100);
    v_page        INT    := ui_page_param(p_data, 'page', 1, 1000000);
    v_master      BIGINT := ui_parse_id(p_data->>'master_id');
    v_search      TEXT   := NULLIF(trim(p_search), '');
    v_where       TEXT   := 'TRUE';
    v_sort        RECORD;
    v_sort_column TEXT;
    v_sort_dir    TEXT;
    v_total_rows  INT;
    v_total_pages INT;
    v_rows        JSON;
BEGIN
    IF p_master_column IS NOT NULL THEN
        v_where := format('%I = $1', p_master_column);
    END IF;
    -- strpos, а не LIKE: символы % и _ в тексте поиска ищутся как есть
    IF p_search_column IS NOT NULL AND v_search IS NOT NULL THEN
        v_where := v_where || format(' AND strpos(lower(%I::TEXT), lower($4)) > 0', p_search_column);
    END IF;

    SELECT * INTO v_sort FROM ui_grid_sort(p_action, p_data, p_default_sort, p_default_dir);
    v_sort_column := COALESCE(v_sort.sort_column, 'id');
    v_sort_dir    := COALESCE(v_sort.dir, p_default_dir);

    EXECUTE format('SELECT count(*) FROM %s WHERE %s', p_source, v_where)
    INTO v_total_rows
    USING v_master, NULL::INT, NULL::INT, v_search;

    v_total_pages := GREATEST(CEIL(v_total_rows::NUMERIC / v_limit)::INT, 1);
    v_page := LEAST(v_page, v_total_pages);

    EXECUTE format('SELECT json_agg(t) FROM (SELECT * FROM %s WHERE %s ORDER BY %I %s, id %s LIMIT $2 OFFSET $3) t',
                   p_source, v_where, v_sort_column, v_sort_dir, v_sort_dir)
    INTO v_rows
    USING v_master, v_limit, (v_page - 1) * v_limit, v_search;

    RETURN json_build_object(
        'status', 'success',
        'meta', json_build_object(
            'current_page', v_page,
            'limit', v_limit,
            'total_rows', v_total_rows,
            'total_pages', v_total_pages,
            'sort', json_build_object('field', COALESCE(v_sort.field, 'id'), 'dir', v_sort_dir)),
        'columns', ui_grid_columns(p_action),
        'row_actions', ui_grid_row_actions(p_action),
        'rows', COALESCE(v_rows, '[]'::json));
END;
$$ LANGUAGE plpgsql;


-- ---------------------------------------------------------------------
-- "Заказы": фильтр по клиенту
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION orders_page(p_data JSON)
RETURNS JSON AS $$
    SELECT ui_grid_page('orders_page', p_data, 'orders_v',
                        p_search_column => 'customer', p_search => p_data->>'customer_filter');
$$ LANGUAGE sql;

-- Поле-фильтр — первым, над кнопками и таблицей
UPDATE pgerp.form_components SET sort_order = sort_order + 1 WHERE form_name = 'orders';

INSERT INTO pgerp.form_components (form_name, sort_order, component_type, component_name, label, options)
VALUES ('orders', 1, 'input', 'customer_filter', 'Клиент', '{"refresh": "orders_grid"}');

UPDATE pgerp.forms SET updated_at = now() WHERE form_name = 'orders';
