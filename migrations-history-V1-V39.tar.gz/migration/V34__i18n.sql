-- =====================================================================
-- Мультиязычность.
--
--  * Исходный язык — русский: на нём написаны метаданные и сообщения обработчиков. Перевод ищется
--    по исходному тексту, как в gettext (pgerp.translations: язык, исходный текст → перевод),
--    поэтому код обработчиков менять не нужно.
--  * Сообщения с подстановками переводятся по шаблону: в исходном тексте — плейсхолдеры format()
--    (%s, %I, %L, %1$s) или RAISE (%); текст ошибки «Товар «Стол» уже есть» находит перевод
--    шаблона «Товар «%s» уже есть». В переводе — плейсхолдеры format(): %s или %1$s, %2$s, …
--    Подставленные значения тоже переводятся, если для них есть точный перевод.
--  * Маршрутизатор переводит ответ действия: текст ошибки, инструкции (text, title, confirm_label),
--    заголовки колонок, кнопки строк, подписи элементов списков. form_get и menu_get переводят форму
--    и меню; редакторы получают исходные тексты (параметр "source": true).
--    Данные (строки таблиц, узлы деревьев, значения полей) не переводятся; обработчик может
--    перевести текст сам: ui_t('…').
--  * Язык пользователя — pgerp.users.lang (переключатель в шапке, действие session_lang_set);
--    не задан — язык браузера (Accept-Language), иначе исходный.
--  * Форма «Переводы» (Администрирование): переводы и тексты без перевода — из метаданных
--    и строковых литералов кода функций.
-- =====================================================================

-- ---------------------------------------------------------------------
-- Языки и переводы
-- ---------------------------------------------------------------------
CREATE TABLE pgerp.languages (
    code       VARCHAR(10)  PRIMARY KEY CHECK (code ~ '^[a-z]{2,3}$'),
    title      VARCHAR(100) NOT NULL,
    is_source  BOOLEAN      NOT NULL DEFAULT FALSE,
    sort_order INT          NOT NULL DEFAULT 0
);
-- Исходный язык один
CREATE UNIQUE INDEX languages_source_key ON pgerp.languages (is_source) WHERE is_source;

INSERT INTO pgerp.languages (code, title, is_source, sort_order) VALUES
    ('ru', 'Русский', TRUE,  1),
    ('en', 'English', FALSE, 2);

CREATE TABLE pgerp.translations (
    id          BIGSERIAL   PRIMARY KEY,
    lang        VARCHAR(10) NOT NULL REFERENCES pgerp.languages ON UPDATE CASCADE ON DELETE CASCADE,
    source      TEXT        NOT NULL CHECK (source <> ''),
    translation TEXT        NOT NULL CHECK (translation <> ''),
    -- Исходный текст с плейсхолдерами: ищется по шаблону, если точного совпадения нет
    is_template BOOLEAN     GENERATED ALWAYS AS (source ~ '%') STORED,
    UNIQUE (lang, source)
);
CREATE INDEX ON pgerp.translations (lang) WHERE is_template;

ALTER TABLE pgerp.users ADD COLUMN lang VARCHAR(10)
    REFERENCES pgerp.languages ON UPDATE CASCADE ON DELETE SET NULL;


-- ---------------------------------------------------------------------
-- Текущий язык
-- ---------------------------------------------------------------------
CREATE FUNCTION pgerp.i18n_source_lang()
RETURNS VARCHAR AS $$
    SELECT code FROM pgerp.languages WHERE is_source;
$$ LANGUAGE sql STABLE;

-- Код языка из запроса ("en", "en-US", "EN") → язык из pgerp.languages или NULL
CREATE FUNCTION pgerp.i18n_resolve(p_lang VARCHAR)
RETURNS VARCHAR AS $$
    SELECT code FROM pgerp.languages WHERE code = lower(split_part(split_part(p_lang, '-', 1), '_', 1));
$$ LANGUAGE sql STABLE;

-- Язык текущего действия (задаёт маршрутизатор); вне него — исходный
CREATE FUNCTION pgerp.ui_lang()
RETURNS VARCHAR AS $$
    SELECT COALESCE(pgerp.i18n_resolve(NULLIF(current_setting('pgerp.lang', TRUE), '')), pgerp.i18n_source_lang());
$$ LANGUAGE sql STABLE;

CREATE FUNCTION pgerp.i18n_is_source()
RETURNS BOOLEAN AS $$
    SELECT pgerp.ui_lang() = pgerp.i18n_source_lang();
$$ LANGUAGE sql STABLE;


-- ---------------------------------------------------------------------
-- Перевод текста
-- ---------------------------------------------------------------------
-- Точный перевод: подписи, заголовки, пункты меню
CREATE FUNCTION pgerp.ui_t_exact(p_text TEXT)
RETURNS TEXT AS $$
    SELECT COALESCE(
        (SELECT t.translation FROM pgerp.translations t
         WHERE t.lang = pgerp.ui_lang() AND t.source = p_text AND NOT pgerp.i18n_is_source()),
        p_text);
$$ LANGUAGE sql STABLE;

-- Регулярное выражение шаблона: спецсимволы экранируются, плейсхолдеры format() и RAISE — группы
CREATE FUNCTION pgerp.i18n_template_regex(p_source TEXT)
RETURNS TEXT AS $$
    SELECT '^' || replace(
        regexp_replace(
            replace(regexp_replace(p_source, '([.^$*+?()\[\]{}|\\])', '\\\1', 'g'), '%%', chr(1)),
            '%([0-9]+\$)?[sIL]?', '(.*?)', 'g'),
        chr(1), '%') || '$';
$$ LANGUAGE sql IMMUTABLE;

-- Перевод текста на язык действия: точный, иначе по шаблону с подстановками, иначе исходный текст
CREATE FUNCTION pgerp.ui_t(p_text TEXT)
RETURNS TEXT AS $$
DECLARE
    v_lang     VARCHAR := pgerp.ui_lang();
    v_template RECORD;
    v_args     TEXT[];
    v_result   TEXT;
BEGIN
    IF p_text IS NULL OR p_text = '' OR v_lang = pgerp.i18n_source_lang() THEN
        RETURN p_text;
    END IF;

    SELECT translation INTO v_result FROM pgerp.translations WHERE lang = v_lang AND source = p_text;
    IF FOUND THEN
        RETURN v_result;
    END IF;

    -- Длинные шаблоны первыми: они точнее
    FOR v_template IN
        SELECT source, translation FROM pgerp.translations
        WHERE lang = v_lang AND is_template
        ORDER BY length(source) DESC
    LOOP
        v_args := regexp_match(p_text, pgerp.i18n_template_regex(v_template.source));
        IF v_args IS NOT NULL THEN
            BEGIN
                RETURN format(v_template.translation,
                              VARIADIC ARRAY(SELECT pgerp.ui_t_exact(a)
                                             FROM unnest(v_args) WITH ORDINALITY AS u(a, n) ORDER BY n));
            EXCEPTION WHEN OTHERS THEN
                -- Перевод не подходит к числу подстановок — показываем исходный текст
                RETURN p_text;
            END;
        END IF;
    END LOOP;
    RETURN p_text;
END;
$$ LANGUAGE plpgsql STABLE;


-- ---------------------------------------------------------------------
-- Перевод ответов
-- ---------------------------------------------------------------------
-- Строковые значения ключей p_keys объекта
CREATE FUNCTION pgerp.i18n_keys(p_object JSONB, p_keys TEXT[], p_exact BOOLEAN)
RETURNS JSONB AS $$
DECLARE
    v_key TEXT;
BEGIN
    IF jsonb_typeof(p_object) IS DISTINCT FROM 'object' THEN
        RETURN p_object;
    END IF;
    FOREACH v_key IN ARRAY p_keys LOOP
        IF jsonb_typeof(p_object->v_key) = 'string' THEN
            p_object := jsonb_set(p_object, ARRAY[v_key], to_jsonb(
                CASE WHEN p_exact THEN pgerp.ui_t_exact(p_object->>v_key) ELSE pgerp.ui_t(p_object->>v_key) END));
        END IF;
    END LOOP;
    RETURN p_object;
END;
$$ LANGUAGE plpgsql STABLE;

-- То же для каждого объекта массива
CREATE FUNCTION pgerp.i18n_array(p_array JSONB, p_keys TEXT[], p_exact BOOLEAN)
RETURNS JSONB AS $$
    SELECT CASE WHEN jsonb_typeof(p_array) = 'array' THEN
        COALESCE((SELECT jsonb_agg(pgerp.i18n_keys(e, p_keys, p_exact) ORDER BY n)
                  FROM jsonb_array_elements(p_array) WITH ORDINALITY AS t(e, n)), '[]'::jsonb)
        ELSE p_array END;
$$ LANGUAGE sql STABLE;

-- Заменить массив p_key объекта переведённым
CREATE FUNCTION pgerp.i18n_set_array(p_object JSONB, p_key TEXT, p_keys TEXT[], p_exact BOOLEAN)
RETURNS JSONB AS $$
    SELECT CASE WHEN jsonb_typeof(p_object->p_key) = 'array'
                THEN jsonb_set(p_object, ARRAY[p_key], pgerp.i18n_array(p_object->p_key, p_keys, p_exact))
                ELSE p_object END;
$$ LANGUAGE sql STABLE;

-- Ответ действия: ошибка, инструкции, колонки и кнопки строк таблицы, элементы выпадающего списка
CREATE FUNCTION pgerp.i18n_response(p_result JSON)
RETURNS JSON AS $$
DECLARE
    v_result JSONB;
BEGIN
    IF p_result IS NULL OR pgerp.i18n_is_source() OR json_typeof(p_result) <> 'object' THEN
        RETURN p_result;
    END IF;
    v_result := pgerp.i18n_keys(p_result::jsonb, '{message}', FALSE);
    v_result := pgerp.i18n_set_array(v_result, 'ui_instructions', '{text,title,confirm_label}', FALSE);
    v_result := pgerp.i18n_set_array(v_result, 'columns', '{title}', TRUE);
    v_result := pgerp.i18n_set_array(v_result, 'row_actions', '{label}', TRUE);
    v_result := pgerp.i18n_set_array(v_result, 'items', '{label}', TRUE);
    RETURN v_result::json;
END;
$$ LANGUAGE plpgsql STABLE;


-- ---------------------------------------------------------------------
-- Маршрутизатор: язык действия и перевод ответа
-- ---------------------------------------------------------------------
DROP FUNCTION pgerp.handle_ui_event(VARCHAR, VARCHAR, JSON);

-- p_lang — язык браузера (Accept-Language); язык из настройки пользователя важнее
CREATE FUNCTION pgerp.handle_ui_event(p_user VARCHAR, p_action VARCHAR, p_form_data JSON,
                                      p_lang VARCHAR DEFAULT NULL)
RETURNS JSON AS $$
DECLARE
    v_user         pgerp.users%ROWTYPE;
    v_action       pgerp.ui_actions%ROWTYPE;
    v_result       JSON;
    v_message      TEXT;
    v_state        TEXT;
    v_instructions TEXT;
BEGIN
    PERFORM set_config('pgerp.lang', COALESCE(pgerp.i18n_resolve(p_lang), ''), TRUE);

    SELECT * INTO v_user FROM pgerp.users WHERE login = p_user AND is_active;
    IF NOT FOUND THEN
        RAISE EXCEPTION USING MESSAGE = pgerp.ui_t('Сеанс завершён — войдите снова'), ERRCODE = 'U0002';
    END IF;
    -- До конца транзакции: обработчики, триггеры и ui_push видят пользователя и язык
    PERFORM set_config('pgerp.user', v_user.login, TRUE);
    IF v_user.lang IS NOT NULL THEN
        PERFORM set_config('pgerp.lang', v_user.lang, TRUE);
    END IF;

    SELECT * INTO v_action FROM pgerp.ui_actions WHERE action_name = p_action;
    IF NOT FOUND THEN
        RAISE EXCEPTION USING MESSAGE = pgerp.ui_t(format('Неизвестное действие: %s', p_action));
    END IF;

    IF NOT v_action.everyone THEN
        IF v_user.must_change_password THEN
            RAISE EXCEPTION USING MESSAGE = pgerp.ui_t('Смените пароль, чтобы продолжить работу'),
                                  ERRCODE = 'U0003';
        END IF;
        IF NOT pgerp.auth_action_allowed(v_user.id, p_action) THEN
            RAISE EXCEPTION USING ERRCODE = 'U0003', MESSAGE = pgerp.ui_t(
                format('Нет доступа к действию «%s»', COALESCE(v_action.description, p_action)));
        END IF;
    END IF;

    BEGIN
        -- regproc при выводе даёт корректно экранированное имя функции
        EXECUTE format('SELECT %s($1)', v_action.function_name) INTO v_result USING p_form_data;
    EXCEPTION
        WHEN SQLSTATE 'U0001' THEN
            GET STACKED DIAGNOSTICS v_message = MESSAGE_TEXT, v_instructions = PG_EXCEPTION_DETAIL;
            RETURN pgerp.i18n_response(json_build_object(
                'status', 'error',
                'message', v_message,
                'ui_instructions', v_instructions::JSON));
        -- Ошибки ввода и доступа — на языке пользователя; изменения обработчика откатываются
        WHEN raise_exception OR SQLSTATE 'U0002' OR SQLSTATE 'U0003' THEN
            GET STACKED DIAGNOSTICS v_message = MESSAGE_TEXT, v_state = RETURNED_SQLSTATE;
            RAISE EXCEPTION USING MESSAGE = pgerp.ui_t(v_message), ERRCODE = v_state;
    END;
    RETURN pgerp.i18n_response(v_result);
END;
$$ LANGUAGE plpgsql
SET search_path = public, pgerp;


-- ---------------------------------------------------------------------
-- Вход: сообщения на языке пользователя или браузера
-- ---------------------------------------------------------------------
DROP FUNCTION pgerp.auth_login(VARCHAR, TEXT);

CREATE FUNCTION pgerp.auth_login(p_login VARCHAR, p_password TEXT, p_lang VARCHAR DEFAULT NULL)
RETURNS TABLE (user_login VARCHAR, user_roles VARCHAR[], error_message TEXT) AS $$
DECLARE
    c_attempts CONSTANT INT      := 5;
    c_lock     CONSTANT INTERVAL := '5 minutes';
    v_user     pgerp.users%ROWTYPE;
BEGIN
    PERFORM set_config('pgerp.lang', COALESCE(pgerp.i18n_resolve(p_lang), ''), TRUE);

    SELECT * INTO v_user FROM pgerp.users u WHERE u.login = lower(trim(p_login)) FOR UPDATE;
    IF NOT FOUND THEN
        -- Время ответа как у существующего логина: по нему нельзя подобрать логины
        PERFORM pgerp.auth_hash(COALESCE(p_password, ''));
        RETURN QUERY SELECT NULL::VARCHAR, NULL::VARCHAR[], pgerp.ui_t('Неверный логин или пароль');
        RETURN;
    END IF;
    IF v_user.lang IS NOT NULL THEN
        PERFORM set_config('pgerp.lang', v_user.lang, TRUE);
    END IF;

    IF v_user.locked_until > now() THEN
        RETURN QUERY SELECT NULL::VARCHAR, NULL::VARCHAR[], pgerp.ui_t(
            format('Слишком много неудачных попыток входа. Повторите через %s мин.',
                   ceil(extract(epoch FROM v_user.locked_until - now()) / 60)));
        RETURN;
    END IF;

    IF NOT pgerp.auth_password_ok(p_password, v_user.password_hash) THEN
        UPDATE pgerp.users u
        SET failed_attempts = CASE WHEN u.failed_attempts + 1 >= c_attempts THEN 0 ELSE u.failed_attempts + 1 END,
            locked_until    = CASE WHEN u.failed_attempts + 1 >= c_attempts THEN now() + c_lock END
        WHERE u.id = v_user.id;
        RETURN QUERY SELECT NULL::VARCHAR, NULL::VARCHAR[], pgerp.ui_t('Неверный логин или пароль');
        RETURN;
    END IF;

    IF NOT v_user.is_active THEN
        RETURN QUERY SELECT NULL::VARCHAR, NULL::VARCHAR[],
            pgerp.ui_t('Учётная запись отключена — обратитесь к администратору');
        RETURN;
    END IF;

    UPDATE pgerp.users u
    SET failed_attempts = 0, locked_until = NULL, last_login_at = now()
    WHERE u.id = v_user.id;

    RETURN QUERY
    SELECT v_user.login,
           ARRAY(SELECT r.role_name FROM pgerp.user_roles ur JOIN pgerp.roles r ON r.id = ur.role_id
                 WHERE ur.user_id = v_user.id ORDER BY r.role_name)::VARCHAR[],
           NULL::TEXT;
END;
$$ LANGUAGE plpgsql;


-- ---------------------------------------------------------------------
-- Форма, меню, сеанс
-- ---------------------------------------------------------------------
-- Форма на языке пользователя: заголовок, подписи, вкладки, пустой пункт списка.
-- "source": true — исходные тексты для редактора форм
CREATE OR REPLACE FUNCTION pgerp.ui_form_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_form    VARCHAR := p_data->>'form';
    v_user_id BIGINT  := pgerp.ui_user_id();
    v_title   VARCHAR;
    v_result  JSONB;
BEGIN
    IF v_user_id IS NOT NULL THEN
        IF (SELECT must_change_password FROM pgerp.users WHERE id = v_user_id) THEN
            IF v_form IS DISTINCT FROM 'password_change' THEN
                RAISE EXCEPTION 'Смените пароль, чтобы продолжить работу' USING ERRCODE = 'U0003';
            END IF;
        ELSIF NOT pgerp.auth_form_allowed(v_user_id, v_form) THEN
            SELECT title INTO v_title FROM pgerp.forms WHERE form_name = v_form;
            RAISE EXCEPTION USING ERRCODE = 'U0003',
                MESSAGE = format('Нет доступа к форме «%s»', COALESCE(v_title, v_form));
        END IF;
    END IF;

    v_result := pgerp.ui_form_get(p_data)::jsonb;
    IF (p_data->>'source')::BOOLEAN IS TRUE OR pgerp.i18n_is_source() THEN
        RETURN v_result::json;
    END IF;
    v_result := jsonb_set(v_result, '{form}', pgerp.i18n_keys(v_result->'form', '{title}', TRUE));
    v_result := jsonb_set(v_result, '{form,components}', COALESCE((
        SELECT jsonb_agg(
                   pgerp.i18n_keys(c, '{label,tab}', TRUE)
                   || CASE WHEN jsonb_typeof(c->'options') = 'object'
                           THEN jsonb_build_object('options', pgerp.i18n_keys(c->'options', '{placeholder}', TRUE))
                           ELSE '{}' END
                   ORDER BY n)
        FROM jsonb_array_elements(v_result->'form'->'components') WITH ORDINALITY AS t(c, n)), '[]'::jsonb));
    RETURN v_result::json;
END;
$$ LANGUAGE plpgsql;

-- Пункты меню с подпунктами на языке пользователя
CREATE FUNCTION pgerp.i18n_menu(p_items JSONB)
RETURNS JSONB AS $$
    SELECT COALESCE(jsonb_agg(
               pgerp.i18n_keys(i, '{title}', TRUE) || jsonb_build_object('items', pgerp.i18n_menu(i->'items'))
               ORDER BY n), '[]'::jsonb)
    FROM jsonb_array_elements(p_items) WITH ORDINALITY AS t(i, n);
$$ LANGUAGE sql STABLE;

-- В меню — формы, выданные ролям пользователя напрямую. "source": true — исходные тексты для редактора меню
CREATE OR REPLACE FUNCTION pgerp.ui_menu_get(p_data JSON)
RETURNS JSON AS $$
    WITH menu AS (
        SELECT pgerp.ui_menu_level(NULL,
            CASE WHEN pgerp.ui_user_id() IS NULL OR pgerp.auth_is_admin(pgerp.ui_user_id()) THEN NULL
                 ELSE ARRAY(SELECT rf.form_name
                            FROM pgerp.role_forms rf
                            JOIN pgerp.user_roles ur ON ur.role_id = rf.role_id
                            WHERE ur.user_id = pgerp.ui_user_id())::VARCHAR[] END)::jsonb AS items
    )
    SELECT json_build_object('status', 'success', 'items',
        CASE WHEN (p_data->>'source')::BOOLEAN IS TRUE OR pgerp.i18n_is_source() THEN items
             ELSE pgerp.i18n_menu(items) END)
    FROM menu;
$$ LANGUAGE sql STABLE;

-- Сеанс: пользователь, язык действия и доступные языки (переключатель в шапке)
CREATE OR REPLACE FUNCTION pgerp.ui_session_get(p_data JSON)
RETURNS JSON AS $$
    SELECT json_build_object(
        'status', 'success',
        'user', json_build_object(
            'login', u.login,
            'full_name', u.full_name,
            'roles', ARRAY(SELECT r.role_name FROM pgerp.user_roles ur JOIN pgerp.roles r ON r.id = ur.role_id
                           WHERE ur.user_id = u.id ORDER BY r.role_name),
            'is_admin', pgerp.auth_is_admin(u.id),
            'must_change_password', u.must_change_password,
            'lang', pgerp.ui_lang()),
        'languages', (SELECT json_agg(json_build_object('code', code, 'title', title) ORDER BY sort_order, code)
                      FROM pgerp.languages))
    FROM pgerp.users u
    WHERE u.id = pgerp.ui_user_id();
$$ LANGUAGE sql STABLE;

-- Язык пользователя из переключателя в шапке
CREATE FUNCTION pgerp.ui_session_lang_set(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_lang VARCHAR := pgerp.i18n_resolve(p_data->>'lang');
BEGIN
    PERFORM ui_require(v_lang IS NOT NULL, format('Язык «%s» не поддерживается', p_data->>'lang'));
    UPDATE pgerp.users SET lang = v_lang WHERE id = pgerp.ui_user_id();
    RETURN ui_ok();
END;
$$ LANGUAGE plpgsql;


-- ---------------------------------------------------------------------
-- Тексты состояний в представлениях администрирования — на языке пользователя
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW pgerp.users_v AS
SELECT u.id, u.login, u.full_name,
       (SELECT string_agg(pgerp.ui_t_exact(r.title), ', ' ORDER BY r.title)
        FROM pgerp.user_roles ur JOIN pgerp.roles r ON r.id = ur.role_id
        WHERE ur.user_id = u.id) AS roles,
       pgerp.ui_t_exact(CASE WHEN NOT u.is_active          THEN 'Отключён'
                             WHEN u.locked_until > now()   THEN 'Вход заблокирован'
                             WHEN u.must_change_password   THEN 'Должен сменить пароль'
                             ELSE 'Активен' END) AS status,
       to_char(u.last_login_at, 'DD.MM.YYYY HH24:MI') AS last_login,
       u.last_login_at
FROM pgerp.users u;

DROP VIEW pgerp.roles_v;
CREATE VIEW pgerp.roles_v AS
SELECT r.id, r.role_name, pgerp.ui_t_exact(r.title) AS title,
       (SELECT count(*) FROM pgerp.user_roles ur WHERE ur.role_id = r.id) AS users_count,
       CASE WHEN r.role_name = 'admin' THEN pgerp.ui_t_exact('Все формы')
            ELSE (SELECT string_agg(pgerp.ui_t_exact(f.title), ', ' ORDER BY f.title)
                  FROM pgerp.role_forms rf JOIN pgerp.forms f ON f.form_name = rf.form_name
                  WHERE rf.role_id = r.id) END AS forms
FROM pgerp.roles r;

DROP VIEW pgerp.role_forms_v;
CREATE VIEW pgerp.role_forms_v AS
SELECT rf.id, rf.role_id, rf.form_name, pgerp.ui_t_exact(f.title) AS title, pgerp.ui_t_exact(f.folder) AS folder
FROM pgerp.role_forms rf
JOIN pgerp.forms f ON f.form_name = rf.form_name;

CREATE OR REPLACE VIEW pgerp.forms_combo_v AS
SELECT form_name, concat_ws(' / ', pgerp.ui_t_exact(folder), pgerp.ui_t_exact(title)) AS label
FROM pgerp.forms;

CREATE VIEW pgerp.roles_combo_v AS
SELECT id, pgerp.ui_t_exact(title) AS title FROM pgerp.roles;

CREATE OR REPLACE FUNCTION pgerp.roles_combo(p_data JSON)
RETURNS JSON AS $$
    SELECT ui_combo_items('pgerp.roles_combo_v', 'title');
$$ LANGUAGE sql STABLE;


-- ---------------------------------------------------------------------
-- Тексты для перевода
-- ---------------------------------------------------------------------
-- Метаданные и строковые литералы с кириллицей в коде функций схем public и pgerp
-- (сообщения ui_require, ui_message, шаблоны format()). Склеенные из частей тексты сюда
-- попадают частями — их обработчик переводит сам через ui_t().
CREATE VIEW pgerp.translatable_texts AS
SELECT DISTINCT ON (source) source, origin
FROM (
    SELECT title AS source, 'Форма' AS origin, 1 AS priority FROM pgerp.forms
    UNION ALL SELECT folder, 'Папка форм', 1 FROM pgerp.forms WHERE folder IS NOT NULL
    UNION ALL SELECT label, 'Компонент формы', 1 FROM pgerp.form_components WHERE label IS NOT NULL
    UNION ALL SELECT tab, 'Вкладка формы', 1 FROM pgerp.form_components WHERE tab IS NOT NULL
    UNION ALL SELECT options->>'placeholder', 'Пустой пункт списка', 1 FROM pgerp.form_components
              WHERE options->>'placeholder' IS NOT NULL
    UNION ALL SELECT column_title, 'Колонка таблицы', 1 FROM pgerp.grid_columns
    UNION ALL SELECT label, 'Кнопка строки', 1 FROM pgerp.grid_row_actions
    UNION ALL SELECT title, 'Меню', 1 FROM pgerp.menu_items
    UNION ALL SELECT description, 'Действие', 1 FROM pgerp.ui_actions WHERE description IS NOT NULL
    UNION ALL SELECT title, 'Роль', 1 FROM pgerp.roles
    UNION ALL
    SELECT replace(m[1], '''''', ''''), 'Код: ' || p.proname, 2
    FROM pg_proc p
    CROSS JOIN LATERAL regexp_matches(p.prosrc, '''((?:[^'']|'''')*)''', 'g') AS m
    WHERE p.pronamespace IN ('public'::regnamespace, 'pgerp'::regnamespace)
      AND m[1] ~ '[Ѐ-ӿ]'
) t
WHERE trim(source) <> ''
ORDER BY source, priority, origin;

-- Тексты без перевода на каждый язык, кроме исходного. id — устойчивый хеш языка и текста
CREATE VIEW pgerp.translation_missing_v AS
SELECT ('x' || substr(md5(l.code || chr(1) || t.source), 1, 15))::BIT(60)::BIGINT AS id,
       l.code AS lang, t.source, t.origin
FROM pgerp.languages l
CROSS JOIN pgerp.translatable_texts t
WHERE NOT l.is_source
  AND NOT EXISTS (SELECT 1 FROM pgerp.translations tr WHERE tr.lang = l.code AND tr.source = t.source);

CREATE VIEW pgerp.target_languages_v AS
SELECT code, title, sort_order FROM pgerp.languages WHERE NOT is_source;


-- ---------------------------------------------------------------------
-- Форма «Переводы»
-- ---------------------------------------------------------------------
CREATE FUNCTION pgerp.translations_page(p_data JSON)
RETURNS JSON AS $$
    SELECT ui_grid_page('translations_page', p_data, 'pgerp.translations', NULL, 'source', 'asc',
                        'source', p_data->>'translation_filter');
$$ LANGUAGE sql;

CREATE FUNCTION pgerp.translation_missing_page(p_data JSON)
RETURNS JSON AS $$
    SELECT ui_grid_page('translation_missing_page', p_data, 'pgerp.translation_missing_v', NULL, 'source', 'asc',
                        'source', p_data->>'translation_filter');
$$ LANGUAGE sql;

CREATE FUNCTION pgerp.target_languages_combo(p_data JSON)
RETURNS JSON AS $$
    SELECT ui_combo_items('pgerp.target_languages_v', 'title', 'code');
$$ LANGUAGE sql STABLE;

CREATE FUNCTION pgerp.translation_new_open(p_data JSON)
RETURNS JSON AS $$
    SELECT ui_ok(ui_open_form('translation', p_title => 'Новый перевод',
        p_data => jsonb_build_object('lang', (SELECT code FROM pgerp.target_languages_v ORDER BY sort_order, code LIMIT 1))));
$$ LANGUAGE sql;

CREATE FUNCTION pgerp.translation_edit_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_row pgerp.translations%ROWTYPE;
BEGIN
    SELECT * INTO v_row FROM pgerp.translations WHERE id = ui_parse_id(p_data->>'id');
    PERFORM ui_require(FOUND, 'Перевод не найден — возможно, он удалён');
    RETURN ui_ok(ui_open_form('translation', p_title => 'Перевод',
        p_data => jsonb_build_object('id', v_row.id::TEXT, 'lang', v_row.lang,
                                     'source', v_row.source, 'translation', v_row.translation)));
END;
$$ LANGUAGE plpgsql;

-- «Перевести» в списке текстов без перевода: язык и исходный текст уже заполнены
CREATE FUNCTION pgerp.translation_missing_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_row RECORD;
BEGIN
    SELECT * INTO v_row FROM pgerp.translation_missing_v WHERE id = ui_parse_id(p_data->>'id');
    PERFORM ui_require(FOUND, 'Текст уже переведён или больше не используется');
    RETURN ui_ok(ui_open_form('translation', p_title => 'Новый перевод',
        p_data => jsonb_build_object('lang', v_row.lang, 'source', v_row.source)));
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION pgerp.translation_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_id          BIGINT  := ui_parse_id(p_data->>'id');
    v_lang        VARCHAR := ui_text(p_data, 'lang');
    v_source      TEXT    := NULLIF(p_data->>'source', '');
    v_translation TEXT    := NULLIF(trim(p_data->>'translation'), '');
    v_count       INT;
BEGIN
    PERFORM ui_require(EXISTS (SELECT 1 FROM pgerp.target_languages_v WHERE code = v_lang), 'Выберите язык перевода');
    PERFORM ui_require(v_source IS NOT NULL, 'Укажите исходный текст');
    PERFORM ui_require(v_translation IS NOT NULL, 'Укажите перевод');

    -- Перевод шаблона должен принять столько же подстановок, сколько их в исходном тексте
    v_count := (SELECT count(*) FROM regexp_matches(replace(v_source, '%%', ''), '%([0-9]+\$)?[sIL]?', 'g'));
    IF v_count > 0 THEN
        BEGIN
            PERFORM format(v_translation, VARIADIC array_fill('x'::TEXT, ARRAY[v_count]));
        EXCEPTION WHEN OTHERS THEN
            PERFORM ui_require(FALSE, format(
                'В исходном тексте подстановок: %s. В переводе используйте %%s или %%1$s, %%2$s, …', v_count));
        END;
    END IF;

    IF ui_is_new(p_data) THEN
        INSERT INTO pgerp.translations (lang, source, translation) VALUES (v_lang, v_source, v_translation)
        ON CONFLICT (lang, source) DO UPDATE SET translation = EXCLUDED.translation;
    ELSE
        PERFORM ui_require(
            NOT EXISTS (SELECT 1 FROM pgerp.translations WHERE lang = v_lang AND source = v_source AND id <> v_id),
            'Перевод этого текста на этот язык уже есть');
        UPDATE pgerp.translations SET lang = v_lang, source = v_source, translation = v_translation WHERE id = v_id;
        PERFORM ui_require(FOUND, 'Перевод не найден — возможно, он удалён');
    END IF;

    RETURN ui_ok(
        ui_close_form(),
        ui_refresh_grid('translations_grid', p_keep_page => TRUE),
        ui_refresh_grid('translation_missing_grid', p_keep_page => TRUE));
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION pgerp.translation_delete(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_row pgerp.translations%ROWTYPE;
BEGIN
    SELECT * INTO v_row FROM pgerp.translations WHERE id = ui_parse_id(p_data->>'id');
    PERFORM ui_require(FOUND, 'Перевод не найден — возможно, он удалён');

    IF NOT ui_confirmed(p_data) THEN
        RETURN ui_ok(ui_confirm(format('Удалить перевод «%s»?', v_row.translation), 'translation_delete',
                                jsonb_build_object('id', v_row.id, 'confirmed', TRUE),
                                p_confirm_label => 'Удалить'));
    END IF;
    DELETE FROM pgerp.translations WHERE id = v_row.id;
    RETURN ui_ok(
        ui_refresh_grid('translations_grid', p_keep_page => TRUE),
        ui_refresh_grid('translation_missing_grid', p_keep_page => TRUE));
END;
$$ LANGUAGE plpgsql;


-- ---------------------------------------------------------------------
-- Метаданные
-- ---------------------------------------------------------------------
INSERT INTO pgerp.ui_actions (action_name, function_name, description, is_system, everyone) VALUES
    ('session_lang_set',         'pgerp.ui_session_lang_set',      'Смена языка пользователя',    TRUE,  TRUE),
    ('translations_page',        'pgerp.translations_page',        'Таблица: переводы',           FALSE, FALSE),
    ('translation_missing_page', 'pgerp.translation_missing_page', 'Таблица: тексты без перевода', FALSE, FALSE),
    ('target_languages_combo',   'pgerp.target_languages_combo',   'Список: языки перевода',      FALSE, FALSE),
    ('translation_new_open',     'pgerp.translation_new_open',     'Новый перевод',               FALSE, FALSE),
    ('translation_edit_open',    'pgerp.translation_edit_open',    'Карточка перевода',           FALSE, FALSE),
    ('translation_missing_open', 'pgerp.translation_missing_open', 'Перевод текста без перевода', FALSE, FALSE),
    ('translation_save',         'pgerp.translation_save',         'Сохранение перевода',         FALSE, FALSE),
    ('translation_delete',       'pgerp.translation_delete',       'Удаление перевода',           FALSE, FALSE);

INSERT INTO pgerp.grid_columns (action_name, display_order, field_name, column_title, cell_type, sort_column) VALUES
    ('translations_page',        1, 'lang',        'Язык',            'text', 'lang'),
    ('translations_page',        2, 'source',      'Исходный текст',  'text', 'source'),
    ('translations_page',        3, 'translation', 'Перевод',         'text', 'translation'),
    ('translation_missing_page', 1, 'lang',        'Язык',            'text', 'lang'),
    ('translation_missing_page', 2, 'source',      'Исходный текст',  'text', 'source'),
    ('translation_missing_page', 3, 'origin',      'Где встречается', 'text', 'origin');

INSERT INTO pgerp.grid_row_actions (source_action, sort_order, row_action, label, style) VALUES
    ('translations_page',        1, 'translation_edit_open',    'Изменить',  'default'),
    ('translations_page',        2, 'translation_delete',       'Удалить',   'danger'),
    ('translation_missing_page', 1, 'translation_missing_open', 'Перевести', 'default');

INSERT INTO pgerp.forms (form_name, title, folder) VALUES
    ('translations', 'Переводы', 'Администрирование'),
    ('translation',  'Перевод',  'Администрирование');

INSERT INTO pgerp.form_components
    (form_name, sort_order, component_type, component_name, label, action_event, tab, options) VALUES
    ('translations', 1, 'input',  'translation_filter',       'Исходный текст содержит', NULL, NULL,
     '{"refresh": "translations_grid, translation_missing_grid"}'),
    ('translations', 2, 'button', 'btn_translation_new',      'Новый перевод',  'translation_new_open',     NULL,           NULL),
    ('translations', 3, 'grid',   'translations_grid',        'Переводы',       'translations_page',        'Переводы',     NULL),
    ('translations', 4, 'grid',   'translation_missing_grid', 'Без перевода',   'translation_missing_page', 'Без перевода', NULL),

    ('translation', 1, 'hidden',   'id',          NULL,                       NULL,                     NULL, NULL),
    ('translation', 2, 'combobox', 'lang',        'Язык',                     'target_languages_combo', NULL, '{"placeholder": "—"}'),
    ('translation', 3, 'input',    'source',      'Исходный текст (русский)', NULL,                     NULL, NULL),
    ('translation', 4, 'input',    'translation', 'Перевод',                  NULL,                     NULL, NULL),
    ('translation', 5, 'label',    'hint',        'Подстановки: в исходном тексте %s (или % в RAISE), в переводе — %s или %1$s, %2$s по порядку исходного текста.', NULL, NULL, NULL),
    ('translation', 6, 'button',   'btn_save',    'Сохранить',                'translation_save',       NULL, NULL),
    ('translation', 7, 'button',   'btn_cancel',  'Закрыть',                  'form_close',             NULL, NULL);

INSERT INTO pgerp.menu_items (parent_id, sort_order, title, form_name)
SELECT id, 3, 'Переводы', 'translations'
FROM pgerp.menu_items
WHERE parent_id IS NULL AND title = 'Администрирование';
