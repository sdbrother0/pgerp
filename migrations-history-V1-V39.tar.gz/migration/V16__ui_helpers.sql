-- =====================================================================
-- Помощники для ответов действий: ui_ok(...) и по функции на каждую инструкцию UI.
--
--     RETURN ui_ok(
--         ui_close_form(),
--         ui_refresh_grid('orders_grid', p_keep_page => TRUE),
--         ui_message('Заказ сохранён'));
--
-- Все обработчики действий переписаны на помощников; поведение не меняется.
-- =====================================================================

-- ---------------------------------------------------------------------
-- Помощники
-- ---------------------------------------------------------------------

-- Инструкция: команда и её параметры; параметры со значением NULL не передаются
CREATE FUNCTION ui_instruction(p_command TEXT, p_params JSONB DEFAULT '{}')
RETURNS JSONB AS $$
    SELECT jsonb_build_object('command', p_command)
           || COALESCE((SELECT jsonb_object_agg(key, value)
                        FROM jsonb_each(p_params)
                        WHERE value <> 'null'::jsonb), '{}'::jsonb);
$$ LANGUAGE sql IMMUTABLE;

-- Успешный ответ с инструкциями. Инструкции выполняются по порядку;
-- NULL пропускается, массив инструкций разворачивается (удобно для условных групп).
CREATE FUNCTION ui_ok(VARIADIC p_instructions JSONB[] DEFAULT '{}')
RETURNS JSONB AS $$
    SELECT jsonb_build_object(
        'status', 'success',
        'ui_instructions', COALESCE(jsonb_agg(e.value ORDER BY i.n, e.n), '[]'::jsonb))
    FROM unnest(p_instructions) WITH ORDINALITY AS i(value, n)
    CROSS JOIN LATERAL jsonb_array_elements(
        CASE WHEN jsonb_typeof(i.value) = 'array' THEN i.value ELSE jsonb_build_array(i.value) END
    ) WITH ORDINALITY AS e(value, n)
    WHERE i.value IS NOT NULL;
$$ LANGUAGE sql IMMUTABLE;

CREATE FUNCTION ui_message(p_text TEXT)
RETURNS JSONB AS $$
    SELECT ui_instruction('show_message', jsonb_build_object('text', p_text));
$$ LANGUAGE sql IMMUTABLE;

-- Подтверждение: при согласии вызывается p_action с p_data
CREATE FUNCTION ui_confirm(p_text TEXT, p_action VARCHAR, p_data JSONB, p_confirm_label TEXT DEFAULT NULL)
RETURNS JSONB AS $$
    SELECT ui_instruction('confirm', jsonb_build_object(
        'text', p_text, 'action', p_action, 'data', p_data, 'confirm_label', p_confirm_label));
$$ LANGUAGE sql IMMUTABLE;

-- Открыть форму; p_select — режим выбора из списка ({value_field, display_field, fill})
CREATE FUNCTION ui_open_form(p_form VARCHAR, p_data JSONB DEFAULT NULL, p_title TEXT DEFAULT NULL,
                             p_select JSONB DEFAULT NULL, p_modal BOOLEAN DEFAULT TRUE)
RETURNS JSONB AS $$
    SELECT ui_instruction('open_form', jsonb_build_object(
        'form', p_form, 'modal', p_modal, 'title', p_title, 'data', p_data, 'select', p_select));
$$ LANGUAGE sql IMMUTABLE;

CREATE FUNCTION ui_close_form()
RETURNS JSONB AS $$
    SELECT ui_instruction('close_form');
$$ LANGUAGE sql IMMUTABLE;

CREATE FUNCTION ui_clear_form()
RETURNS JSONB AS $$
    SELECT ui_instruction('clear_form');
$$ LANGUAGE sql IMMUTABLE;

-- Заполнить поля этой формы или другой открытой формы p_form
CREATE FUNCTION ui_set_values(p_values JSONB, p_form VARCHAR DEFAULT NULL)
RETURNS JSONB AS $$
    SELECT ui_instruction('set_values', jsonb_build_object('values', p_values, 'form', p_form));
$$ LANGUAGE sql IMMUTABLE;

CREATE FUNCTION ui_set_title(p_title TEXT)
RETURNS JSONB AS $$
    SELECT ui_instruction('set_title', jsonb_build_object('title', p_title));
$$ LANGUAGE sql IMMUTABLE;

-- Перечитать таблицу; p_keep_page — остаться на текущей странице
CREATE FUNCTION ui_refresh_grid(p_grid VARCHAR, p_keep_page BOOLEAN DEFAULT FALSE)
RETURNS JSONB AS $$
    SELECT ui_instruction('refresh_grid', jsonb_build_object('grid', p_grid, 'keep_page', p_keep_page));
$$ LANGUAGE sql IMMUTABLE;


-- ---------------------------------------------------------------------
-- Системные действия
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION ui_form_close(p_data JSON)
RETURNS JSON AS $$
BEGIN
    RETURN ui_ok(ui_close_form());
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION ui_form_delete(p_data JSON)
RETURNS JSON AS $$
BEGIN
    DELETE FROM erp_forms WHERE form_name = p_data->>'form';
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Форма "%" не найдена', p_data->>'form';
    END IF;
    RETURN ui_ok();
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION ui_form_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_form_name  VARCHAR := p_data->>'name';
    v_title      VARCHAR := NULLIF(trim(p_data->>'title'), '');
    v_components JSON    := COALESCE(p_data->'components', '[]'::json);
    v_comp       RECORD;
BEGIN
    IF v_form_name IS NULL OR v_form_name !~ '^[a-z_][a-z0-9_]*$' THEN
        RAISE EXCEPTION 'Имя формы: латинские буквы в нижнем регистре, цифры и "_"';
    END IF;

    FOR v_comp IN
        SELECT c->>'type' AS type, c->>'name' AS name, NULLIF(c->>'action', '') AS action,
               NULLIF(c->>'master', '') AS master, n
        FROM json_array_elements(v_components) WITH ORDINALITY AS t(c, n)
    LOOP
        IF v_comp.type IS NULL OR NOT v_comp.type = ANY (ui_component_types()) THEN
            RAISE EXCEPTION 'Компонент №%: неизвестный тип "%"', v_comp.n, v_comp.type;
        END IF;
        IF v_comp.name IS NULL OR v_comp.name !~ '^[a-z_][a-z0-9_]*$' THEN
            RAISE EXCEPTION 'Компонент №%: имя — латинские буквы в нижнем регистре, цифры и "_"', v_comp.n;
        END IF;
        IF v_comp.type = 'grid' AND v_comp.action IS NULL THEN
            RAISE EXCEPTION 'Таблица "%": выберите действие-источник данных', v_comp.name;
        END IF;
        IF v_comp.type = 'lookup' AND v_comp.action IS NULL THEN
            RAISE EXCEPTION 'Поле выбора "%": выберите действие открытия списка', v_comp.name;
        END IF;
        IF v_comp.action IS NOT NULL
           AND NOT EXISTS (SELECT 1 FROM erp_ui_actions WHERE action_name = v_comp.action AND NOT is_system) THEN
            RAISE EXCEPTION 'Компонент "%": действие "%" не зарегистрировано', v_comp.name, v_comp.action;
        END IF;
        IF v_comp.type = 'grid' AND v_comp.master IS NOT NULL
           AND NOT EXISTS (SELECT 1 FROM json_array_elements(v_components) c
                           WHERE c->>'name' = v_comp.master AND c->>'type' IN ('input', 'hidden', 'lookup')) THEN
            RAISE EXCEPTION 'Таблица "%": поле-мастер "%" не найдено среди полей формы', v_comp.name, v_comp.master;
        END IF;
    END LOOP;

    IF (SELECT count(*) <> count(DISTINCT c->>'name') FROM json_array_elements(v_components) c) THEN
        RAISE EXCEPTION 'Имена компонентов должны быть уникальны';
    END IF;

    INSERT INTO erp_forms (form_name, title)
    VALUES (v_form_name, COALESCE(v_title, v_form_name))
    ON CONFLICT (form_name) DO UPDATE
        SET title = EXCLUDED.title, updated_at = now();

    DELETE FROM erp_form_components WHERE form_name = v_form_name;

    INSERT INTO erp_form_components
        (form_name, sort_order, component_type, component_name, label, action_event, master_field, tab)
    SELECT v_form_name, n, c->>'type', c->>'name', c->>'label', NULLIF(c->>'action', ''),
           CASE WHEN c->>'type' = 'grid' THEN NULLIF(c->>'master', '') END,
           CASE WHEN c->>'type' <> 'hidden' THEN NULLIF(trim(c->>'tab'), '') END
    FROM json_array_elements(v_components) WITH ORDINALITY AS t(c, n);

    RETURN ui_ok(ui_message(format('Форма "%s" сохранена', v_form_name)));
END;
$$ LANGUAGE plpgsql;


-- ---------------------------------------------------------------------
-- Примеры
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION hello_run(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_name VARCHAR := NULLIF(trim(p_data->>'user_name'), '');
BEGIN
    IF v_name IS NULL THEN
        RAISE EXCEPTION 'Введите имя';
    END IF;

    RETURN ui_ok(ui_message('Привет, ' || v_name));
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION division_run(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_a NUMERIC := division_parse(p_data->>'a', 'a');
    v_b NUMERIC := division_parse(p_data->>'b', 'b');
BEGIN
    IF v_b = 0 THEN
        RETURN ui_ok(
            ui_set_values(jsonb_build_object('result', '')),
            ui_message('Деление на ноль невозможно'));
    END IF;

    RETURN ui_ok(ui_set_values(jsonb_build_object(
        'result', replace(trim_scale(round(v_a / v_b, 10))::TEXT, '.', ','))));
END;
$$ LANGUAGE plpgsql;


-- ---------------------------------------------------------------------
-- Справочники: клиенты и товары
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION customer_select_open(p_data JSON)
RETURNS JSON AS $$
BEGIN
    RETURN ui_ok(ui_open_form('customers',
        p_title  => 'Выбор клиента',
        p_select => jsonb_build_object('value_field', 'id', 'display_field', 'name')));
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION customer_new_open(p_data JSON)
RETURNS JSON AS $$
BEGIN
    RETURN ui_ok(ui_open_form('customer', p_title => 'Новый клиент'));
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION customer_edit_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_customer erp_customers%ROWTYPE;
BEGIN
    SELECT * INTO v_customer FROM erp_customers WHERE id = ui_parse_id(p_data->>'id');
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Клиент не найден — возможно, он удалён';
    END IF;

    RETURN ui_ok(ui_open_form('customer',
        p_title => v_customer.name,
        p_data  => jsonb_build_object(
            'id', v_customer.id::TEXT,
            'name', v_customer.name,
            'phone', COALESCE(v_customer.phone, ''))));
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION customer_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_id_text TEXT    := NULLIF(trim(p_data->>'id'), '');
    v_name    VARCHAR := NULLIF(trim(p_data->>'name'), '');
    v_phone   VARCHAR := NULLIF(trim(p_data->>'phone'), '');
BEGIN
    IF v_name IS NULL THEN
        RAISE EXCEPTION 'Укажите наименование клиента';
    END IF;
    IF EXISTS (SELECT 1 FROM erp_customers
               WHERE lower(name) = lower(v_name) AND id IS DISTINCT FROM ui_parse_id(v_id_text)) THEN
        RAISE EXCEPTION 'Клиент «%» уже есть в справочнике', v_name;
    END IF;

    IF v_id_text IS NULL THEN
        INSERT INTO erp_customers (name, phone) VALUES (v_name, v_phone);
    ELSE
        UPDATE erp_customers SET name = v_name, phone = v_phone WHERE id = ui_parse_id(v_id_text);
        IF NOT FOUND THEN
            RAISE EXCEPTION 'Клиент не найден — возможно, он удалён';
        END IF;
    END IF;

    RETURN ui_ok(
        ui_close_form(),
        ui_refresh_grid('customers_grid', p_keep_page => v_id_text IS NOT NULL),
        ui_refresh_grid('orders_grid', p_keep_page => TRUE));
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION product_select_open(p_data JSON)
RETURNS JSON AS $$
BEGIN
    RETURN ui_ok(ui_open_form('products',
        p_title  => 'Выбор товара',
        p_select => jsonb_build_object(
            'value_field', 'id',
            'display_field', 'name',
            'fill', jsonb_build_object('price', 'price_input'))));
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION product_new_open(p_data JSON)
RETURNS JSON AS $$
BEGIN
    RETURN ui_ok(ui_open_form('product', p_title => 'Новый товар'));
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION product_edit_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_product erp_products%ROWTYPE;
BEGIN
    SELECT * INTO v_product FROM erp_products WHERE id = ui_parse_id(p_data->>'id');
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Товар не найден — возможно, он удалён';
    END IF;

    RETURN ui_ok(ui_open_form('product',
        p_title => v_product.name,
        p_data  => jsonb_build_object(
            'id', v_product.id::TEXT,
            'name', v_product.name,
            'price', ui_money_input(v_product.price))));
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION product_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_id_text TEXT    := NULLIF(trim(p_data->>'id'), '');
    v_name    VARCHAR := NULLIF(trim(p_data->>'name'), '');
    v_price   NUMERIC := ui_parse_money(p_data->>'price');
BEGIN
    IF v_name IS NULL THEN
        RAISE EXCEPTION 'Укажите наименование товара';
    END IF;
    IF v_price IS NULL THEN
        RAISE EXCEPTION 'Цена — число, например 1500 или 99,90';
    END IF;
    IF EXISTS (SELECT 1 FROM erp_products
               WHERE lower(name) = lower(v_name) AND id IS DISTINCT FROM ui_parse_id(v_id_text)) THEN
        RAISE EXCEPTION 'Товар «%» уже есть в справочнике', v_name;
    END IF;

    IF v_id_text IS NULL THEN
        INSERT INTO erp_products (name, price) VALUES (v_name, v_price);
    ELSE
        UPDATE erp_products SET name = v_name, price = v_price WHERE id = ui_parse_id(v_id_text);
        IF NOT FOUND THEN
            RAISE EXCEPTION 'Товар не найден — возможно, он удалён';
        END IF;
    END IF;

    RETURN ui_ok(
        ui_close_form(),
        ui_refresh_grid('products_grid', p_keep_page => v_id_text IS NOT NULL));
END;
$$ LANGUAGE plpgsql;


-- ---------------------------------------------------------------------
-- Заказ (шапка)
-- ---------------------------------------------------------------------

-- Инструкция: обновить сумму в открытой карточке заказа
DROP FUNCTION order_total_update(BIGINT);
CREATE FUNCTION order_total_update(p_order_id BIGINT)
RETURNS JSONB AS $$
    SELECT ui_set_values(jsonb_build_object('order_total', ui_format_money(COALESCE(total, 0))),
                         p_form => 'order_new')
    FROM erp_orders_v
    WHERE id = p_order_id;
$$ LANGUAGE sql STABLE;

-- После сохранения шапки: у новой записи появляется id и заголовок, так что таблицы-детали начинают работать
CREATE OR REPLACE FUNCTION order_header_saved(p_is_new BOOLEAN, p_id BIGINT)
RETURNS JSONB AS $$
    SELECT CASE WHEN p_is_new THEN
        jsonb_build_array(
            ui_set_values(jsonb_build_object('id', p_id::TEXT)),
            ui_set_title(format('Заказ №%s', p_id)),
            ui_refresh_grid('orders_grid'))
    ELSE
        jsonb_build_array(ui_refresh_grid('orders_grid', p_keep_page => TRUE))
    END;
$$ LANGUAGE sql STABLE;

-- Новый заказ открывается с нулевой суммой
CREATE OR REPLACE FUNCTION order_new_open(p_data JSON)
RETURNS JSON AS $$
BEGIN
    RETURN ui_ok(ui_open_form('order_new', jsonb_build_object('order_total', ui_format_money(0))));
END;
$$ LANGUAGE plpgsql;

-- Открытие заказа запоминает его сохранённую версию (см. V15)
CREATE OR REPLACE FUNCTION order_edit_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_order erp_orders_v%ROWTYPE;
BEGIN
    SELECT * INTO v_order FROM erp_orders_v WHERE id = ui_parse_id(p_data->>'id');
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Заказ №% не найден — возможно, он уже удалён', p_data->>'id';
    END IF;

    IF v_order.status <> 'DRAFT' THEN
        INSERT INTO erp_order_snapshots (order_id, state)
        VALUES (v_order.id, order_state(v_order.id))
        ON CONFLICT (order_id) DO NOTHING;
    END IF;

    RETURN ui_ok(ui_open_form('order_new',
        p_title => format(CASE WHEN v_order.status = 'DRAFT' THEN 'Заказ №%s (черновик)' ELSE 'Заказ №%s' END,
                          v_order.id),
        p_data  => jsonb_build_object(
            'id', v_order.id::TEXT,
            'customer_id', v_order.customer_id::TEXT,
            'customer_id__display', v_order.customer,
            'order_total', ui_format_money(v_order.total))));
END;
$$ LANGUAGE plpgsql;

-- "Сохранить": шапка, проверка заказа целиком, черновик становится заказом; окно закрывается
CREATE OR REPLACE FUNCTION order_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_is_new BOOLEAN := NULLIF(trim(p_data->>'id'), '') IS NULL;
    v_id     BIGINT  := order_upsert(p_data);
BEGIN
    IF NOT EXISTS (SELECT 1 FROM erp_order_lines WHERE order_id = v_id) THEN
        RAISE EXCEPTION 'Добавьте в заказ хотя бы одну позицию';
    END IF;

    UPDATE erp_orders SET status = 'NEW' WHERE id = v_id AND status = 'DRAFT';
    DELETE FROM erp_order_snapshots WHERE order_id = v_id;

    RETURN ui_ok(
        ui_close_form(),
        ui_refresh_grid('orders_grid', p_keep_page => NOT v_is_new),
        ui_message(format('Заказ №%s сохранён', v_id)));
END;
$$ LANGUAGE plpgsql;

-- "Отмена" (и закрытие окна): черновик удаляется, сохранённый заказ возвращается к снимку.
-- Если что-то было изменено, сначала переспрашивает.
CREATE OR REPLACE FUNCTION order_cancel(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_order    erp_orders%ROWTYPE;
    v_snapshot JSONB;
    v_changed  BOOLEAN;
    v_close    JSONB := jsonb_build_array(ui_close_form(), ui_refresh_grid('orders_grid', p_keep_page => TRUE));
BEGIN
    SELECT * INTO v_order FROM erp_orders WHERE id = ui_parse_id(p_data->>'id');
    IF NOT FOUND THEN
        -- Заказ ещё не создавался или уже удалён — отменять нечего
        RETURN ui_ok(v_close);
    END IF;

    SELECT state INTO v_snapshot FROM erp_order_snapshots WHERE order_id = v_order.id;

    v_changed := CASE
        WHEN v_order.status = 'DRAFT' THEN
            EXISTS (SELECT 1 FROM erp_order_lines WHERE order_id = v_order.id)
            OR EXISTS (SELECT 1 FROM erp_order_payments WHERE order_id = v_order.id)
        ELSE
            -- Клиент берётся из формы: его смена ещё не записана в базу
            v_snapshot IS NOT NULL
            AND v_snapshot IS DISTINCT FROM order_state(v_order.id)
                || jsonb_build_object('customer_id', ui_parse_id(p_data->>'customer_id'))
    END;

    IF v_changed AND (p_data->>'confirmed') IS DISTINCT FROM 'true' THEN
        RETURN ui_ok(ui_confirm(
            CASE WHEN v_order.status = 'DRAFT'
                THEN format('Закрыть без сохранения? Черновик заказа №%s с позициями и оплатами будет удалён.',
                            v_order.id)
                ELSE format('Закрыть без сохранения? Изменения в заказе №%s будут отменены.', v_order.id)
            END,
            'order_cancel',
            jsonb_build_object('id', v_order.id::TEXT, 'customer_id', p_data->>'customer_id', 'confirmed', TRUE),
            p_confirm_label => 'Не сохранять'));
    END IF;

    IF v_order.status = 'DRAFT' THEN
        DELETE FROM erp_orders WHERE id = v_order.id;  -- позиции и оплаты удаляются каскадно
    ELSIF v_snapshot IS NOT NULL THEN
        PERFORM order_restore(v_order.id, v_snapshot);
        DELETE FROM erp_order_snapshots WHERE order_id = v_order.id;
    END IF;

    RETURN ui_ok(v_close);
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION order_delete(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_order erp_orders_v%ROWTYPE;
BEGIN
    SELECT * INTO v_order FROM erp_orders_v WHERE id = ui_parse_id(p_data->>'id');
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Заказ №% не найден — возможно, он уже удалён', p_data->>'id';
    END IF;

    IF (p_data->>'confirmed') IS DISTINCT FROM 'true' THEN
        RETURN ui_ok(ui_confirm(
            format('Удалить заказ №%s?' || E'\n' || '%s — позиций: %s, сумма %s',
                   v_order.id, v_order.customer, v_order.lines_count, ui_format_money(v_order.total)),
            'order_delete',
            jsonb_build_object('id', v_order.id, 'confirmed', TRUE),
            p_confirm_label => 'Удалить'));
    END IF;

    DELETE FROM erp_orders WHERE id = v_order.id;  -- позиции и оплаты удаляются каскадно

    RETURN ui_ok(
        ui_refresh_grid('orders_grid', p_keep_page => TRUE),
        ui_message(format('Заказ №%s удалён', v_order.id)));
END;
$$ LANGUAGE plpgsql;


-- ---------------------------------------------------------------------
-- Позиции заказа
-- ---------------------------------------------------------------------

-- "Добавить позицию": у нового заказа сначала сохраняется шапка (черновиком)
CREATE OR REPLACE FUNCTION order_line_new_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_is_new BOOLEAN := NULLIF(trim(p_data->>'id'), '') IS NULL;
    v_id     BIGINT  := order_upsert(p_data);
BEGIN
    RETURN ui_ok(
        order_header_saved(v_is_new, v_id),
        ui_open_form('order_line',
            p_title => 'Новая позиция',
            p_data  => jsonb_build_object('order_id', v_id::TEXT, 'quantity', '1')));
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION order_line_edit_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_line erp_order_lines_v%ROWTYPE;
BEGIN
    SELECT * INTO v_line FROM erp_order_lines_v WHERE id = ui_parse_id(p_data->>'id');
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Позиция не найдена — возможно, она уже удалена';
    END IF;

    RETURN ui_ok(ui_open_form('order_line',
        p_title => format('Позиция: %s', v_line.product),
        p_data  => jsonb_build_object(
            'id', v_line.id::TEXT,
            'order_id', v_line.order_id::TEXT,
            'product_id', v_line.product_id::TEXT,
            'product_id__display', v_line.product,
            'quantity', v_line.quantity::TEXT,
            'price', ui_money_input(v_line.price))));
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION order_line_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_id_text  TEXT    := NULLIF(trim(p_data->>'id'), '');
    v_order    BIGINT  := ui_parse_id(p_data->>'order_id');
    v_product  BIGINT  := ui_parse_id(p_data->>'product_id');
    v_quantity TEXT    := trim(p_data->>'quantity');
    v_price    NUMERIC := ui_parse_money(p_data->>'price');
BEGIN
    IF v_order IS NULL OR NOT EXISTS (SELECT 1 FROM erp_orders WHERE id = v_order) THEN
        RAISE EXCEPTION 'Заказ не найден — возможно, он уже удалён';
    END IF;
    IF v_product IS NULL OR NOT EXISTS (SELECT 1 FROM erp_products WHERE id = v_product) THEN
        RAISE EXCEPTION 'Выберите товар';
    END IF;
    IF v_quantity IS NULL OR v_quantity !~ '^[1-9]\d{0,5}$' THEN
        RAISE EXCEPTION 'Количество — целое число больше нуля';
    END IF;
    IF v_price IS NULL THEN
        RAISE EXCEPTION 'Цена — число, например 1500 или 99,90';
    END IF;

    IF v_id_text IS NULL THEN
        INSERT INTO erp_order_lines (order_id, product_id, quantity, price)
        VALUES (v_order, v_product, v_quantity::INT, v_price);
    ELSE
        UPDATE erp_order_lines
        SET product_id = v_product, quantity = v_quantity::INT, price = v_price
        WHERE id = ui_parse_id(v_id_text) AND order_id = v_order;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'Позиция не найдена — возможно, она уже удалена';
        END IF;
    END IF;

    RETURN ui_ok(
        ui_close_form(),
        ui_refresh_grid('order_lines_grid', p_keep_page => TRUE),
        ui_refresh_grid('orders_grid', p_keep_page => TRUE),
        order_total_update(v_order));
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION order_line_delete(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_line erp_order_lines_v%ROWTYPE;
BEGIN
    SELECT * INTO v_line FROM erp_order_lines_v WHERE id = ui_parse_id(p_data->>'id');
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Позиция не найдена — возможно, она уже удалена';
    END IF;

    IF (p_data->>'confirmed') IS DISTINCT FROM 'true' THEN
        RETURN ui_ok(ui_confirm(
            format('Удалить позицию «%s», %s шт. на сумму %s?',
                   v_line.product, v_line.quantity, ui_format_money(v_line.total)),
            'order_line_delete',
            jsonb_build_object('id', v_line.id, 'confirmed', TRUE),
            p_confirm_label => 'Удалить'));
    END IF;

    DELETE FROM erp_order_lines WHERE id = v_line.id;

    RETURN ui_ok(
        ui_refresh_grid('order_lines_grid', p_keep_page => TRUE),
        ui_refresh_grid('orders_grid', p_keep_page => TRUE),
        order_total_update(v_line.order_id));
END;
$$ LANGUAGE plpgsql;


-- ---------------------------------------------------------------------
-- Оплаты заказа
-- ---------------------------------------------------------------------

-- "Добавить оплату": по умолчанию предлагается неоплаченный остаток
CREATE OR REPLACE FUNCTION order_payment_new_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_is_new BOOLEAN := NULLIF(trim(p_data->>'id'), '') IS NULL;
    v_id     BIGINT  := order_upsert(p_data);
    v_rest   NUMERIC;
BEGIN
    SELECT total - paid INTO v_rest FROM erp_orders_v WHERE id = v_id;

    RETURN ui_ok(
        order_header_saved(v_is_new, v_id),
        ui_open_form('order_payment',
            p_title => format('Оплата заказа №%s', v_id),
            p_data  => jsonb_build_object(
                'order_id', v_id::TEXT,
                'paid_on', to_char(current_date, 'DD.MM.YYYY'),
                'amount', CASE WHEN v_rest > 0 THEN ui_money_input(v_rest) ELSE '' END)));
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION order_payment_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_order     BIGINT  := ui_parse_id(p_data->>'order_id');
    v_date_text TEXT    := trim(p_data->>'paid_on');
    v_amount    NUMERIC := ui_parse_money(p_data->>'amount');
    v_date      DATE;
BEGIN
    IF v_order IS NULL OR NOT EXISTS (SELECT 1 FROM erp_orders WHERE id = v_order) THEN
        RAISE EXCEPTION 'Заказ не найден — возможно, он уже удалён';
    END IF;
    IF v_date_text IS NULL OR v_date_text !~ '^\d{2}\.\d{2}\.\d{4}$' THEN
        RAISE EXCEPTION 'Дата оплаты — в формате ДД.ММ.ГГГГ';
    END IF;
    BEGIN
        v_date := to_date(v_date_text, 'DD.MM.YYYY');
    EXCEPTION WHEN OTHERS THEN
        RAISE EXCEPTION 'Дата оплаты — в формате ДД.ММ.ГГГГ';
    END;
    IF v_amount IS NULL OR v_amount <= 0 THEN
        RAISE EXCEPTION 'Сумма оплаты — число больше нуля';
    END IF;

    INSERT INTO erp_order_payments (order_id, paid_on, amount) VALUES (v_order, v_date, v_amount);

    RETURN ui_ok(
        ui_close_form(),
        ui_refresh_grid('order_payments_grid', p_keep_page => TRUE),
        ui_refresh_grid('orders_grid', p_keep_page => TRUE));
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION order_payment_delete(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_payment erp_order_payments_v%ROWTYPE;
BEGIN
    SELECT * INTO v_payment FROM erp_order_payments_v WHERE id = ui_parse_id(p_data->>'id');
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Оплата не найдена — возможно, она уже удалена';
    END IF;

    IF (p_data->>'confirmed') IS DISTINCT FROM 'true' THEN
        RETURN ui_ok(ui_confirm(
            format('Удалить оплату от %s на сумму %s?', v_payment.paid_date, ui_format_money(v_payment.amount)),
            'order_payment_delete',
            jsonb_build_object('id', v_payment.id, 'confirmed', TRUE),
            p_confirm_label => 'Удалить'));
    END IF;

    DELETE FROM erp_order_payments WHERE id = v_payment.id;

    RETURN ui_ok(
        ui_refresh_grid('order_payments_grid', p_keep_page => TRUE),
        ui_refresh_grid('orders_grid', p_keep_page => TRUE));
END;
$$ LANGUAGE plpgsql;
