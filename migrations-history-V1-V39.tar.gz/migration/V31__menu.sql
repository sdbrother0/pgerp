-- =====================================================================
-- Меню приложения: пункты с произвольной вложенностью.
--   * pgerp.menu_items — дерево пунктов (parent_id); у пункта может быть форма, которая
--     открывается при переходе к нему. Пункт с подпунктами — раскрывающаяся группа.
--   * menu_get  (системное) — меню деревом: {items: [{id, title, form, items: [...]}]};
--   * menu_save (системное) — сохранение меню целиком из редактора.
--
-- Режим «Формы» показывает слева меню вместо списка всех форм. Меню заполняется
-- из текущих папок и форм, чтобы после обновления набор пунктов не изменился.
-- =====================================================================

CREATE TABLE pgerp.menu_items (
    id         BIGSERIAL    PRIMARY KEY,
    parent_id  BIGINT       REFERENCES pgerp.menu_items ON DELETE CASCADE,
    sort_order INT          NOT NULL,
    title      VARCHAR(200) NOT NULL CHECK (trim(title) <> ''),
    -- Удаление формы оставляет пункт без формы; пункт можно перенастроить в редакторе меню
    form_name  VARCHAR(50)  REFERENCES pgerp.forms ON UPDATE CASCADE ON DELETE SET NULL
);
CREATE INDEX ON pgerp.menu_items (parent_id, sort_order);
CREATE INDEX ON pgerp.menu_items (form_name);


-- Уровень меню с подпунктами: [{id, title, form, items: [...]}] по порядку
CREATE FUNCTION pgerp.ui_menu_level(p_parent BIGINT)
RETURNS JSON AS $$
BEGIN
    RETURN COALESCE((
        SELECT json_agg(json_build_object(
                   'id', m.id,
                   'title', m.title,
                   'form', m.form_name,
                   'items', pgerp.ui_menu_level(m.id))
               ORDER BY m.sort_order, m.id)
        FROM pgerp.menu_items m
        WHERE m.parent_id IS NOT DISTINCT FROM p_parent), '[]'::json);
END;
$$ LANGUAGE plpgsql STABLE;

CREATE FUNCTION pgerp.ui_menu_get(p_data JSON)
RETURNS JSON AS $$
    SELECT json_build_object('status', 'success', 'items', pgerp.ui_menu_level(NULL));
$$ LANGUAGE sql STABLE;


-- Вставка уровня меню из редактора; p_path — путь к уровню для текста ошибок ("Заказы › Справочники")
CREATE FUNCTION pgerp.ui_menu_insert(p_items JSON, p_parent BIGINT, p_path TEXT)
RETURNS VOID AS $$
DECLARE
    v_item  RECORD;
    v_title TEXT;
    v_form  TEXT;
    v_path  TEXT;
    v_id    BIGINT;
BEGIN
    IF p_items IS NULL OR json_typeof(p_items) = 'null' THEN
        RETURN;
    END IF;
    PERFORM ui_require(json_typeof(p_items) = 'array', 'Меню: пункты передаются списком');

    FOR v_item IN
        SELECT i, n FROM json_array_elements(p_items) WITH ORDINALITY AS t(i, n)
    LOOP
        v_title := NULLIF(trim(v_item.i->>'title'), '');
        v_form  := NULLIF(v_item.i->>'form', '');
        v_path  := concat_ws(' › ', p_path, COALESCE(v_title, format('пункт №%s', v_item.n)));

        PERFORM ui_require(v_title IS NOT NULL, format('Меню, %s: укажите название пункта', v_path));
        PERFORM ui_require(length(v_title) <= 200, format('Меню, %s: название длиннее 200 символов', v_path));
        PERFORM ui_require(v_form IS NULL OR EXISTS (SELECT 1 FROM pgerp.forms WHERE form_name = v_form),
                           format('Меню, %s: формы "%s" нет', v_path, v_form));

        INSERT INTO pgerp.menu_items (parent_id, sort_order, title, form_name)
        VALUES (p_parent, v_item.n, v_title, v_form)
        RETURNING id INTO v_id;

        PERFORM pgerp.ui_menu_insert(v_item.i->'items', v_id, v_path);
    END LOOP;
END;
$$ LANGUAGE plpgsql;

-- {"items": [{title, form, items: [...]}]} — меню заменяется целиком
CREATE FUNCTION pgerp.ui_menu_save(p_data JSON)
RETURNS JSON AS $$
BEGIN
    -- Два одновременных сохранения не должны сложить два меню
    LOCK TABLE pgerp.menu_items IN EXCLUSIVE MODE;
    DELETE FROM pgerp.menu_items;
    PERFORM pgerp.ui_menu_insert(COALESCE(p_data->'items', '[]'::json), NULL, NULL);

    RETURN ui_ok(ui_message('Меню сохранено'));
END;
$$ LANGUAGE plpgsql;

INSERT INTO pgerp.ui_actions (action_name, function_name, description, is_system) VALUES
    ('menu_get',  'pgerp.ui_menu_get',  'Меню приложения',     TRUE),
    ('menu_save', 'pgerp.ui_menu_save', 'Сохранение меню',     TRUE);


-- ---------------------------------------------------------------------
-- Начальное меню — как прежний список форм: папки (группы) по алфавиту, в них формы
-- по заголовку, затем формы без папки
-- ---------------------------------------------------------------------
INSERT INTO pgerp.menu_items (parent_id, sort_order, title)
SELECT NULL, row_number() OVER (ORDER BY folder), folder
FROM (SELECT DISTINCT folder FROM pgerp.forms WHERE folder IS NOT NULL) f;

INSERT INTO pgerp.menu_items (parent_id, sort_order, title, form_name)
SELECT g.id, row_number() OVER (PARTITION BY g.id ORDER BY f.title), f.title, f.form_name
FROM pgerp.forms f
JOIN pgerp.menu_items g ON g.parent_id IS NULL AND g.title = f.folder;

INSERT INTO pgerp.menu_items (parent_id, sort_order, title, form_name)
SELECT NULL,
       (SELECT count(*) FROM pgerp.menu_items WHERE parent_id IS NULL) + row_number() OVER (ORDER BY title),
       title, form_name
FROM pgerp.forms
WHERE folder IS NULL;
