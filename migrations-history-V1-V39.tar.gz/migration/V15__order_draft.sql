-- =====================================================================
-- Заказ как документ: "Сохранить" / "Отмена".
--
--  * Новый заказ создаётся черновиком (status = 'DRAFT') при первом добавлении
--    позиции или оплаты. "Сохранить" переводит его в NEW, "Отмена" — удаляет.
--  * При открытии сохранённого заказа запоминается его снимок (шапка, позиции, оплаты).
--    Позиции и оплаты по-прежнему пишутся сразу, но "Отмена" возвращает заказ к снимку,
--    а "Сохранить" снимок удаляет.
--  * erp_forms.cancel_action — действие, которое клиент вызывает при закрытии
--    модального окна крестиком или Escape, как по кнопке "Отмена".
-- =====================================================================

-- ---------------------------------------------------------------------
-- Метаданные форм: действие отмены
-- ---------------------------------------------------------------------
ALTER TABLE erp_forms ADD COLUMN cancel_action VARCHAR(100) REFERENCES erp_ui_actions (action_name);

CREATE OR REPLACE FUNCTION ui_form_get(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_form_name VARCHAR := p_data->>'form';
    v_form      JSON;
BEGIN
    SELECT json_build_object(
               'name', f.form_name,
               'title', f.title,
               'cancel', f.cancel_action,
               'components', COALESCE((
                   SELECT json_agg(json_build_object(
                              'type', c.component_type,
                              'name', c.component_name,
                              'label', c.label,
                              'action', c.action_event,
                              'master', c.master_field,
                              'tab', c.tab)
                          ORDER BY c.sort_order)
                   FROM erp_form_components c
                   WHERE c.form_name = f.form_name), '[]'::json))
    INTO v_form
    FROM erp_forms f
    WHERE f.form_name = v_form_name;

    IF v_form IS NULL THEN
        RAISE EXCEPTION 'Форма "%" не найдена', v_form_name;
    END IF;

    RETURN json_build_object('status', 'success', 'form', v_form);
END;
$$ LANGUAGE plpgsql;


-- ---------------------------------------------------------------------
-- Черновики и снимки заказов
-- ---------------------------------------------------------------------
ALTER TABLE erp_orders DROP CONSTRAINT erp_orders_status_check;
ALTER TABLE erp_orders ADD CONSTRAINT erp_orders_status_check
    CHECK (status IN ('DRAFT', 'NEW', 'PAID', 'SHIPPED'));

-- Последняя сохранённая версия заказа, открытого на редактирование
CREATE TABLE erp_order_snapshots (
    order_id   BIGINT      PRIMARY KEY REFERENCES erp_orders ON DELETE CASCADE,
    state      JSONB       NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Состояние заказа целиком: шапка, позиции и оплаты
CREATE FUNCTION order_state(p_id BIGINT)
RETURNS JSONB AS $$
    SELECT jsonb_build_object(
        'customer_id', o.customer_id,
        'lines', COALESCE((
            SELECT jsonb_agg(jsonb_build_object(
                       'id', l.id, 'product_id', l.product_id, 'quantity', l.quantity, 'price', l.price)
                   ORDER BY l.id)
            FROM erp_order_lines l
            WHERE l.order_id = o.id), '[]'::jsonb),
        'payments', COALESCE((
            SELECT jsonb_agg(jsonb_build_object('id', p.id, 'paid_on', p.paid_on, 'amount', p.amount)
                   ORDER BY p.id)
            FROM erp_order_payments p
            WHERE p.order_id = o.id), '[]'::jsonb))
    FROM erp_orders o
    WHERE o.id = p_id;
$$ LANGUAGE sql STABLE;

-- Возврат заказа к снимку; позиции и оплаты восстанавливаются с прежними id
CREATE FUNCTION order_restore(p_id BIGINT, p_state JSONB)
RETURNS VOID AS $$
BEGIN
    UPDATE erp_orders SET customer_id = (p_state->>'customer_id')::BIGINT WHERE id = p_id;

    DELETE FROM erp_order_lines WHERE order_id = p_id;
    INSERT INTO erp_order_lines (id, order_id, product_id, quantity, price)
    SELECT id, p_id, product_id, quantity, price
    FROM jsonb_to_recordset(p_state->'lines') AS t(id BIGINT, product_id BIGINT, quantity INT, price NUMERIC);

    DELETE FROM erp_order_payments WHERE order_id = p_id;
    INSERT INTO erp_order_payments (id, order_id, paid_on, amount)
    SELECT id, p_id, paid_on, amount
    FROM jsonb_to_recordset(p_state->'payments') AS t(id BIGINT, paid_on DATE, amount NUMERIC);
END;
$$ LANGUAGE plpgsql;


-- Новый заказ сохраняется в базе черновиком
CREATE OR REPLACE FUNCTION order_upsert(p_data JSON)
RETURNS BIGINT AS $$
DECLARE
    v_id_text  TEXT   := NULLIF(trim(p_data->>'id'), '');
    v_customer BIGINT := ui_parse_id(p_data->>'customer_id');
    v_id       BIGINT;
BEGIN
    IF v_customer IS NULL THEN
        RAISE EXCEPTION 'Выберите клиента';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM erp_customers WHERE id = v_customer) THEN
        RAISE EXCEPTION 'Клиент не найден — возможно, он удалён';
    END IF;

    IF v_id_text IS NULL THEN
        INSERT INTO erp_orders (customer_id, status) VALUES (v_customer, 'DRAFT') RETURNING id INTO v_id;
        RETURN v_id;
    END IF;

    UPDATE erp_orders SET customer_id = v_customer
    WHERE id = ui_parse_id(v_id_text)
    RETURNING id INTO v_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Заказ №% не найден — возможно, он уже удалён', v_id_text;
    END IF;
    RETURN v_id;
END;
$$ LANGUAGE plpgsql;


-- Открытие заказа запоминает его сохранённую версию. Если снимок уже есть
-- (прошлое редактирование не завершили), он остаётся: "Отмена" вернёт к последнему сохранению.
CREATE OR REPLACE FUNCTION order_edit_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_order erp_orders_v%ROWTYPE;
BEGIN
    SELECT * INTO v_order FROM erp_orders_v WHERE id = ui_parse_id(p_data->>'id');
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Заказ №% не найден — возможно, он уже удалён', p_data->>'id';
    END IF;

    IF v_order.status <> 'DRAFT' THEN
        INSERT INTO erp_order_snapshots (order_id, state)
        VALUES (v_order.id, order_state(v_order.id))
        ON CONFLICT (order_id) DO NOTHING;
    END IF;

    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_object(
            'command', 'open_form',
            'form', 'order_new',
            'modal', TRUE,
            'title', format(CASE WHEN v_order.status = 'DRAFT' THEN 'Заказ №%s (черновик)' ELSE 'Заказ №%s' END,
                            v_order.id),
            'data', json_build_object(
                'id', v_order.id::TEXT,
                'customer_id', v_order.customer_id::TEXT,
                'customer_id__display', v_order.customer,
                'order_total', ui_format_money(v_order.total))));
END;
$$ LANGUAGE plpgsql;


-- "Сохранить": шапка, проверка заказа целиком, черновик становится заказом; окно закрывается
CREATE OR REPLACE FUNCTION order_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_is_new BOOLEAN := NULLIF(trim(p_data->>'id'), '') IS NULL;
    v_id     BIGINT  := order_upsert(p_data);
BEGIN
    IF NOT EXISTS (SELECT 1 FROM erp_order_lines WHERE order_id = v_id) THEN
        RAISE EXCEPTION 'Добавьте в заказ хотя бы одну позицию';
    END IF;

    UPDATE erp_orders SET status = 'NEW' WHERE id = v_id AND status = 'DRAFT';
    DELETE FROM erp_order_snapshots WHERE order_id = v_id;

    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_array(
            json_build_object('command', 'close_form'),
            json_build_object('command', 'refresh_grid', 'grid', 'orders_grid', 'keep_page', NOT v_is_new),
            json_build_object('command', 'show_message', 'text', format('Заказ №%s сохранён', v_id))));
END;
$$ LANGUAGE plpgsql;


-- "Отмена" (и закрытие окна): черновик удаляется, сохранённый заказ возвращается к снимку.
-- Если что-то было изменено, сначала переспрашивает.
CREATE FUNCTION order_cancel(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_order    erp_orders%ROWTYPE;
    v_snapshot JSONB;
    v_changed  BOOLEAN;
    v_close    JSON := json_build_array(
        json_build_object('command', 'close_form'),
        json_build_object('command', 'refresh_grid', 'grid', 'orders_grid', 'keep_page', TRUE));
BEGIN
    SELECT * INTO v_order FROM erp_orders WHERE id = ui_parse_id(p_data->>'id');
    IF NOT FOUND THEN
        -- Заказ ещё не создавался или уже удалён — отменять нечего
        RETURN json_build_object('status', 'success', 'ui_instructions', v_close);
    END IF;

    SELECT state INTO v_snapshot FROM erp_order_snapshots WHERE order_id = v_order.id;

    v_changed := CASE
        WHEN v_order.status = 'DRAFT' THEN
            EXISTS (SELECT 1 FROM erp_order_lines WHERE order_id = v_order.id)
            OR EXISTS (SELECT 1 FROM erp_order_payments WHERE order_id = v_order.id)
        ELSE
            -- Клиент берётся из формы: его смена ещё не записана в базу
            v_snapshot IS NOT NULL
            AND v_snapshot IS DISTINCT FROM order_state(v_order.id)
                || jsonb_build_object('customer_id', ui_parse_id(p_data->>'customer_id'))
    END;

    IF v_changed AND (p_data->>'confirmed') IS DISTINCT FROM 'true' THEN
        RETURN json_build_object(
            'status', 'success',
            'ui_instructions', json_build_object(
                'command', 'confirm',
                'text', CASE WHEN v_order.status = 'DRAFT'
                            THEN format('Закрыть без сохранения? Черновик заказа №%s с позициями и оплатами будет удалён.',
                                        v_order.id)
                            ELSE format('Закрыть без сохранения? Изменения в заказе №%s будут отменены.', v_order.id)
                        END,
                'confirm_label', 'Не сохранять',
                'action', 'order_cancel',
                'data', json_build_object('id', v_order.id::TEXT,
                                          'customer_id', p_data->>'customer_id',
                                          'confirmed', TRUE)));
    END IF;

    IF v_order.status = 'DRAFT' THEN
        DELETE FROM erp_orders WHERE id = v_order.id;  -- позиции и оплаты удаляются каскадно
    ELSIF v_snapshot IS NOT NULL THEN
        PERFORM order_restore(v_order.id, v_snapshot);
        DELETE FROM erp_order_snapshots WHERE order_id = v_order.id;
    END IF;

    RETURN json_build_object('status', 'success', 'ui_instructions', v_close);
END;
$$ LANGUAGE plpgsql;

INSERT INTO erp_ui_actions (action_name, function_name, description)
VALUES ('order_cancel', 'order_cancel', 'Отмена изменений заказа: черновик удаляется, заказ возвращается к сохранённому');


-- Кнопки карточки заказа: "Сохранить" и "Отмена"; закрытие окна — тоже отмена
UPDATE erp_form_components SET label = 'Отмена', action_event = 'order_cancel'
WHERE form_name = 'order_new' AND component_name = 'btn_close';

UPDATE erp_forms SET cancel_action = 'order_cancel', updated_at = now() WHERE form_name = 'order_new';
