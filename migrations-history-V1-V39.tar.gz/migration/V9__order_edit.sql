-- =====================================================================
-- Редактирование заказа той же модальной формой order_new.
-- Новый тип компонента 'hidden' (скрытое поле, например id записи);
-- инструкция open_form может передать данные для заполнения полей и заголовок.
-- =====================================================================

-- Единый перечень типов компонентов (раньше был продублирован в ui_form_save).
CREATE FUNCTION ui_component_types()
RETURNS VARCHAR[] AS $$
    SELECT ARRAY['label', 'input', 'hidden', 'button', 'grid']::VARCHAR[];
$$ LANGUAGE sql IMMUTABLE;

ALTER TABLE erp_form_components DROP CONSTRAINT erp_form_components_component_type_check;
ALTER TABLE erp_form_components ADD CONSTRAINT erp_form_components_component_type_check
    CHECK (component_type = ANY (ui_component_types()));


CREATE OR REPLACE FUNCTION ui_form_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_form_name VARCHAR := p_data->>'name';
    v_title     VARCHAR := NULLIF(trim(p_data->>'title'), '');
    v_comp      RECORD;
BEGIN
    IF v_form_name IS NULL OR v_form_name !~ '^[a-z_][a-z0-9_]*$' THEN
        RAISE EXCEPTION 'Имя формы: латинские буквы в нижнем регистре, цифры и "_"';
    END IF;

    FOR v_comp IN
        SELECT c->>'type' AS type, c->>'name' AS name, NULLIF(c->>'action', '') AS action, n
        FROM json_array_elements(COALESCE(p_data->'components', '[]'::json)) WITH ORDINALITY AS t(c, n)
    LOOP
        IF v_comp.type IS NULL OR NOT v_comp.type = ANY (ui_component_types()) THEN
            RAISE EXCEPTION 'Компонент №%: неизвестный тип "%"', v_comp.n, v_comp.type;
        END IF;
        IF v_comp.name IS NULL OR v_comp.name !~ '^[a-z_][a-z0-9_]*$' THEN
            RAISE EXCEPTION 'Компонент №%: имя — латинские буквы в нижнем регистре, цифры и "_"', v_comp.n;
        END IF;
        IF v_comp.type = 'grid' AND v_comp.action IS NULL THEN
            RAISE EXCEPTION 'Таблица "%": выберите действие-источник данных', v_comp.name;
        END IF;
        IF v_comp.action IS NOT NULL
           AND NOT EXISTS (SELECT 1 FROM erp_ui_actions WHERE action_name = v_comp.action AND NOT is_system) THEN
            RAISE EXCEPTION 'Компонент "%": действие "%" не зарегистрировано', v_comp.name, v_comp.action;
        END IF;
    END LOOP;

    IF (SELECT count(*) <> count(DISTINCT c->>'name')
        FROM json_array_elements(COALESCE(p_data->'components', '[]'::json)) c) THEN
        RAISE EXCEPTION 'Имена компонентов должны быть уникальны';
    END IF;

    INSERT INTO erp_forms (form_name, title)
    VALUES (v_form_name, COALESCE(v_title, v_form_name))
    ON CONFLICT (form_name) DO UPDATE
        SET title = EXCLUDED.title, updated_at = now();

    DELETE FROM erp_form_components WHERE form_name = v_form_name;

    INSERT INTO erp_form_components (form_name, sort_order, component_type, component_name, label, action_event)
    SELECT v_form_name, n, c->>'type', c->>'name', c->>'label', NULLIF(c->>'action', '')
    FROM json_array_elements(COALESCE(p_data->'components', '[]'::json)) WITH ORDINALITY AS t(c, n);

    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_object(
            'command', 'show_message',
            'text', format('Форма "%s" сохранена', v_form_name)));
END;
$$ LANGUAGE plpgsql;


-- Сохранение заказа: без id — создание, с id — изменение существующего.
CREATE FUNCTION order_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_id_text  VARCHAR := NULLIF(trim(p_data->>'id'), '');
    v_customer VARCHAR := NULLIF(trim(p_data->>'customer_name'), '');
    v_product  VARCHAR := NULLIF(trim(p_data->>'product_name'), '');
    v_quantity VARCHAR := trim(p_data->>'quantity');
    v_price    VARCHAR := replace(replace(trim(p_data->>'price'), ' ', ''), ',', '.');
    v_id       BIGINT;
BEGIN
    IF v_customer IS NULL THEN
        RAISE EXCEPTION 'Укажите клиента';
    END IF;
    IF v_product IS NULL THEN
        RAISE EXCEPTION 'Укажите товар';
    END IF;
    IF v_quantity IS NULL OR v_quantity !~ '^[1-9]\d{0,5}$' THEN
        RAISE EXCEPTION 'Количество — целое число больше нуля';
    END IF;
    IF v_price IS NULL OR v_price !~ '^\d{1,10}(\.\d{1,2})?$' THEN
        RAISE EXCEPTION 'Цена — число, например 1500 или 99,90';
    END IF;

    IF v_id_text IS NULL THEN
        INSERT INTO erp_orders (customer_name, product_name, quantity, price)
        VALUES (v_customer, v_product, v_quantity::INT, v_price::NUMERIC)
        RETURNING id INTO v_id;

        RETURN json_build_object(
            'status', 'success',
            'ui_instructions', json_build_array(
                json_build_object('command', 'close_form'),
                json_build_object('command', 'refresh_grid', 'grid', 'orders_grid'),
                json_build_object('command', 'show_message', 'text', format('Заказ №%s создан', v_id))));
    END IF;

    IF v_id_text !~ '^\d{1,18}$' THEN
        RAISE EXCEPTION 'Некорректный номер заказа';
    END IF;

    UPDATE erp_orders
    SET customer_name = v_customer,
        product_name  = v_product,
        quantity      = v_quantity::INT,
        price         = v_price::NUMERIC
    WHERE id = v_id_text::BIGINT
    RETURNING id INTO v_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Заказ №% не найден — возможно, он уже удалён', v_id_text;
    END IF;

    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_array(
            json_build_object('command', 'close_form'),
            json_build_object('command', 'refresh_grid', 'grid', 'orders_grid', 'keep_page', TRUE),
            json_build_object('command', 'show_message', 'text', format('Заказ №%s сохранён', v_id))));
END;
$$ LANGUAGE plpgsql;

-- Совместимость: order_create всегда создаёт новый заказ.
CREATE OR REPLACE FUNCTION order_create(p_data JSON)
RETURNS JSON AS $$
BEGIN
    RETURN order_save((p_data::JSONB - 'id')::JSON);
END;
$$ LANGUAGE plpgsql;

-- Кнопка "Изменить" в строке таблицы: открыть форму заказа с заполненными полями.
CREATE FUNCTION order_edit_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_order erp_orders%ROWTYPE;
BEGIN
    IF p_data->>'id' IS NULL OR p_data->>'id' !~ '^\d{1,18}$' THEN
        RAISE EXCEPTION 'Не указан заказ';
    END IF;

    SELECT * INTO v_order FROM erp_orders WHERE id = (p_data->>'id')::BIGINT;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Заказ №% не найден — возможно, он уже удалён', p_data->>'id';
    END IF;

    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_object(
            'command', 'open_form',
            'form', 'order_new',
            'modal', TRUE,
            'title', format('Заказ №%s', v_order.id),
            'data', json_build_object(
                'id', v_order.id::TEXT,
                'customer_name', v_order.customer_name,
                'product_name', v_order.product_name,
                'quantity', v_order.quantity::TEXT,
                'price', translate(v_order.price::TEXT, '.', ','))));
END;
$$ LANGUAGE plpgsql;


INSERT INTO erp_ui_actions (action_name, function_name, description) VALUES
    ('order_save',      'order_save',      'Сохранение заказа: создание (без id) или изменение'),
    ('order_edit_open', 'order_edit_open', 'Открыть форму заказа для редактирования');

INSERT INTO erp_grid_row_actions (source_action, sort_order, row_action, label, style)
VALUES ('orders_page', 0, 'order_edit_open', 'Изменить', 'default');

-- Форма заказа: скрытое поле id и кнопка "Сохранить" вместо "Создать"
INSERT INTO erp_form_components (form_name, sort_order, component_type, component_name, label, action_event)
VALUES ('order_new', 0, 'hidden', 'id', NULL, NULL);

UPDATE erp_form_components
SET label = 'Сохранить', action_event = 'order_save'
WHERE form_name = 'order_new' AND component_name = 'btn_create';

UPDATE erp_forms SET updated_at = now() WHERE form_name = 'order_new';
