-- =====================================================================
-- Денежный формат для текстов UI: "1 234 567,50" независимо от lc_numeric.
-- =====================================================================

CREATE FUNCTION ui_format_money(p_value NUMERIC)
RETURNS TEXT AS $$
    -- Фиксированные разделители в шаблоне, затем замена на русские
    SELECT translate(to_char(p_value, 'FM999,999,999,999,990.00'), ',.', ' ,');
$$ LANGUAGE sql IMMUTABLE;

CREATE OR REPLACE FUNCTION order_delete(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_order erp_orders%ROWTYPE;
BEGIN
    IF p_data->>'id' IS NULL OR p_data->>'id' !~ '^\d{1,18}$' THEN
        RAISE EXCEPTION 'Не указан заказ';
    END IF;

    SELECT * INTO v_order FROM erp_orders WHERE id = (p_data->>'id')::BIGINT;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Заказ №% не найден — возможно, он уже удалён', p_data->>'id';
    END IF;

    IF (p_data->>'confirmed') IS DISTINCT FROM 'true' THEN
        RETURN json_build_object(
            'status', 'success',
            'ui_instructions', json_build_object(
                'command', 'confirm',
                'text', format('Удалить заказ №%s?' || E'\n' || '%s — %s, %s шт., сумма %s',
                               v_order.id, v_order.customer_name, v_order.product_name, v_order.quantity,
                               ui_format_money(v_order.quantity * v_order.price)),
                'confirm_label', 'Удалить',
                'action', 'order_delete',
                'data', json_build_object('id', v_order.id, 'confirmed', TRUE)));
    END IF;

    DELETE FROM erp_orders WHERE id = v_order.id;

    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_array(
            json_build_object('command', 'refresh_grid', 'grid', 'orders_grid', 'keep_page', TRUE),
            json_build_object('command', 'show_message', 'text', format('Заказ №%s удалён', v_order.id))));
END;
$$ LANGUAGE plpgsql;
