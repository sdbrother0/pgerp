-- =====================================================================
-- Таблицы без префикса erp_: таблицы ядра — в схеме erp (рядом с функциями ядра, V23),
-- прикладные — в public.
--
--   erp:  erp_forms            → erp.forms
--         erp_form_components  → erp.form_components
--         erp_ui_actions       → erp.ui_actions
--         erp_grid_columns     → erp.grid_columns
--         erp_grid_row_actions → erp.grid_row_actions
--
--   public: erp_customers → customers,  erp_products → products,  erp_orders → orders,
--           erp_order_lines → order_lines,  erp_order_payments → order_payments,
--           erp_order_snapshots → order_snapshots;
--           представления erp_*_v → products_v, orders_v, order_lines_v, order_payments_v
--
-- Внешние ключи, представления и последовательности ссылаются на таблицы по OID и продолжают
-- работать. Тела функций хранятся текстом, поэтому функции, которые обращаются к таблицам,
-- пересоздаются ниже — без изменений, кроме имён таблиц.
--
-- Таблицы ядра указываются со схемой: erp.forms, erp.ui_actions. public в search_path стоит
-- первой, и прикладная таблица с таким же именем иначе подменила бы таблицу ядра.
-- =====================================================================

-- ---------------------------------------------------------------------
-- Таблицы ядра → erp, без префикса (индексы, ограничения и последовательности переносятся с ними)
-- ---------------------------------------------------------------------
ALTER TABLE erp_forms            SET SCHEMA erp;
ALTER TABLE erp_form_components  SET SCHEMA erp;
ALTER TABLE erp_ui_actions       SET SCHEMA erp;
ALTER TABLE erp_grid_columns     SET SCHEMA erp;
ALTER TABLE erp_grid_row_actions SET SCHEMA erp;

ALTER TABLE erp.erp_forms            RENAME TO forms;
ALTER TABLE erp.erp_form_components  RENAME TO form_components;
ALTER TABLE erp.erp_ui_actions       RENAME TO ui_actions;
ALTER TABLE erp.erp_grid_columns     RENAME TO grid_columns;
ALTER TABLE erp.erp_grid_row_actions RENAME TO grid_row_actions;

-- ---------------------------------------------------------------------
-- Прикладные таблицы и представления: без префикса
-- ---------------------------------------------------------------------
ALTER TABLE erp_customers       RENAME TO customers;
ALTER TABLE erp_products        RENAME TO products;
ALTER TABLE erp_orders          RENAME TO orders;
ALTER TABLE erp_order_lines     RENAME TO order_lines;
ALTER TABLE erp_order_payments  RENAME TO order_payments;
ALTER TABLE erp_order_snapshots RENAME TO order_snapshots;

ALTER VIEW erp_products_v       RENAME TO products_v;
ALTER VIEW erp_orders_v         RENAME TO orders_v;
ALTER VIEW erp_order_lines_v    RENAME TO order_lines_v;
ALTER VIEW erp_order_payments_v RENAME TO order_payments_v;

-- ---------------------------------------------------------------------
-- Индексы, последовательности и ограничения тоже без префикса:
-- erp_orders_pkey → orders_pkey, erp_forms_pkey → forms_pkey, erp_orders_id_seq → orders_id_seq, ...
-- ---------------------------------------------------------------------
DO $$
DECLARE
    v_rel RECORD;
    v_con RECORD;
BEGIN
    FOR v_rel IN
        SELECT oid::regclass AS rel, relname, CASE relkind WHEN 'i' THEN 'INDEX' ELSE 'SEQUENCE' END AS kind
        FROM pg_class
        WHERE relnamespace IN ('public'::regnamespace, 'erp'::regnamespace)
          AND relkind IN ('i', 'S') AND relname LIKE 'erp\_%'
    LOOP
        EXECUTE format('ALTER %s %s RENAME TO %I', v_rel.kind, v_rel.rel, substr(v_rel.relname, 5));
    END LOOP;

    -- PRIMARY KEY и UNIQUE уже переименованы вместе со своими индексами
    FOR v_con IN
        SELECT conrelid::regclass AS tbl, conname
        FROM pg_constraint
        WHERE connamespace IN ('public'::regnamespace, 'erp'::regnamespace) AND conname LIKE 'erp\_%'
    LOOP
        EXECUTE format('ALTER TABLE %s RENAME CONSTRAINT %I TO %I', v_con.tbl, v_con.conname, substr(v_con.conname, 5));
    END LOOP;
END;
$$;

-- ---------------------------------------------------------------------
-- Ядро: маршрутизатор, редактор форм, метаданные таблиц
-- ---------------------------------------------------------------------
-- search_path задаётся маршрутизатору (см. V23): обработчики вызывают помощники ядра без схемы
CREATE OR REPLACE FUNCTION erp.handle_ui_event(p_action VARCHAR, p_form_data JSON)
RETURNS JSON AS $$
DECLARE
    v_function     REGPROC;
    v_result       JSON;
    v_message      TEXT;
    v_instructions TEXT;
BEGIN
    SELECT function_name INTO v_function
    FROM erp.ui_actions
    WHERE action_name = p_action;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Неизвестное действие: %', p_action;
    END IF;

    BEGIN
        -- regproc при выводе даёт корректно экранированное имя функции
        EXECUTE format('SELECT %s($1)', v_function) INTO v_result USING p_form_data;
    EXCEPTION WHEN SQLSTATE 'U0001' THEN
        GET STACKED DIAGNOSTICS v_message = MESSAGE_TEXT, v_instructions = PG_EXCEPTION_DETAIL;
        RETURN json_build_object(
            'status', 'error',
            'message', v_message,
            'ui_instructions', v_instructions::JSON);
    END;
    RETURN v_result;
END;
$$ LANGUAGE plpgsql
SET search_path = public, erp;

-- Формы без папки — в конце списка
CREATE OR REPLACE FUNCTION erp.ui_form_list(p_data JSON)
RETURNS JSON AS $$
BEGIN
    RETURN json_build_object(
        'status', 'success',
        'forms', COALESCE((
            SELECT json_agg(json_build_object('name', form_name, 'title', title, 'folder', folder)
                            ORDER BY folder NULLS LAST, title)
            FROM erp.forms), '[]'::json),
        'actions', COALESCE((
            SELECT json_agg(json_build_object('name', action_name, 'description', description)
                            ORDER BY action_name)
            FROM erp.ui_actions
            WHERE NOT is_system), '[]'::json));
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION erp.ui_form_get(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_form_name VARCHAR := p_data->>'form';
    v_form      JSON;
BEGIN
    SELECT json_build_object(
               'name', f.form_name,
               'title', f.title,
               'folder', f.folder,
               'cancel', f.cancel_action,
               'components', COALESCE((
                   SELECT json_agg(json_build_object(
                              'type', c.component_type,
                              'name', c.component_name,
                              'label', c.label,
                              'action', c.action_event,
                              'master', c.master_field,
                              'tab', c.tab,
                              'options', c.options)
                          ORDER BY c.sort_order)
                   FROM erp.form_components c
                   WHERE c.form_name = f.form_name), '[]'::json))
    INTO v_form
    FROM erp.forms f
    WHERE f.form_name = v_form_name;

    IF v_form IS NULL THEN
        RAISE EXCEPTION 'Форма "%" не найдена', v_form_name;
    END IF;

    RETURN json_build_object('status', 'success', 'form', v_form);
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION erp.ui_form_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_form_name  VARCHAR := p_data->>'name';
    v_title      VARCHAR := ui_text(p_data, 'title');
    v_folder     VARCHAR := ui_text(p_data, 'folder');
    v_components JSON    := COALESCE(p_data->'components', '[]'::json);
    v_comp       RECORD;
BEGIN
    PERFORM ui_require(v_form_name ~ '^[a-z_][a-z0-9_]*$',
                       'Имя формы: латинские буквы в нижнем регистре, цифры и "_"');

    FOR v_comp IN
        SELECT c->>'type' AS type, c->>'name' AS name, NULLIF(c->>'action', '') AS action,
               NULLIF(c->>'master', '') AS master, c->'options' AS options, n
        FROM json_array_elements(v_components) WITH ORDINALITY AS t(c, n)
    LOOP
        PERFORM ui_require(v_comp.type = ANY (ui_component_types()),
                           format('Компонент №%s: неизвестный тип "%s"', v_comp.n, v_comp.type));
        PERFORM ui_require(v_comp.name ~ '^[a-z_][a-z0-9_]*$',
                           format('Компонент №%s: имя — латинские буквы в нижнем регистре, цифры и "_"', v_comp.n));

        IF v_comp.type = 'grid' AND v_comp.action IS NULL THEN
            RAISE EXCEPTION 'Таблица "%": выберите действие-источник данных', v_comp.name;
        END IF;
        IF v_comp.type = 'lookup' AND v_comp.action IS NULL THEN
            RAISE EXCEPTION 'Поле выбора "%": выберите действие открытия списка', v_comp.name;
        END IF;
        IF v_comp.type = 'timer' AND v_comp.action IS NULL THEN
            RAISE EXCEPTION 'Таймер "%": выберите действие', v_comp.name;
        END IF;

        IF v_comp.action IS NOT NULL THEN
            PERFORM ui_require(
                EXISTS (SELECT 1 FROM erp.ui_actions WHERE action_name = v_comp.action AND NOT is_system),
                format('Компонент "%s": действие "%s" не зарегистрировано', v_comp.name, v_comp.action));
        END IF;
        IF v_comp.type = 'grid' AND v_comp.master IS NOT NULL THEN
            PERFORM ui_require(
                EXISTS (SELECT 1 FROM json_array_elements(v_components) c
                        WHERE c->>'name' = v_comp.master AND c->>'type' IN ('input', 'hidden', 'lookup')),
                format('Таблица "%s": поле-мастер "%s" не найдено среди полей формы', v_comp.name, v_comp.master));
        END IF;
        IF v_comp.options IS NOT NULL AND json_typeof(v_comp.options) NOT IN ('object', 'null') THEN
            RAISE EXCEPTION 'Компонент "%": параметры должны быть объектом JSON', v_comp.name;
        END IF;
    END LOOP;

    PERFORM ui_require(
        (SELECT count(*) = count(DISTINCT c->>'name') FROM json_array_elements(v_components) c),
        'Имена компонентов должны быть уникальны');

    INSERT INTO erp.forms (form_name, title, folder)
    VALUES (v_form_name, COALESCE(v_title, v_form_name), v_folder)
    ON CONFLICT (form_name) DO UPDATE
        SET title = EXCLUDED.title, folder = EXCLUDED.folder, updated_at = now();

    DELETE FROM erp.form_components WHERE form_name = v_form_name;

    INSERT INTO erp.form_components
        (form_name, sort_order, component_type, component_name, label, action_event, master_field, tab, options)
    SELECT v_form_name, n, c->>'type', c->>'name', c->>'label', NULLIF(c->>'action', ''),
           CASE WHEN c->>'type' = 'grid' THEN NULLIF(c->>'master', '') END,
           CASE WHEN c->>'type' NOT IN ('hidden', 'timer') THEN NULLIF(trim(c->>'tab'), '') END,
           CASE WHEN json_typeof(c->'options') = 'object' AND (c->'options')::jsonb <> '{}' THEN (c->'options')::jsonb END
    FROM json_array_elements(v_components) WITH ORDINALITY AS t(c, n);

    RETURN ui_ok(ui_message(format('Форма "%s" сохранена', v_form_name)));
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION erp.ui_form_delete(p_data JSON)
RETURNS JSON AS $$
BEGIN
    DELETE FROM erp.forms WHERE form_name = p_data->>'form';
    PERFORM ui_require(FOUND, format('Форма "%s" не найдена', p_data->>'form'));

    RETURN ui_ok();
END;
$$ LANGUAGE plpgsql;

-- {"action": "order_create"} -> {"action", "function", "description", "source"}
-- Отдаётся код только зарегистрированных в erp.ui_actions функций.
CREATE OR REPLACE FUNCTION erp.ui_action_source(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_action erp.ui_actions%ROWTYPE;
BEGIN
    SELECT * INTO v_action
    FROM erp.ui_actions
    WHERE action_name = p_data->>'action';

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Действие "%" не зарегистрировано', p_data->>'action';
    END IF;

    RETURN json_build_object(
        'status', 'success',
        'action', v_action.action_name,
        'function', v_action.function_name::REGPROCEDURE::TEXT,
        'description', v_action.description,
        'source', pg_get_functiondef(v_action.function_name));
END;
$$ LANGUAGE plpgsql;

-- Колонки теперь сообщают клиенту, можно ли по ним сортировать.
CREATE OR REPLACE FUNCTION erp.ui_grid_columns(p_action VARCHAR)
RETURNS JSON AS $$
    SELECT COALESCE(json_agg(json_build_object(
               'field', field_name,
               'title', column_title,
               'type', cell_type,
               'sortable', sort_column IS NOT NULL)
           ORDER BY display_order), '[]'::json)
    FROM erp.grid_columns
    WHERE action_name = p_action;
$$ LANGUAGE sql STABLE;

-- Проверенная сортировка: запрошенное поле, если оно сортируемое, иначе поле по умолчанию.
CREATE OR REPLACE FUNCTION erp.ui_grid_sort(p_action VARCHAR, p_data JSON, p_default_field VARCHAR, p_default_dir VARCHAR)
RETURNS TABLE (field VARCHAR, dir VARCHAR, sort_column VARCHAR) AS $$
    SELECT c.field_name,
           CASE WHEN lower(p_data->>'sort_dir') IN ('asc', 'desc') AND c.field_name = p_data->>'sort_field'
                THEN lower(p_data->>'sort_dir')
                ELSE p_default_dir
           END,
           c.sort_column
    FROM erp.grid_columns c
    WHERE c.action_name = p_action
      AND c.sort_column IS NOT NULL
      AND c.field_name IN (p_data->>'sort_field', p_default_field)
    -- Запрошенное поле приоритетнее поля по умолчанию
    ORDER BY c.field_name = p_data->>'sort_field' DESC NULLS LAST
    LIMIT 1;
$$ LANGUAGE sql STABLE;

CREATE OR REPLACE FUNCTION erp.ui_grid_row_actions(p_action VARCHAR)
RETURNS JSON AS $$
    SELECT COALESCE(json_agg(json_build_object(
               'action', row_action,
               'label', label,
               'style', style)
           ORDER BY sort_order), '[]'::json)
    FROM erp.grid_row_actions
    WHERE source_action = p_action;
$$ LANGUAGE sql STABLE;

-- ---------------------------------------------------------------------
-- Справочники: клиенты и товары
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION customers_page(p_data JSON)
RETURNS JSON AS $$
    SELECT ui_grid_page('customers_page', p_data, 'customers', NULL, 'name', 'asc');
$$ LANGUAGE sql;

CREATE OR REPLACE FUNCTION customer_edit_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_customer customers%ROWTYPE;
BEGIN
    SELECT * INTO v_customer FROM customers WHERE id = ui_parse_id(p_data->>'id');
    PERFORM ui_require(FOUND, 'Клиент не найден — возможно, он удалён');

    RETURN ui_ok(ui_open_form('customer',
        p_title => v_customer.name,
        p_data  => jsonb_build_object(
            'id', v_customer.id::TEXT,
            'name', v_customer.name,
            'phone', COALESCE(v_customer.phone, ''))));
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION customer_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_id    BIGINT  := ui_parse_id(p_data->>'id');
    v_name  VARCHAR := ui_text(p_data, 'name');
    v_phone VARCHAR := ui_text(p_data, 'phone');
BEGIN
    PERFORM ui_require(v_name IS NOT NULL, 'Укажите наименование клиента');
    PERFORM ui_require(
        NOT EXISTS (SELECT 1 FROM customers WHERE lower(name) = lower(v_name) AND id IS DISTINCT FROM v_id),
        format('Клиент «%s» уже есть в справочнике', v_name));

    IF ui_is_new(p_data) THEN
        INSERT INTO customers (name, phone) VALUES (v_name, v_phone);
    ELSE
        UPDATE customers SET name = v_name, phone = v_phone WHERE id = v_id;
        PERFORM ui_require(FOUND, 'Клиент не найден — возможно, он удалён');
    END IF;

    RETURN ui_ok(
        ui_close_form(),
        ui_refresh_grid('customers_grid', p_keep_page => NOT ui_is_new(p_data)),
        ui_refresh_grid('orders_grid', p_keep_page => TRUE));
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION products_page(p_data JSON)
RETURNS JSON AS $$
    SELECT ui_grid_page('products_page', p_data, 'products_v', NULL, 'name', 'asc');
$$ LANGUAGE sql;

CREATE OR REPLACE FUNCTION product_edit_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_product products%ROWTYPE;
BEGIN
    SELECT * INTO v_product FROM products WHERE id = ui_parse_id(p_data->>'id');
    PERFORM ui_require(FOUND, 'Товар не найден — возможно, он удалён');

    RETURN ui_ok(ui_open_form('product',
        p_title => v_product.name,
        p_data  => jsonb_build_object(
            'id', v_product.id::TEXT,
            'name', v_product.name,
            'price', ui_money_input(v_product.price))));
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION product_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_id    BIGINT  := ui_parse_id(p_data->>'id');
    v_name  VARCHAR := ui_text(p_data, 'name');
    v_price NUMERIC := ui_parse_money(p_data->>'price');
BEGIN
    PERFORM ui_require(v_name IS NOT NULL,  'Укажите наименование товара');
    PERFORM ui_require(v_price IS NOT NULL, 'Цена — число, например 1500 или 99,90');
    PERFORM ui_require(
        NOT EXISTS (SELECT 1 FROM products WHERE lower(name) = lower(v_name) AND id IS DISTINCT FROM v_id),
        format('Товар «%s» уже есть в справочнике', v_name));

    IF ui_is_new(p_data) THEN
        INSERT INTO products (name, price) VALUES (v_name, v_price);
    ELSE
        UPDATE products SET name = v_name, price = v_price WHERE id = v_id;
        PERFORM ui_require(FOUND, 'Товар не найден — возможно, он удалён');
    END IF;

    RETURN ui_ok(
        ui_close_form(),
        ui_refresh_grid('products_grid', p_keep_page => NOT ui_is_new(p_data)));
END;
$$ LANGUAGE plpgsql;

-- ---------------------------------------------------------------------
-- Заказ (шапка)
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION orders_page(p_data JSON)
RETURNS JSON AS $$
    SELECT ui_grid_page('orders_page', p_data, 'orders_v');
$$ LANGUAGE sql;

-- Инструкция: обновить сумму в открытой карточке заказа
CREATE OR REPLACE FUNCTION order_total_update(p_order_id BIGINT)
RETURNS JSONB AS $$
    SELECT ui_set_values(jsonb_build_object('order_total', ui_format_money(COALESCE(total, 0))),
                         p_form => 'order_new')
    FROM orders_v
    WHERE id = p_order_id;
$$ LANGUAGE sql STABLE;

-- Снимок заказа для "Отмены": шапка, позиции и оплаты
CREATE OR REPLACE FUNCTION order_state(p_id BIGINT)
RETURNS JSONB AS $$
    SELECT jsonb_build_object(
        'customer_id', o.customer_id,
        'order_date', o.order_date,
        'lines', COALESCE((
            SELECT jsonb_agg(jsonb_build_object(
                       'id', l.id, 'product_id', l.product_id, 'quantity', l.quantity, 'price', l.price)
                   ORDER BY l.id)
            FROM order_lines l
            WHERE l.order_id = o.id), '[]'::jsonb),
        'payments', COALESCE((
            SELECT jsonb_agg(jsonb_build_object('id', p.id, 'paid_on', p.paid_on, 'amount', p.amount)
                   ORDER BY p.id)
            FROM order_payments p
            WHERE p.order_id = o.id), '[]'::jsonb))
    FROM orders o
    WHERE o.id = p_id;
$$ LANGUAGE sql STABLE;

-- Вернуть заказ к снимку
CREATE OR REPLACE FUNCTION order_restore(p_id BIGINT, p_state JSONB)
RETURNS VOID AS $$
BEGIN
    UPDATE orders
    SET customer_id = (p_state->>'customer_id')::BIGINT,
        order_date  = (p_state->>'order_date')::DATE
    WHERE id = p_id;

    DELETE FROM order_lines WHERE order_id = p_id;
    INSERT INTO order_lines (id, order_id, product_id, quantity, price)
    SELECT id, p_id, product_id, quantity, price
    FROM jsonb_to_recordset(p_state->'lines') AS t(id BIGINT, product_id BIGINT, quantity INT, price NUMERIC);

    DELETE FROM order_payments WHERE order_id = p_id;
    INSERT INTO order_payments (id, order_id, paid_on, amount)
    SELECT id, p_id, paid_on, amount
    FROM jsonb_to_recordset(p_state->'payments') AS t(id BIGINT, paid_on DATE, amount NUMERIC);
END;
$$ LANGUAGE plpgsql;

-- Шапка заказа (клиент и дата): новый заказ создаётся черновиком; возвращает id
CREATE OR REPLACE FUNCTION order_upsert(p_data JSON)
RETURNS BIGINT AS $$
DECLARE
    v_customer BIGINT := ui_parse_id(p_data->>'customer_id');
    v_date     DATE   := ui_parse_date(p_data->>'order_date');
    v_id       BIGINT;
BEGIN
    PERFORM ui_require(v_customer IS NOT NULL, 'Выберите клиента');
    PERFORM ui_require(EXISTS (SELECT 1 FROM customers WHERE id = v_customer),
                       'Клиент не найден — возможно, он удалён');
    PERFORM ui_require(v_date IS NOT NULL, 'Укажите дату заказа');

    IF ui_is_new(p_data) THEN
        INSERT INTO orders (customer_id, order_date, status)
        VALUES (v_customer, v_date, 'DRAFT')
        RETURNING id INTO v_id;
        RETURN v_id;
    END IF;

    UPDATE orders SET customer_id = v_customer, order_date = v_date
    WHERE id = ui_parse_id(p_data->>'id')
    RETURNING id INTO v_id;
    PERFORM ui_require(FOUND, format('Заказ №%s не найден — возможно, он уже удалён', ui_text(p_data, 'id')));

    RETURN v_id;
END;
$$ LANGUAGE plpgsql;

-- Открытие заказа запоминает его сохранённую версию (см. V15)
CREATE OR REPLACE FUNCTION order_edit_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_order orders_v%ROWTYPE;
BEGIN
    SELECT * INTO v_order FROM orders_v WHERE id = ui_parse_id(p_data->>'id');
    PERFORM ui_require(FOUND, format('Заказ №%s не найден — возможно, он уже удалён', p_data->>'id'));

    IF v_order.status <> 'DRAFT' THEN
        INSERT INTO order_snapshots (order_id, state)
        VALUES (v_order.id, order_state(v_order.id))
        ON CONFLICT (order_id) DO NOTHING;
    END IF;

    RETURN ui_ok(ui_open_form('order_new',
        p_title => format(CASE WHEN v_order.status = 'DRAFT' THEN 'Заказ №%s (черновик)' ELSE 'Заказ №%s' END,
                          v_order.id),
        p_data  => jsonb_build_object(
            'id', v_order.id::TEXT,
            'customer_id', v_order.customer_id::TEXT,
            'customer_id__display', v_order.customer,
            'order_date', to_char(v_order.order_date_value, 'YYYY-MM-DD'),
            'order_total', ui_format_money(v_order.total))));
END;
$$ LANGUAGE plpgsql;

-- "Сохранить": шапка, проверка заказа целиком, черновик становится заказом; окно закрывается
CREATE OR REPLACE FUNCTION order_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_id BIGINT := order_upsert(p_data);
BEGIN
    PERFORM ui_require(EXISTS (SELECT 1 FROM order_lines WHERE order_id = v_id),
                       'Добавьте в заказ хотя бы одну позицию');

    UPDATE orders SET status = 'NEW' WHERE id = v_id AND status = 'DRAFT';
    DELETE FROM order_snapshots WHERE order_id = v_id;

    RETURN ui_ok(
        ui_close_form(),
        ui_refresh_grid('orders_grid', p_keep_page => NOT ui_is_new(p_data)),
        ui_message(format('Заказ №%s сохранён', v_id)));
END;
$$ LANGUAGE plpgsql;

-- "Отмена" (и закрытие окна): черновик удаляется, сохранённый заказ возвращается к снимку.
-- Если что-то было изменено, сначала переспрашивает. Шапка (клиент и дата) берётся из формы —
-- её изменения ещё не записаны в базу.
CREATE OR REPLACE FUNCTION order_cancel(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_order    orders%ROWTYPE;
    v_snapshot JSONB;
    v_changed  BOOLEAN;
    v_close    JSONB := jsonb_build_array(ui_close_form(), ui_refresh_grid('orders_grid', p_keep_page => TRUE));
BEGIN
    SELECT * INTO v_order FROM orders WHERE id = ui_parse_id(p_data->>'id');
    IF NOT FOUND THEN
        -- Заказ ещё не создавался или уже удалён — отменять нечего
        RETURN ui_ok(v_close);
    END IF;

    SELECT state INTO v_snapshot FROM order_snapshots WHERE order_id = v_order.id;

    v_changed := CASE
        WHEN v_order.status = 'DRAFT' THEN
            EXISTS (SELECT 1 FROM order_lines WHERE order_id = v_order.id)
            OR EXISTS (SELECT 1 FROM order_payments WHERE order_id = v_order.id)
        ELSE
            v_snapshot IS NOT NULL
            AND v_snapshot IS DISTINCT FROM order_state(v_order.id) || jsonb_build_object(
                'customer_id', ui_parse_id(p_data->>'customer_id'),
                'order_date', ui_parse_date(p_data->>'order_date'))
    END;

    IF v_changed AND NOT ui_confirmed(p_data) THEN
        RETURN ui_ok(ui_confirm(
            CASE WHEN v_order.status = 'DRAFT'
                THEN format('Закрыть без сохранения? Черновик заказа №%s с позициями и оплатами будет удалён.',
                            v_order.id)
                ELSE format('Закрыть без сохранения? Изменения в заказе №%s будут отменены.', v_order.id)
            END,
            'order_cancel',
            jsonb_build_object('id', v_order.id::TEXT, 'confirmed', TRUE),
            p_confirm_label => 'Не сохранять'));
    END IF;

    IF v_order.status = 'DRAFT' THEN
        DELETE FROM orders WHERE id = v_order.id;  -- позиции и оплаты удаляются каскадно
    ELSIF v_snapshot IS NOT NULL THEN
        PERFORM order_restore(v_order.id, v_snapshot);
        DELETE FROM order_snapshots WHERE order_id = v_order.id;
    END IF;

    RETURN ui_ok(v_close);
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION order_delete(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_order orders_v%ROWTYPE;
BEGIN
    SELECT * INTO v_order FROM orders_v WHERE id = ui_parse_id(p_data->>'id');
    PERFORM ui_require(FOUND, format('Заказ №%s не найден — возможно, он уже удалён', p_data->>'id'));

    IF NOT ui_confirmed(p_data) THEN
        RETURN ui_ok(ui_confirm(
            format('Удалить заказ №%s?' || E'\n' || '%s — позиций: %s, сумма %s',
                   v_order.id, v_order.customer, v_order.lines_count, ui_format_money(v_order.total)),
            'order_delete',
            jsonb_build_object('id', v_order.id, 'confirmed', TRUE),
            p_confirm_label => 'Удалить'));
    END IF;

    DELETE FROM orders WHERE id = v_order.id;  -- позиции и оплаты удаляются каскадно

    RETURN ui_ok(
        ui_refresh_grid('orders_grid', p_keep_page => TRUE),
        ui_message(format('Заказ №%s удалён', v_order.id)));
END;
$$ LANGUAGE plpgsql;

-- ---------------------------------------------------------------------
-- Позиции заказа
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION order_lines_page(p_data JSON)
RETURNS JSON AS $$
    SELECT ui_grid_page('order_lines_page', p_data, 'order_lines_v', 'order_id', 'id', 'asc');
$$ LANGUAGE sql;

CREATE OR REPLACE FUNCTION order_line_edit_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_line order_lines_v%ROWTYPE;
BEGIN
    SELECT * INTO v_line FROM order_lines_v WHERE id = ui_parse_id(p_data->>'id');
    PERFORM ui_require(FOUND, 'Позиция не найдена — возможно, она уже удалена');

    RETURN ui_ok(ui_open_form('order_line',
        p_title => format('Позиция: %s', v_line.product),
        p_data  => jsonb_build_object(
            'id', v_line.id::TEXT,
            'order_id', v_line.order_id::TEXT,
            'product_id', v_line.product_id::TEXT,
            'product_id__display', v_line.product,
            'quantity', v_line.quantity::TEXT,
            'price', ui_money_input(v_line.price))));
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION order_line_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_order    BIGINT  := ui_parse_id(p_data->>'order_id');
    v_product  BIGINT  := ui_parse_id(p_data->>'product_id');
    v_quantity TEXT    := trim(p_data->>'quantity');
    v_price    NUMERIC := ui_parse_money(p_data->>'price');
BEGIN
    PERFORM ui_require(EXISTS (SELECT 1 FROM orders WHERE id = v_order),
                       'Заказ не найден — возможно, он уже удалён');
    PERFORM ui_require(EXISTS (SELECT 1 FROM products WHERE id = v_product), 'Выберите товар');
    PERFORM ui_require(v_quantity ~ '^[1-9]\d{0,5}$', 'Количество — целое число больше нуля');
    PERFORM ui_require(v_price IS NOT NULL, 'Цена — число, например 1500 или 99,90');

    IF ui_is_new(p_data) THEN
        INSERT INTO order_lines (order_id, product_id, quantity, price)
        VALUES (v_order, v_product, v_quantity::INT, v_price);
    ELSE
        UPDATE order_lines
        SET product_id = v_product, quantity = v_quantity::INT, price = v_price
        WHERE id = ui_parse_id(p_data->>'id') AND order_id = v_order;
        PERFORM ui_require(FOUND, 'Позиция не найдена — возможно, она уже удалена');
    END IF;

    RETURN ui_ok(
        ui_close_form(),
        ui_refresh_grid('order_lines_grid', p_keep_page => TRUE),
        ui_refresh_grid('orders_grid', p_keep_page => TRUE),
        order_total_update(v_order));
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION order_line_delete(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_line order_lines_v%ROWTYPE;
BEGIN
    SELECT * INTO v_line FROM order_lines_v WHERE id = ui_parse_id(p_data->>'id');
    PERFORM ui_require(FOUND, 'Позиция не найдена — возможно, она уже удалена');

    IF NOT ui_confirmed(p_data) THEN
        RETURN ui_ok(ui_confirm(
            format('Удалить позицию «%s», %s шт. на сумму %s?',
                   v_line.product, v_line.quantity, ui_format_money(v_line.total)),
            'order_line_delete',
            jsonb_build_object('id', v_line.id, 'confirmed', TRUE),
            p_confirm_label => 'Удалить'));
    END IF;

    DELETE FROM order_lines WHERE id = v_line.id;

    RETURN ui_ok(
        ui_refresh_grid('order_lines_grid', p_keep_page => TRUE),
        ui_refresh_grid('orders_grid', p_keep_page => TRUE),
        order_total_update(v_line.order_id));
END;
$$ LANGUAGE plpgsql;

-- ---------------------------------------------------------------------
-- Оплаты заказа
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION order_payments_page(p_data JSON)
RETURNS JSON AS $$
    SELECT ui_grid_page('order_payments_page', p_data, 'order_payments_v', 'order_id', 'paid_date', 'asc');
$$ LANGUAGE sql;

-- "Добавить оплату": по умолчанию предлагается неоплаченный остаток
CREATE OR REPLACE FUNCTION order_payment_new_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_id   BIGINT := order_upsert(p_data);
    v_rest NUMERIC;
BEGIN
    SELECT total - paid INTO v_rest FROM orders_v WHERE id = v_id;

    RETURN ui_ok(
        order_header_saved(ui_is_new(p_data), v_id),
        ui_open_form('order_payment',
            p_title => format('Оплата заказа №%s', v_id),
            p_data  => jsonb_build_object(
                'order_id', v_id::TEXT,
                'paid_on', to_char(current_date, 'DD.MM.YYYY'),
                'amount', CASE WHEN v_rest > 0 THEN ui_money_input(v_rest) ELSE '' END)));
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION order_payment_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_order  BIGINT  := ui_parse_id(p_data->>'order_id');
    v_date   DATE    := ui_parse_date(p_data->>'paid_on');
    v_amount NUMERIC := ui_parse_money(p_data->>'amount');
BEGIN
    PERFORM ui_require(EXISTS (SELECT 1 FROM orders WHERE id = v_order),
                       'Заказ не найден — возможно, он уже удалён');
    PERFORM ui_require(v_date IS NOT NULL, 'Дата оплаты — в формате ДД.ММ.ГГГГ');
    PERFORM ui_require(v_amount > 0, 'Сумма оплаты — число больше нуля');

    INSERT INTO order_payments (order_id, paid_on, amount) VALUES (v_order, v_date, v_amount);

    RETURN ui_ok(
        ui_close_form(),
        ui_refresh_grid('order_payments_grid', p_keep_page => TRUE),
        ui_refresh_grid('orders_grid', p_keep_page => TRUE));
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION order_payment_delete(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_payment order_payments_v%ROWTYPE;
BEGIN
    SELECT * INTO v_payment FROM order_payments_v WHERE id = ui_parse_id(p_data->>'id');
    PERFORM ui_require(FOUND, 'Оплата не найдена — возможно, она уже удалена');

    IF NOT ui_confirmed(p_data) THEN
        RETURN ui_ok(ui_confirm(
            format('Удалить оплату от %s на сумму %s?', v_payment.paid_date, ui_format_money(v_payment.amount)),
            'order_payment_delete',
            jsonb_build_object('id', v_payment.id, 'confirmed', TRUE),
            p_confirm_label => 'Удалить'));
    END IF;

    DELETE FROM order_payments WHERE id = v_payment.id;

    RETURN ui_ok(
        ui_refresh_grid('order_payments_grid', p_keep_page => TRUE),
        ui_refresh_grid('orders_grid', p_keep_page => TRUE));
END;
$$ LANGUAGE plpgsql;

