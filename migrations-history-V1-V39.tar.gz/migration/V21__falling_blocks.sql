-- =====================================================================
-- Пример "Падающие блоки": игра целиком на PL/pgSQL.
--
-- Новое в платформе:
--  * erp_form_components.options (JSONB) — параметры компонента:
--      button.hotkey   — горячая клавиша (event.code или event.key: ArrowLeft, Space, KeyP);
--      timer.interval  — период вызова действия, мс;
--      board.rows/cols — размер пустого поля.
--  * Компонент 'board' — поле из клеток. Значение — строки через "/":
--    "#" — занятая клетка, "@" — активная, "." — пустая.
--  * Компонент 'timer' — вызывает своё действие каждые interval мс, пока его значение
--    не пустое; включает и выключает таймер база через set_values.
--
-- Состояние игры хранится в скрытом поле формы state (JSON), отдельная таблица не нужна:
--   {"rows": ["........", ...], "x": 3, "y": 0, "score": 0, "over": false}
-- =====================================================================

-- ---------------------------------------------------------------------
-- Параметры компонентов
-- ---------------------------------------------------------------------
ALTER TABLE erp_form_components ADD COLUMN options JSONB;

CREATE OR REPLACE FUNCTION ui_component_types()
RETURNS VARCHAR[] AS $$
    SELECT ARRAY['label', 'input', 'date', 'hidden', 'display', 'lookup', 'button', 'grid',
                 'board', 'timer']::VARCHAR[];
$$ LANGUAGE sql IMMUTABLE;

CREATE OR REPLACE FUNCTION ui_form_get(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_form_name VARCHAR := p_data->>'form';
    v_form      JSON;
BEGIN
    SELECT json_build_object(
               'name', f.form_name,
               'title', f.title,
               'folder', f.folder,
               'cancel', f.cancel_action,
               'components', COALESCE((
                   SELECT json_agg(json_build_object(
                              'type', c.component_type,
                              'name', c.component_name,
                              'label', c.label,
                              'action', c.action_event,
                              'master', c.master_field,
                              'tab', c.tab,
                              'options', c.options)
                          ORDER BY c.sort_order)
                   FROM erp_form_components c
                   WHERE c.form_name = f.form_name), '[]'::json))
    INTO v_form
    FROM erp_forms f
    WHERE f.form_name = v_form_name;

    IF v_form IS NULL THEN
        RAISE EXCEPTION 'Форма "%" не найдена', v_form_name;
    END IF;

    RETURN json_build_object('status', 'success', 'form', v_form);
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION ui_form_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_form_name  VARCHAR := p_data->>'name';
    v_title      VARCHAR := NULLIF(trim(p_data->>'title'), '');
    v_folder     VARCHAR := NULLIF(trim(p_data->>'folder'), '');
    v_components JSON    := COALESCE(p_data->'components', '[]'::json);
    v_comp       RECORD;
BEGIN
    IF v_form_name IS NULL OR v_form_name !~ '^[a-z_][a-z0-9_]*$' THEN
        RAISE EXCEPTION 'Имя формы: латинские буквы в нижнем регистре, цифры и "_"';
    END IF;

    FOR v_comp IN
        SELECT c->>'type' AS type, c->>'name' AS name, NULLIF(c->>'action', '') AS action,
               NULLIF(c->>'master', '') AS master, c->'options' AS options, n
        FROM json_array_elements(v_components) WITH ORDINALITY AS t(c, n)
    LOOP
        IF v_comp.type IS NULL OR NOT v_comp.type = ANY (ui_component_types()) THEN
            RAISE EXCEPTION 'Компонент №%: неизвестный тип "%"', v_comp.n, v_comp.type;
        END IF;
        IF v_comp.name IS NULL OR v_comp.name !~ '^[a-z_][a-z0-9_]*$' THEN
            RAISE EXCEPTION 'Компонент №%: имя — латинские буквы в нижнем регистре, цифры и "_"', v_comp.n;
        END IF;
        IF v_comp.type = 'grid' AND v_comp.action IS NULL THEN
            RAISE EXCEPTION 'Таблица "%": выберите действие-источник данных', v_comp.name;
        END IF;
        IF v_comp.type = 'lookup' AND v_comp.action IS NULL THEN
            RAISE EXCEPTION 'Поле выбора "%": выберите действие открытия списка', v_comp.name;
        END IF;
        IF v_comp.type = 'timer' AND v_comp.action IS NULL THEN
            RAISE EXCEPTION 'Таймер "%": выберите действие', v_comp.name;
        END IF;
        IF v_comp.action IS NOT NULL
           AND NOT EXISTS (SELECT 1 FROM erp_ui_actions WHERE action_name = v_comp.action AND NOT is_system) THEN
            RAISE EXCEPTION 'Компонент "%": действие "%" не зарегистрировано', v_comp.name, v_comp.action;
        END IF;
        IF v_comp.type = 'grid' AND v_comp.master IS NOT NULL
           AND NOT EXISTS (SELECT 1 FROM json_array_elements(v_components) c
                           WHERE c->>'name' = v_comp.master AND c->>'type' IN ('input', 'hidden', 'lookup')) THEN
            RAISE EXCEPTION 'Таблица "%": поле-мастер "%" не найдено среди полей формы', v_comp.name, v_comp.master;
        END IF;
        IF v_comp.options IS NOT NULL AND json_typeof(v_comp.options) NOT IN ('object', 'null') THEN
            RAISE EXCEPTION 'Компонент "%": параметры должны быть объектом JSON', v_comp.name;
        END IF;
    END LOOP;

    IF (SELECT count(*) <> count(DISTINCT c->>'name') FROM json_array_elements(v_components) c) THEN
        RAISE EXCEPTION 'Имена компонентов должны быть уникальны';
    END IF;

    INSERT INTO erp_forms (form_name, title, folder)
    VALUES (v_form_name, COALESCE(v_title, v_form_name), v_folder)
    ON CONFLICT (form_name) DO UPDATE
        SET title = EXCLUDED.title, folder = EXCLUDED.folder, updated_at = now();

    DELETE FROM erp_form_components WHERE form_name = v_form_name;

    INSERT INTO erp_form_components
        (form_name, sort_order, component_type, component_name, label, action_event, master_field, tab, options)
    SELECT v_form_name, n, c->>'type', c->>'name', c->>'label', NULLIF(c->>'action', ''),
           CASE WHEN c->>'type' = 'grid' THEN NULLIF(c->>'master', '') END,
           CASE WHEN c->>'type' NOT IN ('hidden', 'timer') THEN NULLIF(trim(c->>'tab'), '') END,
           CASE WHEN json_typeof(c->'options') = 'object' AND (c->'options')::jsonb <> '{}' THEN (c->'options')::jsonb END
    FROM json_array_elements(v_components) WITH ORDINALITY AS t(c, n);

    RETURN ui_ok(ui_message(format('Форма "%s" сохранена', v_form_name)));
END;
$$ LANGUAGE plpgsql;


-- ---------------------------------------------------------------------
-- Игра: поле 8 × 12, падает одна клетка; заполненная строка исчезает и даёт очко
-- ---------------------------------------------------------------------
CREATE FUNCTION game_width() RETURNS INT AS 'SELECT 8' LANGUAGE sql IMMUTABLE;
CREATE FUNCTION game_height() RETURNS INT AS 'SELECT 12' LANGUAGE sql IMMUTABLE;

CREATE FUNCTION game_rows(p_state JSONB)
RETURNS TEXT[] AS $$
    SELECT ARRAY(SELECT jsonb_array_elements_text(p_state->'rows'));
$$ LANGUAGE sql IMMUTABLE;

-- Клетка (x, y) внутри поля и свободна; координаты с нуля, y — сверху вниз
CREATE FUNCTION game_free(p_rows TEXT[], p_x INT, p_y INT)
RETURNS BOOLEAN AS $$
    SELECT p_x BETWEEN 0 AND game_width() - 1
       AND p_y BETWEEN 0 AND game_height() - 1
       AND substr(p_rows[p_y + 1], p_x + 1, 1) = '.';
$$ LANGUAGE sql IMMUTABLE;

-- Состояние из формы; NULL — игра не идёт
CREATE FUNCTION game_current(p_data JSON)
RETURNS JSONB AS $$
    SELECT NULLIF(trim(p_data->>'state'), '')::JSONB;
$$ LANGUAGE sql IMMUTABLE;

-- Новая клетка вверху в случайном столбце; если там занято — игра окончена
CREATE FUNCTION game_spawn(p_rows TEXT[], p_score INT)
RETURNS JSONB AS $$
DECLARE
    v_x INT := floor(random() * game_width())::INT;
BEGIN
    RETURN jsonb_build_object('rows', to_jsonb(p_rows), 'x', v_x, 'y', 0, 'score', p_score,
                              'over', NOT game_free(p_rows, v_x, 0));
END;
$$ LANGUAGE plpgsql VOLATILE;

-- Клетка ложится на место, заполненные строки удаляются, сверху добавляются пустые
CREATE FUNCTION game_land(p_state JSONB)
RETURNS JSONB AS $$
DECLARE
    v_rows    TEXT[] := game_rows(p_state);
    v_x       INT    := (p_state->>'x')::INT;
    v_y       INT    := (p_state->>'y')::INT;
    v_kept    TEXT[];
    v_cleared INT;
BEGIN
    v_rows[v_y + 1] := overlay(v_rows[v_y + 1] PLACING '#' FROM v_x + 1 FOR 1);
    v_kept := ARRAY(SELECT r FROM unnest(v_rows) WITH ORDINALITY AS u(r, n) WHERE strpos(r, '.') > 0 ORDER BY n);
    v_cleared := game_height() - cardinality(v_kept);
    v_rows := array_fill(repeat('.', game_width()), ARRAY[v_cleared]) || v_kept;
    RETURN game_spawn(v_rows, (p_state->>'score')::INT + v_cleared);
END;
$$ LANGUAGE plpgsql VOLATILE;

-- Ответ: поле, очки и состояние в форму; в конце игры — таймер выключается и сообщение
CREATE FUNCTION game_response(p_state JSONB)
RETURNS JSONB AS $$
DECLARE
    v_rows  TEXT[]  := game_rows(p_state);
    v_x     INT     := (p_state->>'x')::INT;
    v_y     INT     := (p_state->>'y')::INT;
    v_over  BOOLEAN := (p_state->>'over')::BOOLEAN;
    v_score TEXT    := p_state->>'score';
BEGIN
    v_rows[v_y + 1] := overlay(v_rows[v_y + 1] PLACING '@' FROM v_x + 1 FOR 1);
    RETURN ui_ok(
        ui_set_values(jsonb_build_object(
            'board', array_to_string(v_rows, '/'),
            'score', v_score,
            'state', CASE WHEN v_over THEN '' ELSE p_state::TEXT END)
            || CASE WHEN v_over THEN jsonb_build_object('ticker', '') ELSE '{}'::jsonb END),
        CASE WHEN v_over THEN ui_message(format('Игра окончена. Очки: %s', v_score)) END);
END;
$$ LANGUAGE plpgsql IMMUTABLE;


-- ---------------------------------------------------------------------
-- Действия
-- ---------------------------------------------------------------------
CREATE FUNCTION game_start(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_response JSONB := game_response(game_spawn(array_fill(repeat('.', game_width()), ARRAY[game_height()]), 0));
BEGIN
    -- Вместе с полем включается таймер
    RETURN ui_ok(v_response->'ui_instructions', ui_set_values(jsonb_build_object('ticker', '1')));
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION game_move(p_data JSON, p_dx INT)
RETURNS JSON AS $$
DECLARE
    v_state JSONB := game_current(p_data);
    v_x     INT;
BEGIN
    IF v_state IS NULL THEN
        RETURN ui_ok();
    END IF;
    v_x := (v_state->>'x')::INT + p_dx;
    IF game_free(game_rows(v_state), v_x, (v_state->>'y')::INT) THEN
        v_state := jsonb_set(v_state, '{x}', to_jsonb(v_x));
    END IF;
    RETURN game_response(v_state);
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION game_left(p_data JSON) RETURNS JSON AS 'SELECT game_move(p_data, -1)' LANGUAGE sql;
CREATE FUNCTION game_right(p_data JSON) RETURNS JSON AS 'SELECT game_move(p_data, 1)' LANGUAGE sql;

-- Шаг вниз (его же вызывает таймер); если ниже занято — клетка ложится
CREATE FUNCTION game_down(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_state JSONB := game_current(p_data);
    v_y     INT;
BEGIN
    IF v_state IS NULL THEN
        RETURN ui_ok();
    END IF;
    v_y := (v_state->>'y')::INT + 1;
    IF game_free(game_rows(v_state), (v_state->>'x')::INT, v_y) THEN
        RETURN game_response(jsonb_set(v_state, '{y}', to_jsonb(v_y)));
    END IF;
    RETURN game_response(game_land(v_state));
END;
$$ LANGUAGE plpgsql;

-- Сброс: клетка падает до упора и сразу ложится
CREATE FUNCTION game_drop(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_state JSONB := game_current(p_data);
    v_rows  TEXT[];
    v_x     INT;
    v_y     INT;
BEGIN
    IF v_state IS NULL THEN
        RETURN ui_ok();
    END IF;
    v_rows := game_rows(v_state);
    v_x := (v_state->>'x')::INT;
    v_y := (v_state->>'y')::INT;
    WHILE game_free(v_rows, v_x, v_y + 1) LOOP
        v_y := v_y + 1;
    END LOOP;
    RETURN game_response(game_land(jsonb_set(v_state, '{y}', to_jsonb(v_y))));
END;
$$ LANGUAGE plpgsql;

-- Пауза: таймер выключается или снова включается
CREATE FUNCTION game_pause(p_data JSON)
RETURNS JSON AS $$
BEGIN
    IF game_current(p_data) IS NULL THEN
        RETURN ui_ok();
    END IF;
    RETURN ui_ok(ui_set_values(jsonb_build_object(
        'ticker', CASE WHEN NULLIF(p_data->>'ticker', '') IS NULL THEN '1' ELSE '' END)));
END;
$$ LANGUAGE plpgsql;

INSERT INTO erp_ui_actions (action_name, function_name, description) VALUES
    ('game_start', 'game_start', 'Падающие блоки: новая игра'),
    ('game_left',  'game_left',  'Падающие блоки: влево'),
    ('game_right', 'game_right', 'Падающие блоки: вправо'),
    ('game_down',  'game_down',  'Падающие блоки: шаг вниз (такт таймера)'),
    ('game_drop',  'game_drop',  'Падающие блоки: сбросить до упора'),
    ('game_pause', 'game_pause', 'Падающие блоки: пауза / продолжить');


-- ---------------------------------------------------------------------
-- Форма
-- ---------------------------------------------------------------------
INSERT INTO erp_forms (form_name, title, folder)
VALUES ('falling_blocks', 'Падающие блоки', 'Примеры');

INSERT INTO erp_form_components (form_name, sort_order, component_type, component_name, label, action_event, options) VALUES
    ('falling_blocks',  1, 'hidden',  'state',      NULL,          NULL,         NULL),
    ('falling_blocks',  2, 'timer',   'ticker',     NULL,          'game_down',  '{"interval": 400}'),
    ('falling_blocks',  3, 'board',   'board',      NULL,          NULL,         '{"rows": 12, "cols": 8}'),
    ('falling_blocks',  4, 'display', 'score',      'Очки',        NULL,         NULL),
    ('falling_blocks',  5, 'button',  'btn_start',  'Новая игра',  'game_start', NULL),
    ('falling_blocks',  6, 'button',  'btn_left',   '←',           'game_left',  '{"hotkey": "ArrowLeft"}'),
    ('falling_blocks',  7, 'button',  'btn_down',   '↓',           'game_down',  '{"hotkey": "ArrowDown"}'),
    ('falling_blocks',  8, 'button',  'btn_right',  '→',           'game_right', '{"hotkey": "ArrowRight"}'),
    ('falling_blocks',  9, 'button',  'btn_drop',   'Сбросить',    'game_drop',  '{"hotkey": "Space"}'),
    ('falling_blocks', 10, 'button',  'btn_pause',  'Пауза',       'game_pause', '{"hotkey": "KeyP"}'),
    ('falling_blocks', 11, 'label',   'help',       'Клавиши: ← → — сдвиг, ↓ — шаг вниз, пробел — сбросить, P — пауза. '
                                                    'Заполненная строка исчезает и даёт очко.', NULL, NULL);
