-- =====================================================================
-- Дата заказа: новый тип компонента 'date' (поле с календарём) и колонка erp_orders.order_date.
-- Дата — часть шапки заказа: сохраняется вместе с клиентом, учитывается "Отменой",
-- в списке заказов колонка "Дата" показывает её вместо времени создания.
-- =====================================================================

CREATE OR REPLACE FUNCTION ui_component_types()
RETURNS VARCHAR[] AS $$
    SELECT ARRAY['label', 'input', 'date', 'hidden', 'display', 'lookup', 'button', 'grid']::VARCHAR[];
$$ LANGUAGE sql IMMUTABLE;

-- Дата из поля формы: ГГГГ-ММ-ДД (поле с календарём) или ДД.ММ.ГГГГ; иначе NULL
CREATE FUNCTION ui_parse_date(p_text TEXT)
RETURNS DATE AS $$
DECLARE
    v_text TEXT := trim(p_text);
BEGIN
    IF v_text ~ '^\d{4}-\d{2}-\d{2}$' THEN
        RETURN to_date(v_text, 'YYYY-MM-DD');
    ELSIF v_text ~ '^\d{2}\.\d{2}\.\d{4}$' THEN
        RETURN to_date(v_text, 'DD.MM.YYYY');
    END IF;
    RETURN NULL;
EXCEPTION WHEN OTHERS THEN
    RETURN NULL;  -- несуществующая дата, например 31.02.2026
END;
$$ LANGUAGE plpgsql IMMUTABLE;


-- ---------------------------------------------------------------------
-- Данные
-- ---------------------------------------------------------------------
ALTER TABLE erp_orders ADD COLUMN order_date DATE;
UPDATE erp_orders SET order_date = created_at::DATE;
ALTER TABLE erp_orders
    ALTER COLUMN order_date SET NOT NULL,
    ALTER COLUMN order_date SET DEFAULT current_date;

-- Колонка order_date представления остаётся текстом для таблицы; дата для сортировки — в конце
CREATE OR REPLACE VIEW erp_orders_v AS
SELECT o.id,
       o.created_at,
       to_char(o.order_date, 'DD.MM.YYYY')       AS order_date,
       o.customer_id,
       c.name                                    AS customer,
       o.status,
       COALESCE(l.lines_count, 0)                AS lines_count,
       COALESCE(l.total, 0)                      AS total,
       COALESCE(p.paid, 0)                       AS paid,
       o.order_date                              AS order_date_value
FROM erp_orders o
JOIN erp_customers c ON c.id = o.customer_id
LEFT JOIN (SELECT order_id, count(*) AS lines_count, sum(quantity * price) AS total
           FROM erp_order_lines GROUP BY order_id) l ON l.order_id = o.id
LEFT JOIN (SELECT order_id, sum(amount) AS paid
           FROM erp_order_payments GROUP BY order_id) p ON p.order_id = o.id;

UPDATE erp_grid_columns SET sort_column = 'order_date_value'
WHERE action_name = 'orders_page' AND field_name = 'order_date';


-- ---------------------------------------------------------------------
-- Шапка заказа: клиент и дата
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION order_upsert(p_data JSON)
RETURNS BIGINT AS $$
DECLARE
    v_id_text  TEXT   := NULLIF(trim(p_data->>'id'), '');
    v_customer BIGINT := ui_parse_id(p_data->>'customer_id');
    v_date     DATE   := ui_parse_date(p_data->>'order_date');
    v_id       BIGINT;
BEGIN
    IF v_customer IS NULL THEN
        RAISE EXCEPTION 'Выберите клиента';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM erp_customers WHERE id = v_customer) THEN
        RAISE EXCEPTION 'Клиент не найден — возможно, он удалён';
    END IF;
    IF v_date IS NULL THEN
        RAISE EXCEPTION 'Укажите дату заказа';
    END IF;

    IF v_id_text IS NULL THEN
        INSERT INTO erp_orders (customer_id, order_date, status)
        VALUES (v_customer, v_date, 'DRAFT')
        RETURNING id INTO v_id;
        RETURN v_id;
    END IF;

    UPDATE erp_orders SET customer_id = v_customer, order_date = v_date
    WHERE id = ui_parse_id(v_id_text)
    RETURNING id INTO v_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Заказ №% не найден — возможно, он уже удалён', v_id_text;
    END IF;
    RETURN v_id;
END;
$$ LANGUAGE plpgsql;

-- Новый заказ открывается с сегодняшней датой и нулевой суммой
CREATE OR REPLACE FUNCTION order_new_open(p_data JSON)
RETURNS JSON AS $$
BEGIN
    RETURN ui_ok(ui_open_form('order_new', jsonb_build_object(
        'order_date', to_char(current_date, 'YYYY-MM-DD'),
        'order_total', ui_format_money(0))));
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION order_edit_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_order erp_orders_v%ROWTYPE;
BEGIN
    SELECT * INTO v_order FROM erp_orders_v WHERE id = ui_parse_id(p_data->>'id');
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Заказ №% не найден — возможно, он уже удалён', p_data->>'id';
    END IF;

    IF v_order.status <> 'DRAFT' THEN
        INSERT INTO erp_order_snapshots (order_id, state)
        VALUES (v_order.id, order_state(v_order.id))
        ON CONFLICT (order_id) DO NOTHING;
    END IF;

    RETURN ui_ok(ui_open_form('order_new',
        p_title => format(CASE WHEN v_order.status = 'DRAFT' THEN 'Заказ №%s (черновик)' ELSE 'Заказ №%s' END,
                          v_order.id),
        p_data  => jsonb_build_object(
            'id', v_order.id::TEXT,
            'customer_id', v_order.customer_id::TEXT,
            'customer_id__display', v_order.customer,
            'order_date', to_char(v_order.order_date_value, 'YYYY-MM-DD'),
            'order_total', ui_format_money(v_order.total))));
END;
$$ LANGUAGE plpgsql;


-- ---------------------------------------------------------------------
-- Снимок заказа для "Отмены" — теперь с датой
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION order_state(p_id BIGINT)
RETURNS JSONB AS $$
    SELECT jsonb_build_object(
        'customer_id', o.customer_id,
        'order_date', o.order_date,
        'lines', COALESCE((
            SELECT jsonb_agg(jsonb_build_object(
                       'id', l.id, 'product_id', l.product_id, 'quantity', l.quantity, 'price', l.price)
                   ORDER BY l.id)
            FROM erp_order_lines l
            WHERE l.order_id = o.id), '[]'::jsonb),
        'payments', COALESCE((
            SELECT jsonb_agg(jsonb_build_object('id', p.id, 'paid_on', p.paid_on, 'amount', p.amount)
                   ORDER BY p.id)
            FROM erp_order_payments p
            WHERE p.order_id = o.id), '[]'::jsonb))
    FROM erp_orders o
    WHERE o.id = p_id;
$$ LANGUAGE sql STABLE;

-- Снимки, сделанные до этой миграции, дополняются текущей датой заказа
UPDATE erp_order_snapshots s SET state = s.state || jsonb_build_object('order_date', o.order_date)
FROM erp_orders o
WHERE o.id = s.order_id AND NOT s.state ? 'order_date';

CREATE OR REPLACE FUNCTION order_restore(p_id BIGINT, p_state JSONB)
RETURNS VOID AS $$
BEGIN
    UPDATE erp_orders
    SET customer_id = (p_state->>'customer_id')::BIGINT,
        order_date  = (p_state->>'order_date')::DATE
    WHERE id = p_id;

    DELETE FROM erp_order_lines WHERE order_id = p_id;
    INSERT INTO erp_order_lines (id, order_id, product_id, quantity, price)
    SELECT id, p_id, product_id, quantity, price
    FROM jsonb_to_recordset(p_state->'lines') AS t(id BIGINT, product_id BIGINT, quantity INT, price NUMERIC);

    DELETE FROM erp_order_payments WHERE order_id = p_id;
    INSERT INTO erp_order_payments (id, order_id, paid_on, amount)
    SELECT id, p_id, paid_on, amount
    FROM jsonb_to_recordset(p_state->'payments') AS t(id BIGINT, paid_on DATE, amount NUMERIC);
END;
$$ LANGUAGE plpgsql;

-- "Отмена": шапка (клиент и дата) берётся из формы — её изменения ещё не записаны в базу
CREATE OR REPLACE FUNCTION order_cancel(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_order    erp_orders%ROWTYPE;
    v_snapshot JSONB;
    v_changed  BOOLEAN;
    v_close    JSONB := jsonb_build_array(ui_close_form(), ui_refresh_grid('orders_grid', p_keep_page => TRUE));
BEGIN
    SELECT * INTO v_order FROM erp_orders WHERE id = ui_parse_id(p_data->>'id');
    IF NOT FOUND THEN
        -- Заказ ещё не создавался или уже удалён — отменять нечего
        RETURN ui_ok(v_close);
    END IF;

    SELECT state INTO v_snapshot FROM erp_order_snapshots WHERE order_id = v_order.id;

    v_changed := CASE
        WHEN v_order.status = 'DRAFT' THEN
            EXISTS (SELECT 1 FROM erp_order_lines WHERE order_id = v_order.id)
            OR EXISTS (SELECT 1 FROM erp_order_payments WHERE order_id = v_order.id)
        ELSE
            v_snapshot IS NOT NULL
            AND v_snapshot IS DISTINCT FROM order_state(v_order.id) || jsonb_build_object(
                'customer_id', ui_parse_id(p_data->>'customer_id'),
                'order_date', ui_parse_date(p_data->>'order_date'))
    END;

    IF v_changed AND (p_data->>'confirmed') IS DISTINCT FROM 'true' THEN
        RETURN ui_ok(ui_confirm(
            CASE WHEN v_order.status = 'DRAFT'
                THEN format('Закрыть без сохранения? Черновик заказа №%s с позициями и оплатами будет удалён.',
                            v_order.id)
                ELSE format('Закрыть без сохранения? Изменения в заказе №%s будут отменены.', v_order.id)
            END,
            'order_cancel',
            jsonb_build_object('id', v_order.id::TEXT, 'confirmed', TRUE),
            p_confirm_label => 'Не сохранять'));
    END IF;

    IF v_order.status = 'DRAFT' THEN
        DELETE FROM erp_orders WHERE id = v_order.id;  -- позиции и оплаты удаляются каскадно
    ELSIF v_snapshot IS NOT NULL THEN
        PERFORM order_restore(v_order.id, v_snapshot);
        DELETE FROM erp_order_snapshots WHERE order_id = v_order.id;
    END IF;

    RETURN ui_ok(v_close);
END;
$$ LANGUAGE plpgsql;


-- ---------------------------------------------------------------------
-- Карточка заказа: поле "Дата заказа" сразу под клиентом
-- ---------------------------------------------------------------------
UPDATE erp_form_components SET sort_order = sort_order + 1
WHERE form_name = 'order_new'
  AND sort_order > (SELECT sort_order FROM erp_form_components
                    WHERE form_name = 'order_new' AND component_name = 'customer_id');

INSERT INTO erp_form_components (form_name, sort_order, component_type, component_name, label)
SELECT 'order_new', sort_order + 1, 'date', 'order_date', 'Дата заказа'
FROM erp_form_components
WHERE form_name = 'order_new' AND component_name = 'customer_id';

UPDATE erp_forms SET updated_at = now() WHERE form_name = 'order_new';
