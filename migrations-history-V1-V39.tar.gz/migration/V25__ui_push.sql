-- =====================================================================
-- Команды в UI из базы — без запроса пользователя.
--
--     SELECT ui_push(ui_message('Через 5 минут сервер будет перезапущен'));    -- всем
--     PERFORM ui_push_to('orders', ui_refresh_grid('orders_grid', TRUE));      -- где открыта форма
--
-- Путь: ui_push → pg_notify('erp_ui', сообщение) → сервер (LISTEN erp_ui) → браузеры (SSE /api/ui/events).
-- Сообщение: {"form": имя формы или null, "ui_instructions": [...]}. Браузер выполняет инструкции;
-- если указана форма — только там, где она открыта, и в её контексте (set_values, set_title).
--
-- Уведомление уходит при фиксации транзакции: откаченные изменения ничего не отправят,
-- одинаковые сообщения одной транзакции PostgreSQL отправляет один раз.
-- Ограничение NOTIFY — 8000 байт на сообщение.
-- =====================================================================

-- Отправить инструкции в браузеры, где открыта форма p_form (NULL — во все)
CREATE FUNCTION erp.ui_push_to(p_form VARCHAR, VARIADIC p_instructions JSONB[])
RETURNS VOID AS $$
DECLARE
    v_message TEXT := jsonb_build_object(
        'form', p_form,
        'ui_instructions', erp.ui_ok(VARIADIC p_instructions)->'ui_instructions')::TEXT;
BEGIN
    IF octet_length(v_message) > 7900 THEN
        RAISE EXCEPTION 'ui_push: сообщение длиннее 8000 байт — передайте в нём меньше данных';
    END IF;
    PERFORM pg_notify('erp_ui', v_message);
END;
$$ LANGUAGE plpgsql;

-- Отправить инструкции во все открытые браузеры
CREATE FUNCTION erp.ui_push(VARIADIC p_instructions JSONB[])
RETURNS VOID AS $$
    SELECT erp.ui_push_to(NULL, VARIADIC p_instructions);
$$ LANGUAGE sql;


-- ---------------------------------------------------------------------
-- Пример: список заказов обновляется у всех, как только кто-то меняет заказ,
-- его позиции или оплаты (в том числе прямо в базе, минуя UI)
-- ---------------------------------------------------------------------
CREATE FUNCTION orders_changed_push()
RETURNS TRIGGER AS $$
BEGIN
    PERFORM ui_push_to('orders', ui_refresh_grid('orders_grid', p_keep_page => TRUE));
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER orders_push AFTER INSERT OR UPDATE OR DELETE ON orders
    FOR EACH STATEMENT EXECUTE FUNCTION orders_changed_push();
CREATE TRIGGER order_lines_push AFTER INSERT OR UPDATE OR DELETE ON order_lines
    FOR EACH STATEMENT EXECUTE FUNCTION orders_changed_push();
CREATE TRIGGER order_payments_push AFTER INSERT OR UPDATE OR DELETE ON order_payments
    FOR EACH STATEMENT EXECUTE FUNCTION orders_changed_push();
