-- =====================================================================
-- Компонент "combobox" — выпадающий список.
--
--  * Источник элементов — действие (action компонента). Получает значения полей формы
--    (список может зависеть от других полей) и возвращает
--        {"status": "success", "items": [{"id": 1, "label": "Мебель"}, ...]}
--    pgerp.ui_combo_items('таблица', 'колонка подписи') строит ответ по любой таблице или представлению.
--  * Значение компонента — id выбранного элемента: уходит в действия кнопок и источники таблиц.
--    Первый пункт — пустой: options.placeholder (по умолчанию «Не выбрано»).
--  * При выборе перечитываются таблицы с master = имя списка и компонент options.refresh
--    (таблица, дерево или другой список — зависимые списки).
--  * refresh_grid('имя списка') перечитывает элементы, выбор сохраняется.
--
-- Пример: в справочнике "Товары" фильтр «Группа» над таблицей.
-- =====================================================================

-- ---------------------------------------------------------------------
-- Ядро
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION pgerp.ui_component_types()
RETURNS VARCHAR[] AS $$
    SELECT ARRAY['label', 'input', 'date', 'hidden', 'display', 'lookup', 'combobox', 'button', 'grid',
                 'board', 'timer', 'tree']::VARCHAR[];
$$ LANGUAGE sql IMMUTABLE;

-- Элементы выпадающего списка из таблицы или представления: {status, items: [{id, label}]},
-- по алфавиту подписи. Имена колонок задаёт код функции-источника, не клиент.
CREATE FUNCTION pgerp.ui_combo_items(p_source REGCLASS,
                                     p_label_column VARCHAR DEFAULT 'name',
                                     p_value_column VARCHAR DEFAULT 'id')
RETURNS JSON AS $$
DECLARE
    v_items JSON;
BEGIN
    EXECUTE format(
        'SELECT json_agg(json_build_object(''id'', t.%2$I, ''label'', t.%1$I) ORDER BY t.%1$I, t.%2$I)
         FROM %3$s t',
        p_label_column, p_value_column, p_source)
    INTO v_items;

    RETURN json_build_object('status', 'success', 'items', COALESCE(v_items, '[]'::json));
END;
$$ LANGUAGE plpgsql STABLE;

-- Сохранение формы: выпадающий список требует действие-источник и может быть мастером таблицы
CREATE OR REPLACE FUNCTION pgerp.ui_form_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_form_name  VARCHAR := p_data->>'name';
    v_title      VARCHAR := ui_text(p_data, 'title');
    v_folder     VARCHAR := ui_text(p_data, 'folder');
    v_components JSON    := COALESCE(p_data->'components', '[]'::json);
    v_comp       RECORD;
BEGIN
    PERFORM ui_require(v_form_name ~ '^[a-z_][a-z0-9_]*$',
                       'Имя формы: латинские буквы в нижнем регистре, цифры и "_"');

    FOR v_comp IN
        SELECT c->>'type' AS type, c->>'name' AS name, NULLIF(c->>'action', '') AS action,
               NULLIF(c->>'master', '') AS master, c->'options' AS options, n
        FROM json_array_elements(v_components) WITH ORDINALITY AS t(c, n)
    LOOP
        PERFORM ui_require(v_comp.type = ANY (ui_component_types()),
                           format('Компонент №%s: неизвестный тип "%s"', v_comp.n, v_comp.type));
        PERFORM ui_require(v_comp.name ~ '^[a-z_][a-z0-9_]*$',
                           format('Компонент №%s: имя — латинские буквы в нижнем регистре, цифры и "_"', v_comp.n));

        IF v_comp.type = 'grid' AND v_comp.action IS NULL THEN
            RAISE EXCEPTION 'Таблица "%": выберите действие-источник данных', v_comp.name;
        END IF;
        IF v_comp.type = 'tree' AND v_comp.action IS NULL THEN
            RAISE EXCEPTION 'Дерево "%": выберите действие-источник данных', v_comp.name;
        END IF;
        IF v_comp.type = 'combobox' AND v_comp.action IS NULL THEN
            RAISE EXCEPTION 'Выпадающий список "%": выберите действие-источник элементов', v_comp.name;
        END IF;
        IF v_comp.type = 'lookup' AND v_comp.action IS NULL THEN
            RAISE EXCEPTION 'Поле выбора "%": выберите действие открытия списка', v_comp.name;
        END IF;
        IF v_comp.type = 'timer' AND v_comp.action IS NULL THEN
            RAISE EXCEPTION 'Таймер "%": выберите действие', v_comp.name;
        END IF;

        IF v_comp.action IS NOT NULL THEN
            PERFORM ui_require(
                EXISTS (SELECT 1 FROM pgerp.ui_actions WHERE action_name = v_comp.action AND NOT is_system),
                format('Компонент "%s": действие "%s" не зарегистрировано', v_comp.name, v_comp.action));
        END IF;
        IF v_comp.type = 'grid' AND v_comp.master IS NOT NULL THEN
            PERFORM ui_require(
                EXISTS (SELECT 1 FROM json_array_elements(v_components) c
                        WHERE c->>'name' = v_comp.master AND c->>'type' IN ('input', 'hidden', 'lookup', 'combobox', 'tree')),
                format('Таблица "%s": поле-мастер "%s" не найдено среди полей формы', v_comp.name, v_comp.master));
        END IF;
        IF v_comp.options IS NOT NULL AND json_typeof(v_comp.options) NOT IN ('object', 'null') THEN
            RAISE EXCEPTION 'Компонент "%": параметры должны быть объектом JSON', v_comp.name;
        END IF;
    END LOOP;

    PERFORM ui_require(
        (SELECT count(*) = count(DISTINCT c->>'name') FROM json_array_elements(v_components) c),
        'Имена компонентов должны быть уникальны');

    INSERT INTO pgerp.forms (form_name, title, folder)
    VALUES (v_form_name, COALESCE(v_title, v_form_name), v_folder)
    ON CONFLICT (form_name) DO UPDATE
        SET title = EXCLUDED.title, folder = EXCLUDED.folder, updated_at = now();

    DELETE FROM pgerp.form_components WHERE form_name = v_form_name;

    INSERT INTO pgerp.form_components
        (form_name, sort_order, component_type, component_name, label, action_event, master_field, tab, options)
    SELECT v_form_name, n, c->>'type', c->>'name', c->>'label', NULLIF(c->>'action', ''),
           CASE WHEN c->>'type' = 'grid' THEN NULLIF(c->>'master', '') END,
           CASE WHEN c->>'type' NOT IN ('hidden', 'timer') THEN NULLIF(trim(c->>'tab'), '') END,
           CASE WHEN json_typeof(c->'options') = 'object' AND (c->'options')::jsonb <> '{}' THEN (c->'options')::jsonb END
    FROM json_array_elements(v_components) WITH ORDINALITY AS t(c, n);

    RETURN ui_ok(ui_message(format('Форма "%s" сохранена', v_form_name)));
END;
$$ LANGUAGE plpgsql;


-- ---------------------------------------------------------------------
-- "Товары": фильтр по группе
-- ---------------------------------------------------------------------
-- Группы с полным путём: "Мебель / Столы" — по нему же список упорядочен
CREATE VIEW product_groups_v AS
SELECT id, parent_id, name, product_group_path(id) AS path
FROM product_groups;

CREATE FUNCTION product_groups_combo(p_data JSON)
RETURNS JSON AS $$
    SELECT ui_combo_items('product_groups_v', 'path');
$$ LANGUAGE sql STABLE;

-- Выбрана группа — только её товары (через фильтр по мастеру), иначе все
CREATE OR REPLACE FUNCTION products_page(p_data JSON)
RETURNS JSON AS $$
    SELECT CASE
        WHEN ui_parse_id(p_data->>'group_filter') IS NULL
            THEN ui_grid_page('products_page', p_data, 'products_v', NULL, 'name', 'asc')
        ELSE ui_grid_page('products_page',
                          (p_data::jsonb || jsonb_build_object('master_id', p_data->>'group_filter'))::json,
                          'products_v', 'group_id', 'name', 'asc')
    END;
$$ LANGUAGE sql;

INSERT INTO pgerp.ui_actions (action_name, function_name, description) VALUES
    ('product_groups_combo', 'product_groups_combo', 'Список: группы товаров');

-- Фильтр — первым, над кнопками и таблицей
UPDATE pgerp.form_components SET sort_order = sort_order + 1 WHERE form_name = 'products';

INSERT INTO pgerp.form_components (form_name, sort_order, component_type, component_name, label, action_event, options)
VALUES ('products', 1, 'combobox', 'group_filter', 'Группа', 'product_groups_combo',
        '{"placeholder": "Все группы", "refresh": "products_grid"}');

UPDATE pgerp.forms SET updated_at = now() WHERE form_name = 'products';
