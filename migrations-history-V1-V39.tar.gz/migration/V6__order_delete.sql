-- =====================================================================
-- Удаление заказа с подтверждением.
-- Действия над строками таблицы описываются метаданными; подтверждение
-- запрашивает сама база инструкцией UI 'confirm'.
-- =====================================================================

-- Кнопки в строках таблицы. Привязаны к действию-источнику данных, как и колонки.
-- При нажатии вызывается row_action с {"id": <id строки>}.
CREATE TABLE erp_grid_row_actions (
    source_action VARCHAR(100) NOT NULL REFERENCES erp_ui_actions ON DELETE CASCADE,
    sort_order    INT          NOT NULL,
    row_action    VARCHAR(100) NOT NULL REFERENCES erp_ui_actions,
    label         VARCHAR(50)  NOT NULL,
    style         VARCHAR(20)  NOT NULL DEFAULT 'default' CHECK (style IN ('default', 'danger')),
    PRIMARY KEY (source_action, row_action)
);

CREATE FUNCTION ui_grid_row_actions(p_action VARCHAR)
RETURNS JSON AS $$
    SELECT COALESCE(json_agg(json_build_object(
               'action', row_action,
               'label', label,
               'style', style)
           ORDER BY sort_order), '[]'::json)
    FROM erp_grid_row_actions
    WHERE source_action = p_action;
$$ LANGUAGE sql STABLE;


-- Источник данных таблицы: то же, что в V3, плюс row_actions.
CREATE OR REPLACE FUNCTION orders_page(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_limit       INT := ui_page_param(p_data, 'limit', 10, 100);
    v_page        INT := ui_page_param(p_data, 'page', 1, 1000000);
    v_total_rows  INT;
    v_total_pages INT;
    v_rows        JSON;
BEGIN
    SELECT count(*) INTO v_total_rows FROM erp_orders;

    v_total_pages := GREATEST(CEIL(v_total_rows::NUMERIC / v_limit)::INT, 1);
    v_page := LEAST(v_page, v_total_pages);

    SELECT json_agg(t) INTO v_rows
    FROM (
        SELECT id,
               to_char(created_at, 'DD.MM.YYYY HH24:MI') AS order_date,
               customer_name                            AS customer,
               product_name                             AS product,
               quantity,
               quantity * price                         AS total,
               status
        FROM erp_orders
        ORDER BY id DESC
        LIMIT v_limit
        OFFSET (v_page - 1) * v_limit
    ) t;

    RETURN json_build_object(
        'status', 'success',
        'meta', json_build_object(
            'current_page', v_page,
            'limit', v_limit,
            'total_rows', v_total_rows,
            'total_pages', v_total_pages),
        'columns', ui_grid_columns('orders_page'),
        'row_actions', ui_grid_row_actions('orders_page'),
        'rows', COALESCE(v_rows, '[]'::json));
END;
$$ LANGUAGE plpgsql;


-- Удаление заказа в два шага:
--   {"id": 5}                    -> инструкция confirm с описанием заказа
--   {"id": 5, "confirmed": true} -> удаление, обновление таблицы, сообщение
CREATE FUNCTION order_delete(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_order erp_orders%ROWTYPE;
BEGIN
    IF p_data->>'id' IS NULL OR p_data->>'id' !~ '^\d{1,18}$' THEN
        RAISE EXCEPTION 'Не указан заказ';
    END IF;

    SELECT * INTO v_order FROM erp_orders WHERE id = (p_data->>'id')::BIGINT;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Заказ №% не найден — возможно, он уже удалён', p_data->>'id';
    END IF;

    IF (p_data->>'confirmed') IS DISTINCT FROM 'true' THEN
        RETURN json_build_object(
            'status', 'success',
            'ui_instructions', json_build_object(
                'command', 'confirm',
                'text', format('Удалить заказ №%s?' || E'\n' || '%s — %s, %s шт., сумма %s',
                               v_order.id, v_order.customer_name, v_order.product_name, v_order.quantity,
                               to_char(v_order.quantity * v_order.price, 'FM999G999G999G990D00')),
                'confirm_label', 'Удалить',
                'action', 'order_delete',
                'data', json_build_object('id', v_order.id, 'confirmed', TRUE)));
    END IF;

    DELETE FROM erp_orders WHERE id = v_order.id;

    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_array(
            json_build_object('command', 'refresh_grid', 'grid', 'orders_grid', 'keep_page', TRUE),
            json_build_object('command', 'show_message', 'text', format('Заказ №%s удалён', v_order.id))));
END;
$$ LANGUAGE plpgsql;

INSERT INTO erp_ui_actions (action_name, function_name, description)
VALUES ('order_delete', 'order_delete', 'Удаление заказа с подтверждением');

INSERT INTO erp_grid_row_actions (source_action, sort_order, row_action, label, style)
VALUES ('orders_page', 1, 'order_delete', 'Удалить', 'danger');
