-- =====================================================================
-- Master/details формы и поля выбора из справочника.
--
--  * grid с master_field — таблица-детали: получает master_id из поля формы-мастера;
--    у одной формы может быть несколько таких таблиц.
--  * lookup — поле выбора: кнопка "..." открывает форму-список в режиме выбора.
--  * Новые инструкции UI: set_values, set_title; open_form.select — режим выбора.
--
-- Заказы переделаны в шапку (клиент) + позиции + оплаты;
-- клиенты и товары вынесены в справочники. Существующие заказы переносятся.
-- =====================================================================

-- ---------------------------------------------------------------------
-- Метаданные форм
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION ui_component_types()
RETURNS VARCHAR[] AS $$
    SELECT ARRAY['label', 'input', 'hidden', 'lookup', 'button', 'grid']::VARCHAR[];
$$ LANGUAGE sql IMMUTABLE;

-- Для grid: имя поля формы, значение которого передаётся в источник данных как master_id
ALTER TABLE erp_form_components ADD COLUMN master_field VARCHAR(50);


CREATE OR REPLACE FUNCTION ui_form_get(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_form_name VARCHAR := p_data->>'form';
    v_form      JSON;
BEGIN
    SELECT json_build_object(
               'name', f.form_name,
               'title', f.title,
               'components', COALESCE((
                   SELECT json_agg(json_build_object(
                              'type', c.component_type,
                              'name', c.component_name,
                              'label', c.label,
                              'action', c.action_event,
                              'master', c.master_field)
                          ORDER BY c.sort_order)
                   FROM erp_form_components c
                   WHERE c.form_name = f.form_name), '[]'::json))
    INTO v_form
    FROM erp_forms f
    WHERE f.form_name = v_form_name;

    IF v_form IS NULL THEN
        RAISE EXCEPTION 'Форма "%" не найдена', v_form_name;
    END IF;

    RETURN json_build_object('status', 'success', 'form', v_form);
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION ui_form_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_form_name  VARCHAR := p_data->>'name';
    v_title      VARCHAR := NULLIF(trim(p_data->>'title'), '');
    v_components JSON    := COALESCE(p_data->'components', '[]'::json);
    v_comp       RECORD;
BEGIN
    IF v_form_name IS NULL OR v_form_name !~ '^[a-z_][a-z0-9_]*$' THEN
        RAISE EXCEPTION 'Имя формы: латинские буквы в нижнем регистре, цифры и "_"';
    END IF;

    FOR v_comp IN
        SELECT c->>'type' AS type, c->>'name' AS name, NULLIF(c->>'action', '') AS action,
               NULLIF(c->>'master', '') AS master, n
        FROM json_array_elements(v_components) WITH ORDINALITY AS t(c, n)
    LOOP
        IF v_comp.type IS NULL OR NOT v_comp.type = ANY (ui_component_types()) THEN
            RAISE EXCEPTION 'Компонент №%: неизвестный тип "%"', v_comp.n, v_comp.type;
        END IF;
        IF v_comp.name IS NULL OR v_comp.name !~ '^[a-z_][a-z0-9_]*$' THEN
            RAISE EXCEPTION 'Компонент №%: имя — латинские буквы в нижнем регистре, цифры и "_"', v_comp.n;
        END IF;
        IF v_comp.type = 'grid' AND v_comp.action IS NULL THEN
            RAISE EXCEPTION 'Таблица "%": выберите действие-источник данных', v_comp.name;
        END IF;
        IF v_comp.type = 'lookup' AND v_comp.action IS NULL THEN
            RAISE EXCEPTION 'Поле выбора "%": выберите действие открытия списка', v_comp.name;
        END IF;
        IF v_comp.action IS NOT NULL
           AND NOT EXISTS (SELECT 1 FROM erp_ui_actions WHERE action_name = v_comp.action AND NOT is_system) THEN
            RAISE EXCEPTION 'Компонент "%": действие "%" не зарегистрировано', v_comp.name, v_comp.action;
        END IF;
        IF v_comp.type = 'grid' AND v_comp.master IS NOT NULL
           AND NOT EXISTS (SELECT 1 FROM json_array_elements(v_components) c
                           WHERE c->>'name' = v_comp.master AND c->>'type' IN ('input', 'hidden', 'lookup')) THEN
            RAISE EXCEPTION 'Таблица "%": поле-мастер "%" не найдено среди полей формы', v_comp.name, v_comp.master;
        END IF;
    END LOOP;

    IF (SELECT count(*) <> count(DISTINCT c->>'name') FROM json_array_elements(v_components) c) THEN
        RAISE EXCEPTION 'Имена компонентов должны быть уникальны';
    END IF;

    INSERT INTO erp_forms (form_name, title)
    VALUES (v_form_name, COALESCE(v_title, v_form_name))
    ON CONFLICT (form_name) DO UPDATE
        SET title = EXCLUDED.title, updated_at = now();

    DELETE FROM erp_form_components WHERE form_name = v_form_name;

    INSERT INTO erp_form_components
        (form_name, sort_order, component_type, component_name, label, action_event, master_field)
    SELECT v_form_name, n, c->>'type', c->>'name', c->>'label', NULLIF(c->>'action', ''),
           CASE WHEN c->>'type' = 'grid' THEN NULLIF(c->>'master', '') END
    FROM json_array_elements(v_components) WITH ORDINALITY AS t(c, n);

    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_object(
            'command', 'show_message',
            'text', format('Форма "%s" сохранена', v_form_name)));
END;
$$ LANGUAGE plpgsql;


-- ---------------------------------------------------------------------
-- Общие помощники
-- ---------------------------------------------------------------------

-- Идентификатор из текста или NULL
CREATE FUNCTION ui_parse_id(p_text TEXT)
RETURNS BIGINT AS $$
    SELECT CASE WHEN trim(p_text) ~ '^\d{1,18}$' THEN trim(p_text)::BIGINT END;
$$ LANGUAGE sql IMMUTABLE;

-- Денежная сумма из текста ("1 500,50", "99.9") или NULL
CREATE FUNCTION ui_parse_money(p_text TEXT)
RETURNS NUMERIC AS $$
    SELECT CASE WHEN v ~ '^\d{1,10}(\.\d{1,2})?$' THEN v::NUMERIC END
    FROM (SELECT replace(replace(trim(p_text), ' ', ''), ',', '.') AS v) t;
$$ LANGUAGE sql IMMUTABLE;

-- Денежная сумма для поля ввода: "1500,50"
CREATE FUNCTION ui_money_input(p_value NUMERIC)
RETURNS TEXT AS $$
    SELECT translate(p_value::TEXT, '.', ',');
$$ LANGUAGE sql IMMUTABLE;


-- Универсальный источник данных таблицы: пагинация, сортировка, фильтр по мастеру.
--   p_source        — таблица/представление (задаётся кодом функции-источника, не клиентом);
--   p_master_column — колонка связи с мастером; без master_id в запросе строк нет (новая запись).
-- В строки попадают все поля источника: кроме колонок таблицы они доступны действиям
-- строк и режиму выбора (например, подстановка цены товара).
CREATE FUNCTION ui_grid_page(p_action VARCHAR, p_data JSON, p_source REGCLASS,
                             p_master_column VARCHAR DEFAULT NULL,
                             p_default_sort VARCHAR DEFAULT 'id', p_default_dir VARCHAR DEFAULT 'desc')
RETURNS JSON AS $$
DECLARE
    v_limit       INT    := ui_page_param(p_data, 'limit', 10, 100);
    v_page        INT    := ui_page_param(p_data, 'page', 1, 1000000);
    v_master      BIGINT := ui_parse_id(p_data->>'master_id');
    v_where       TEXT   := 'TRUE';
    v_sort        RECORD;
    v_sort_column TEXT;
    v_sort_dir    TEXT;
    v_total_rows  INT;
    v_total_pages INT;
    v_rows        JSON;
BEGIN
    IF p_master_column IS NOT NULL THEN
        v_where := format('%I = $1', p_master_column);
    END IF;

    SELECT * INTO v_sort FROM ui_grid_sort(p_action, p_data, p_default_sort, p_default_dir);
    v_sort_column := COALESCE(v_sort.sort_column, 'id');
    v_sort_dir    := COALESCE(v_sort.dir, p_default_dir);

    EXECUTE format('SELECT count(*) FROM %s WHERE %s', p_source, v_where)
    INTO v_total_rows
    USING v_master;

    v_total_pages := GREATEST(CEIL(v_total_rows::NUMERIC / v_limit)::INT, 1);
    v_page := LEAST(v_page, v_total_pages);

    EXECUTE format('SELECT json_agg(t) FROM (SELECT * FROM %s WHERE %s ORDER BY %I %s, id %s LIMIT $2 OFFSET $3) t',
                   p_source, v_where, v_sort_column, v_sort_dir, v_sort_dir)
    INTO v_rows
    USING v_master, v_limit, (v_page - 1) * v_limit;

    RETURN json_build_object(
        'status', 'success',
        'meta', json_build_object(
            'current_page', v_page,
            'limit', v_limit,
            'total_rows', v_total_rows,
            'total_pages', v_total_pages,
            'sort', json_build_object('field', COALESCE(v_sort.field, 'id'), 'dir', v_sort_dir)),
        'columns', ui_grid_columns(p_action),
        'row_actions', ui_grid_row_actions(p_action),
        'rows', COALESCE(v_rows, '[]'::json));
END;
$$ LANGUAGE plpgsql;


-- ---------------------------------------------------------------------
-- Справочники и новая структура заказа (с переносом данных)
-- ---------------------------------------------------------------------
CREATE TABLE erp_customers (
    id         BIGSERIAL    PRIMARY KEY,
    name       VARCHAR(200) NOT NULL UNIQUE,
    phone      VARCHAR(50),
    created_at TIMESTAMPTZ  NOT NULL DEFAULT now()
);

CREATE TABLE erp_products (
    id    BIGSERIAL     PRIMARY KEY,
    name  VARCHAR(200)  NOT NULL UNIQUE,
    price NUMERIC(12,2) NOT NULL CHECK (price >= 0)
);

CREATE TABLE erp_order_lines (
    id         BIGSERIAL     PRIMARY KEY,
    order_id   BIGINT        NOT NULL REFERENCES erp_orders ON DELETE CASCADE,
    product_id BIGINT        NOT NULL REFERENCES erp_products,
    quantity   INT           NOT NULL CHECK (quantity > 0),
    price      NUMERIC(12,2) NOT NULL CHECK (price >= 0)
);
CREATE INDEX ON erp_order_lines (order_id);

CREATE TABLE erp_order_payments (
    id       BIGSERIAL     PRIMARY KEY,
    order_id BIGINT        NOT NULL REFERENCES erp_orders ON DELETE CASCADE,
    paid_on  DATE          NOT NULL DEFAULT current_date,
    amount   NUMERIC(12,2) NOT NULL CHECK (amount > 0)
);
CREATE INDEX ON erp_order_payments (order_id);

INSERT INTO erp_customers (name)
SELECT DISTINCT customer_name FROM erp_orders ORDER BY 1;

INSERT INTO erp_products (name, price)
SELECT product_name, max(price) FROM erp_orders GROUP BY product_name ORDER BY 1;

-- Каждый существующий заказ становится заказом с одной позицией
INSERT INTO erp_order_lines (order_id, product_id, quantity, price)
SELECT o.id, p.id, o.quantity, o.price
FROM erp_orders o
JOIN erp_products p ON p.name = o.product_name
ORDER BY o.id;

ALTER TABLE erp_orders ADD COLUMN customer_id BIGINT REFERENCES erp_customers;
UPDATE erp_orders o SET customer_id = c.id FROM erp_customers c WHERE c.name = o.customer_name;
ALTER TABLE erp_orders ALTER COLUMN customer_id SET NOT NULL;
CREATE INDEX ON erp_orders (customer_id);

-- Функция, работавшая со старыми полями заказа, больше не нужна
DELETE FROM erp_ui_actions WHERE action_name = 'order_create';
DROP FUNCTION order_create(JSON);

ALTER TABLE erp_orders
    DROP COLUMN customer_name,
    DROP COLUMN product_name,
    DROP COLUMN quantity,
    DROP COLUMN price;


CREATE VIEW erp_orders_v AS
SELECT o.id,
       o.created_at,
       to_char(o.created_at, 'DD.MM.YYYY HH24:MI') AS order_date,
       o.customer_id,
       c.name                                    AS customer,
       o.status,
       COALESCE(l.lines_count, 0)                AS lines_count,
       COALESCE(l.total, 0)                      AS total,
       COALESCE(p.paid, 0)                       AS paid
FROM erp_orders o
JOIN erp_customers c ON c.id = o.customer_id
LEFT JOIN (SELECT order_id, count(*) AS lines_count, sum(quantity * price) AS total
           FROM erp_order_lines GROUP BY order_id) l ON l.order_id = o.id
LEFT JOIN (SELECT order_id, sum(amount) AS paid
           FROM erp_order_payments GROUP BY order_id) p ON p.order_id = o.id;

CREATE VIEW erp_order_lines_v AS
SELECT l.id, l.order_id, l.product_id, p.name AS product, l.quantity, l.price, l.quantity * l.price AS total
FROM erp_order_lines l
JOIN erp_products p ON p.id = l.product_id;

-- price_input — цена в формате поля ввода; подставляется в позицию при выборе товара
CREATE VIEW erp_products_v AS
SELECT id, name, price, ui_money_input(price) AS price_input
FROM erp_products;

CREATE VIEW erp_order_payments_v AS
SELECT id, order_id, paid_on, to_char(paid_on, 'DD.MM.YYYY') AS paid_date, amount
FROM erp_order_payments;


-- ---------------------------------------------------------------------
-- Источники данных таблиц
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION orders_page(p_data JSON)
RETURNS JSON AS $$
    SELECT ui_grid_page('orders_page', p_data, 'erp_orders_v');
$$ LANGUAGE sql;

CREATE FUNCTION order_lines_page(p_data JSON)
RETURNS JSON AS $$
    SELECT ui_grid_page('order_lines_page', p_data, 'erp_order_lines_v', 'order_id', 'id', 'asc');
$$ LANGUAGE sql;

CREATE FUNCTION order_payments_page(p_data JSON)
RETURNS JSON AS $$
    SELECT ui_grid_page('order_payments_page', p_data, 'erp_order_payments_v', 'order_id', 'paid_date', 'asc');
$$ LANGUAGE sql;

CREATE FUNCTION customers_page(p_data JSON)
RETURNS JSON AS $$
    SELECT ui_grid_page('customers_page', p_data, 'erp_customers', NULL, 'name', 'asc');
$$ LANGUAGE sql;

CREATE FUNCTION products_page(p_data JSON)
RETURNS JSON AS $$
    SELECT ui_grid_page('products_page', p_data, 'erp_products_v', NULL, 'name', 'asc');
$$ LANGUAGE sql;


-- ---------------------------------------------------------------------
-- Заказ (шапка)
-- ---------------------------------------------------------------------

-- Создание/изменение шапки заказа. Возвращает id заказа.
CREATE FUNCTION order_upsert(p_data JSON)
RETURNS BIGINT AS $$
DECLARE
    v_id_text  TEXT   := NULLIF(trim(p_data->>'id'), '');
    v_customer BIGINT := ui_parse_id(p_data->>'customer_id');
    v_id       BIGINT;
BEGIN
    IF v_customer IS NULL THEN
        RAISE EXCEPTION 'Выберите клиента';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM erp_customers WHERE id = v_customer) THEN
        RAISE EXCEPTION 'Клиент не найден — возможно, он удалён';
    END IF;

    IF v_id_text IS NULL THEN
        INSERT INTO erp_orders (customer_id) VALUES (v_customer) RETURNING id INTO v_id;
        RETURN v_id;
    END IF;

    UPDATE erp_orders SET customer_id = v_customer
    WHERE id = ui_parse_id(v_id_text)
    RETURNING id INTO v_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Заказ №% не найден — возможно, он уже удалён', v_id_text;
    END IF;
    RETURN v_id;
END;
$$ LANGUAGE plpgsql;

-- Сохраняет шапку и возвращает инструкции, которые обновляют форму заказа:
-- у новой записи появляется id и заголовок, так что таблицы-детали начинают работать.
CREATE FUNCTION order_header_saved(p_is_new BOOLEAN, p_id BIGINT)
RETURNS JSONB AS $$
    SELECT CASE WHEN p_is_new THEN
        jsonb_build_array(
            jsonb_build_object('command', 'set_values', 'values', jsonb_build_object('id', p_id::TEXT)),
            jsonb_build_object('command', 'set_title', 'title', format('Заказ №%s', p_id)),
            jsonb_build_object('command', 'refresh_grid', 'grid', 'orders_grid'))
    ELSE
        jsonb_build_array(
            jsonb_build_object('command', 'refresh_grid', 'grid', 'orders_grid', 'keep_page', TRUE))
    END;
$$ LANGUAGE sql STABLE;


-- Кнопка "Сохранить": форма остаётся открытой, чтобы можно было работать с позициями
CREATE OR REPLACE FUNCTION order_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_is_new BOOLEAN := NULLIF(trim(p_data->>'id'), '') IS NULL;
    v_id     BIGINT  := order_upsert(p_data);
BEGIN
    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', order_header_saved(v_is_new, v_id) || jsonb_build_array(
            jsonb_build_object('command', 'show_message',
                               'text', format(CASE WHEN v_is_new THEN 'Заказ №%s создан' ELSE 'Заказ №%s сохранён' END,
                                              v_id))));
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION order_edit_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_order erp_orders_v%ROWTYPE;
BEGIN
    SELECT * INTO v_order FROM erp_orders_v WHERE id = ui_parse_id(p_data->>'id');
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Заказ №% не найден — возможно, он уже удалён', p_data->>'id';
    END IF;

    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_object(
            'command', 'open_form',
            'form', 'order_new',
            'modal', TRUE,
            'title', format('Заказ №%s', v_order.id),
            'data', json_build_object(
                'id', v_order.id::TEXT,
                'customer_id', v_order.customer_id::TEXT,
                'customer_id__display', v_order.customer)));
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION order_delete(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_order erp_orders_v%ROWTYPE;
BEGIN
    SELECT * INTO v_order FROM erp_orders_v WHERE id = ui_parse_id(p_data->>'id');
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Заказ №% не найден — возможно, он уже удалён', p_data->>'id';
    END IF;

    IF (p_data->>'confirmed') IS DISTINCT FROM 'true' THEN
        RETURN json_build_object(
            'status', 'success',
            'ui_instructions', json_build_object(
                'command', 'confirm',
                'text', format('Удалить заказ №%s?' || E'\n' || '%s — позиций: %s, сумма %s',
                               v_order.id, v_order.customer, v_order.lines_count, ui_format_money(v_order.total)),
                'confirm_label', 'Удалить',
                'action', 'order_delete',
                'data', json_build_object('id', v_order.id, 'confirmed', TRUE)));
    END IF;

    DELETE FROM erp_orders WHERE id = v_order.id;  -- позиции и оплаты удаляются каскадно

    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_array(
            json_build_object('command', 'refresh_grid', 'grid', 'orders_grid', 'keep_page', TRUE),
            json_build_object('command', 'show_message', 'text', format('Заказ №%s удалён', v_order.id))));
END;
$$ LANGUAGE plpgsql;


-- ---------------------------------------------------------------------
-- Позиции заказа (детали)
-- ---------------------------------------------------------------------

-- "Добавить позицию": у нового заказа сначала сохраняется шапка
CREATE FUNCTION order_line_new_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_is_new BOOLEAN := NULLIF(trim(p_data->>'id'), '') IS NULL;
    v_id     BIGINT  := order_upsert(p_data);
BEGIN
    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', order_header_saved(v_is_new, v_id) || jsonb_build_array(
            jsonb_build_object(
                'command', 'open_form',
                'form', 'order_line',
                'modal', TRUE,
                'title', 'Новая позиция',
                'data', jsonb_build_object('order_id', v_id::TEXT, 'quantity', '1'))));
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION order_line_edit_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_line erp_order_lines_v%ROWTYPE;
BEGIN
    SELECT * INTO v_line FROM erp_order_lines_v WHERE id = ui_parse_id(p_data->>'id');
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Позиция не найдена — возможно, она уже удалена';
    END IF;

    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_object(
            'command', 'open_form',
            'form', 'order_line',
            'modal', TRUE,
            'title', format('Позиция: %s', v_line.product),
            'data', json_build_object(
                'id', v_line.id::TEXT,
                'order_id', v_line.order_id::TEXT,
                'product_id', v_line.product_id::TEXT,
                'product_id__display', v_line.product,
                'quantity', v_line.quantity::TEXT,
                'price', ui_money_input(v_line.price))));
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION order_line_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_id_text  TEXT    := NULLIF(trim(p_data->>'id'), '');
    v_order    BIGINT  := ui_parse_id(p_data->>'order_id');
    v_product  BIGINT  := ui_parse_id(p_data->>'product_id');
    v_quantity TEXT    := trim(p_data->>'quantity');
    v_price    NUMERIC := ui_parse_money(p_data->>'price');
BEGIN
    IF v_order IS NULL OR NOT EXISTS (SELECT 1 FROM erp_orders WHERE id = v_order) THEN
        RAISE EXCEPTION 'Заказ не найден — возможно, он уже удалён';
    END IF;
    IF v_product IS NULL OR NOT EXISTS (SELECT 1 FROM erp_products WHERE id = v_product) THEN
        RAISE EXCEPTION 'Выберите товар';
    END IF;
    IF v_quantity IS NULL OR v_quantity !~ '^[1-9]\d{0,5}$' THEN
        RAISE EXCEPTION 'Количество — целое число больше нуля';
    END IF;
    IF v_price IS NULL THEN
        RAISE EXCEPTION 'Цена — число, например 1500 или 99,90';
    END IF;

    IF v_id_text IS NULL THEN
        INSERT INTO erp_order_lines (order_id, product_id, quantity, price)
        VALUES (v_order, v_product, v_quantity::INT, v_price);
    ELSE
        UPDATE erp_order_lines
        SET product_id = v_product, quantity = v_quantity::INT, price = v_price
        WHERE id = ui_parse_id(v_id_text) AND order_id = v_order;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'Позиция не найдена — возможно, она уже удалена';
        END IF;
    END IF;

    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_array(
            json_build_object('command', 'close_form'),
            json_build_object('command', 'refresh_grid', 'grid', 'order_lines_grid', 'keep_page', TRUE),
            json_build_object('command', 'refresh_grid', 'grid', 'orders_grid', 'keep_page', TRUE)));
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION order_line_delete(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_line erp_order_lines_v%ROWTYPE;
BEGIN
    SELECT * INTO v_line FROM erp_order_lines_v WHERE id = ui_parse_id(p_data->>'id');
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Позиция не найдена — возможно, она уже удалена';
    END IF;

    IF (p_data->>'confirmed') IS DISTINCT FROM 'true' THEN
        RETURN json_build_object(
            'status', 'success',
            'ui_instructions', json_build_object(
                'command', 'confirm',
                'text', format('Удалить позицию «%s», %s шт. на сумму %s?',
                               v_line.product, v_line.quantity, ui_format_money(v_line.total)),
                'confirm_label', 'Удалить',
                'action', 'order_line_delete',
                'data', json_build_object('id', v_line.id, 'confirmed', TRUE)));
    END IF;

    DELETE FROM erp_order_lines WHERE id = v_line.id;

    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_array(
            json_build_object('command', 'refresh_grid', 'grid', 'order_lines_grid', 'keep_page', TRUE),
            json_build_object('command', 'refresh_grid', 'grid', 'orders_grid', 'keep_page', TRUE)));
END;
$$ LANGUAGE plpgsql;


-- ---------------------------------------------------------------------
-- Оплаты заказа (вторая таблица-детали того же мастера)
-- ---------------------------------------------------------------------
CREATE FUNCTION order_payment_new_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_is_new BOOLEAN := NULLIF(trim(p_data->>'id'), '') IS NULL;
    v_id     BIGINT  := order_upsert(p_data);
    v_rest   NUMERIC;
BEGIN
    -- По умолчанию предлагается неоплаченный остаток
    SELECT total - paid INTO v_rest FROM erp_orders_v WHERE id = v_id;

    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', order_header_saved(v_is_new, v_id) || jsonb_build_array(
            jsonb_build_object(
                'command', 'open_form',
                'form', 'order_payment',
                'modal', TRUE,
                'title', format('Оплата заказа №%s', v_id),
                'data', jsonb_build_object(
                    'order_id', v_id::TEXT,
                    'paid_on', to_char(current_date, 'DD.MM.YYYY'),
                    'amount', CASE WHEN v_rest > 0 THEN ui_money_input(v_rest) ELSE '' END))));
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION order_payment_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_order     BIGINT  := ui_parse_id(p_data->>'order_id');
    v_date_text TEXT    := trim(p_data->>'paid_on');
    v_amount    NUMERIC := ui_parse_money(p_data->>'amount');
    v_date      DATE;
BEGIN
    IF v_order IS NULL OR NOT EXISTS (SELECT 1 FROM erp_orders WHERE id = v_order) THEN
        RAISE EXCEPTION 'Заказ не найден — возможно, он уже удалён';
    END IF;
    IF v_date_text IS NULL OR v_date_text !~ '^\d{2}\.\d{2}\.\d{4}$' THEN
        RAISE EXCEPTION 'Дата оплаты — в формате ДД.ММ.ГГГГ';
    END IF;
    BEGIN
        v_date := to_date(v_date_text, 'DD.MM.YYYY');
    EXCEPTION WHEN OTHERS THEN
        RAISE EXCEPTION 'Дата оплаты — в формате ДД.ММ.ГГГГ';
    END;
    IF v_amount IS NULL OR v_amount <= 0 THEN
        RAISE EXCEPTION 'Сумма оплаты — число больше нуля';
    END IF;

    INSERT INTO erp_order_payments (order_id, paid_on, amount) VALUES (v_order, v_date, v_amount);

    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_array(
            json_build_object('command', 'close_form'),
            json_build_object('command', 'refresh_grid', 'grid', 'order_payments_grid', 'keep_page', TRUE),
            json_build_object('command', 'refresh_grid', 'grid', 'orders_grid', 'keep_page', TRUE)));
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION order_payment_delete(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_payment erp_order_payments_v%ROWTYPE;
BEGIN
    SELECT * INTO v_payment FROM erp_order_payments_v WHERE id = ui_parse_id(p_data->>'id');
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Оплата не найдена — возможно, она уже удалена';
    END IF;

    IF (p_data->>'confirmed') IS DISTINCT FROM 'true' THEN
        RETURN json_build_object(
            'status', 'success',
            'ui_instructions', json_build_object(
                'command', 'confirm',
                'text', format('Удалить оплату от %s на сумму %s?', v_payment.paid_date, ui_format_money(v_payment.amount)),
                'confirm_label', 'Удалить',
                'action', 'order_payment_delete',
                'data', json_build_object('id', v_payment.id, 'confirmed', TRUE)));
    END IF;

    DELETE FROM erp_order_payments WHERE id = v_payment.id;

    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_array(
            json_build_object('command', 'refresh_grid', 'grid', 'order_payments_grid', 'keep_page', TRUE),
            json_build_object('command', 'refresh_grid', 'grid', 'orders_grid', 'keep_page', TRUE)));
END;
$$ LANGUAGE plpgsql;


-- ---------------------------------------------------------------------
-- Справочник клиентов
-- ---------------------------------------------------------------------

-- Кнопка "..." у поля "Клиент": список клиентов в режиме выбора
CREATE FUNCTION customer_select_open(p_data JSON)
RETURNS JSON AS $$
BEGIN
    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_object(
            'command', 'open_form',
            'form', 'customers',
            'modal', TRUE,
            'title', 'Выбор клиента',
            'select', json_build_object('value_field', 'id', 'display_field', 'name')));
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION customer_new_open(p_data JSON)
RETURNS JSON AS $$
BEGIN
    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_object(
            'command', 'open_form', 'form', 'customer', 'modal', TRUE, 'title', 'Новый клиент'));
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION customer_edit_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_customer erp_customers%ROWTYPE;
BEGIN
    SELECT * INTO v_customer FROM erp_customers WHERE id = ui_parse_id(p_data->>'id');
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Клиент не найден — возможно, он удалён';
    END IF;

    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_object(
            'command', 'open_form',
            'form', 'customer',
            'modal', TRUE,
            'title', v_customer.name,
            'data', json_build_object(
                'id', v_customer.id::TEXT,
                'name', v_customer.name,
                'phone', COALESCE(v_customer.phone, ''))));
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION customer_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_id_text TEXT    := NULLIF(trim(p_data->>'id'), '');
    v_name    VARCHAR := NULLIF(trim(p_data->>'name'), '');
    v_phone   VARCHAR := NULLIF(trim(p_data->>'phone'), '');
BEGIN
    IF v_name IS NULL THEN
        RAISE EXCEPTION 'Укажите наименование клиента';
    END IF;
    IF EXISTS (SELECT 1 FROM erp_customers
               WHERE lower(name) = lower(v_name) AND id IS DISTINCT FROM ui_parse_id(v_id_text)) THEN
        RAISE EXCEPTION 'Клиент «%» уже есть в справочнике', v_name;
    END IF;

    IF v_id_text IS NULL THEN
        INSERT INTO erp_customers (name, phone) VALUES (v_name, v_phone);
    ELSE
        UPDATE erp_customers SET name = v_name, phone = v_phone WHERE id = ui_parse_id(v_id_text);
        IF NOT FOUND THEN
            RAISE EXCEPTION 'Клиент не найден — возможно, он удалён';
        END IF;
    END IF;

    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_array(
            json_build_object('command', 'close_form'),
            json_build_object('command', 'refresh_grid', 'grid', 'customers_grid', 'keep_page', v_id_text IS NOT NULL),
            json_build_object('command', 'refresh_grid', 'grid', 'orders_grid', 'keep_page', TRUE)));
END;
$$ LANGUAGE plpgsql;


-- ---------------------------------------------------------------------
-- Справочник товаров
-- ---------------------------------------------------------------------

-- Кнопка "..." у поля "Товар": при выборе подставляется и цена товара
CREATE FUNCTION product_select_open(p_data JSON)
RETURNS JSON AS $$
BEGIN
    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_object(
            'command', 'open_form',
            'form', 'products',
            'modal', TRUE,
            'title', 'Выбор товара',
            'select', json_build_object(
                'value_field', 'id',
                'display_field', 'name',
                'fill', json_build_object('price', 'price_input'))));
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION product_new_open(p_data JSON)
RETURNS JSON AS $$
BEGIN
    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_object(
            'command', 'open_form', 'form', 'product', 'modal', TRUE, 'title', 'Новый товар'));
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION product_edit_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_product erp_products%ROWTYPE;
BEGIN
    SELECT * INTO v_product FROM erp_products WHERE id = ui_parse_id(p_data->>'id');
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Товар не найден — возможно, он удалён';
    END IF;

    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_object(
            'command', 'open_form',
            'form', 'product',
            'modal', TRUE,
            'title', v_product.name,
            'data', json_build_object(
                'id', v_product.id::TEXT,
                'name', v_product.name,
                'price', ui_money_input(v_product.price))));
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION product_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_id_text TEXT    := NULLIF(trim(p_data->>'id'), '');
    v_name    VARCHAR := NULLIF(trim(p_data->>'name'), '');
    v_price   NUMERIC := ui_parse_money(p_data->>'price');
BEGIN
    IF v_name IS NULL THEN
        RAISE EXCEPTION 'Укажите наименование товара';
    END IF;
    IF v_price IS NULL THEN
        RAISE EXCEPTION 'Цена — число, например 1500 или 99,90';
    END IF;
    IF EXISTS (SELECT 1 FROM erp_products
               WHERE lower(name) = lower(v_name) AND id IS DISTINCT FROM ui_parse_id(v_id_text)) THEN
        RAISE EXCEPTION 'Товар «%» уже есть в справочнике', v_name;
    END IF;

    IF v_id_text IS NULL THEN
        INSERT INTO erp_products (name, price) VALUES (v_name, v_price);
    ELSE
        UPDATE erp_products SET name = v_name, price = v_price WHERE id = ui_parse_id(v_id_text);
        IF NOT FOUND THEN
            RAISE EXCEPTION 'Товар не найден — возможно, он удалён';
        END IF;
    END IF;

    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_array(
            json_build_object('command', 'close_form'),
            json_build_object('command', 'refresh_grid', 'grid', 'products_grid', 'keep_page', v_id_text IS NOT NULL)));
END;
$$ LANGUAGE plpgsql;



-- ---------------------------------------------------------------------
-- Реестр действий
-- ---------------------------------------------------------------------
INSERT INTO erp_ui_actions (action_name, function_name, description) VALUES
    ('order_lines_page',       'order_lines_page',       'Таблица: позиции заказа (детали)'),
    ('order_line_new_open',    'order_line_new_open',    'Добавить позицию (новый заказ сначала сохраняется)'),
    ('order_line_edit_open',   'order_line_edit_open',   'Открыть позицию заказа'),
    ('order_line_save',        'order_line_save',        'Сохранение позиции заказа'),
    ('order_line_delete',      'order_line_delete',      'Удаление позиции заказа с подтверждением'),
    ('order_payments_page',    'order_payments_page',    'Таблица: оплаты заказа (детали)'),
    ('order_payment_new_open', 'order_payment_new_open', 'Добавить оплату (новый заказ сначала сохраняется)'),
    ('order_payment_save',     'order_payment_save',     'Сохранение оплаты'),
    ('order_payment_delete',   'order_payment_delete',   'Удаление оплаты с подтверждением'),
    ('customers_page',         'customers_page',         'Таблица: справочник клиентов'),
    ('customer_select_open',   'customer_select_open',   'Выбор клиента из справочника'),
    ('customer_new_open',      'customer_new_open',      'Открыть форму нового клиента'),
    ('customer_edit_open',     'customer_edit_open',     'Открыть клиента для изменения'),
    ('customer_save',          'customer_save',          'Сохранение клиента'),
    ('products_page',          'products_page',          'Таблица: справочник товаров'),
    ('product_select_open',    'product_select_open',    'Выбор товара из справочника (с подстановкой цены)'),
    ('product_new_open',       'product_new_open',       'Открыть форму нового товара'),
    ('product_edit_open',      'product_edit_open',      'Открыть товар для изменения'),
    ('product_save',           'product_save',           'Сохранение товара');

UPDATE erp_ui_actions SET description = 'Сохранение шапки заказа (форма остаётся открытой)'
WHERE action_name = 'order_save';


-- ---------------------------------------------------------------------
-- Колонки и действия строк таблиц
-- ---------------------------------------------------------------------
DELETE FROM erp_grid_columns WHERE action_name = 'orders_page';

INSERT INTO erp_grid_columns (action_name, display_order, field_name, column_title, cell_type, sort_column) VALUES
    ('orders_page', 1, 'id',          '№',        'number',   'id'),
    ('orders_page', 2, 'order_date',  'Дата',     'datetime', 'created_at'),
    ('orders_page', 3, 'customer',    'Клиент',   'text',     'customer'),
    ('orders_page', 4, 'lines_count', 'Позиций',  'number',   'lines_count'),
    ('orders_page', 5, 'total',       'Сумма',    'money',    'total'),
    ('orders_page', 6, 'paid',        'Оплачено', 'money',    'paid'),
    ('orders_page', 7, 'status',      'Статус',   'badge',    'status'),

    ('order_lines_page', 1, 'product',  'Товар',  'text',   'product'),
    ('order_lines_page', 2, 'quantity', 'Кол-во', 'number', 'quantity'),
    ('order_lines_page', 3, 'price',    'Цена',   'money',  'price'),
    ('order_lines_page', 4, 'total',    'Сумма',  'money',  'total'),

    ('order_payments_page', 1, 'paid_date', 'Дата',  'datetime', 'paid_on'),
    ('order_payments_page', 2, 'amount',    'Сумма', 'money',    'amount'),

    ('customers_page', 1, 'name',  'Наименование', 'text', 'name'),
    ('customers_page', 2, 'phone', 'Телефон',      'text', 'phone'),

    ('products_page', 1, 'name',  'Наименование', 'text',  'name'),
    ('products_page', 2, 'price', 'Цена',         'money', 'price');

INSERT INTO erp_grid_row_actions (source_action, sort_order, row_action, label, style) VALUES
    ('order_lines_page',    1, 'order_line_edit_open', 'Изменить', 'default'),
    ('order_lines_page',    2, 'order_line_delete',    'Удалить',  'danger'),
    ('order_payments_page', 1, 'order_payment_delete', 'Удалить',  'danger'),
    ('customers_page',      1, 'customer_edit_open',   'Изменить', 'default'),
    ('products_page',       1, 'product_edit_open',    'Изменить', 'default');


-- ---------------------------------------------------------------------
-- Формы
-- ---------------------------------------------------------------------
INSERT INTO erp_forms (form_name, title) VALUES
    ('order_line',    'Позиция заказа'),
    ('order_payment', 'Оплата'),
    ('customers',     'Клиенты'),
    ('customer',      'Клиент'),
    ('products',      'Товары'),
    ('product',       'Товар');

-- Карточка заказа: шапка + две таблицы-детали, связанные с мастером по полю id
DELETE FROM erp_form_components WHERE form_name = 'order_new';
UPDATE erp_forms SET updated_at = now() WHERE form_name = 'order_new';

INSERT INTO erp_form_components
    (form_name, sort_order, component_type, component_name, label, action_event, master_field) VALUES
    ('order_new',      1, 'hidden', 'id',                  NULL,                NULL,                     NULL),
    ('order_new',      2, 'lookup', 'customer_id',         'Клиент',            'customer_select_open',   NULL),
    ('order_new',      3, 'button', 'btn_add_line',        'Добавить позицию',  'order_line_new_open',    NULL),
    ('order_new',      4, 'grid',   'order_lines_grid',    'Позиции',           'order_lines_page',       'id'),
    ('order_new',      5, 'button', 'btn_add_payment',     'Добавить оплату',   'order_payment_new_open', NULL),
    ('order_new',      6, 'grid',   'order_payments_grid', 'Оплаты',            'order_payments_page',    'id'),
    ('order_new',      7, 'button', 'btn_save',            'Сохранить',         'order_save',             NULL),
    ('order_new',      8, 'button', 'btn_close',           'Закрыть',           'form_close',             NULL),

    ('order_line',     1, 'hidden', 'id',                  NULL,                NULL,                     NULL),
    ('order_line',     2, 'hidden', 'order_id',            NULL,                NULL,                     NULL),
    ('order_line',     3, 'lookup', 'product_id',          'Товар',             'product_select_open',    NULL),
    ('order_line',     4, 'input',  'quantity',            'Количество',        NULL,                     NULL),
    ('order_line',     5, 'input',  'price',               'Цена',              NULL,                     NULL),
    ('order_line',     6, 'button', 'btn_save',            'Сохранить',         'order_line_save',        NULL),
    ('order_line',     7, 'button', 'btn_cancel',          'Отмена',            'form_close',             NULL),

    ('order_payment',  1, 'hidden', 'order_id',            NULL,                NULL,                     NULL),
    ('order_payment',  2, 'input',  'paid_on',             'Дата оплаты',       NULL,                     NULL),
    ('order_payment',  3, 'input',  'amount',              'Сумма',             NULL,                     NULL),
    ('order_payment',  4, 'button', 'btn_save',            'Сохранить',         'order_payment_save',     NULL),
    ('order_payment',  5, 'button', 'btn_cancel',          'Отмена',            'form_close',             NULL),

    ('customers',      1, 'button', 'btn_new',             'Новый клиент',      'customer_new_open',      NULL),
    ('customers',      2, 'grid',   'customers_grid',      'Список клиентов',   'customers_page',         NULL),

    ('customer',       1, 'hidden', 'id',                  NULL,                NULL,                     NULL),
    ('customer',       2, 'input',  'name',                'Наименование',      NULL,                     NULL),
    ('customer',       3, 'input',  'phone',               'Телефон',           NULL,                     NULL),
    ('customer',       4, 'button', 'btn_save',            'Сохранить',         'customer_save',          NULL),
    ('customer',       5, 'button', 'btn_cancel',          'Отмена',            'form_close',             NULL),

    ('products',       1, 'button', 'btn_new',             'Новый товар',       'product_new_open',       NULL),
    ('products',       2, 'grid',   'products_grid',       'Список товаров',    'products_page',          NULL),

    ('product',        1, 'hidden', 'id',                  NULL,                NULL,                     NULL),
    ('product',        2, 'input',  'name',                'Наименование',      NULL,                     NULL),
    ('product',        3, 'input',  'price',               'Цена',              NULL,                     NULL),
    ('product',        4, 'button', 'btn_save',            'Сохранить',         'product_save',           NULL),
    ('product',        5, 'button', 'btn_cancel',          'Отмена',            'form_close',             NULL);
