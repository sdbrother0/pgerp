-- =====================================================================
-- Темы оформления.
--
--  * pgerp.themes — темы, из которых выбирает пользователь: светлая и тёмная. Оформление темы —
--    блок :root[data-theme="<код>"] с переменными цветов в css/app.css; новая тема — такой блок
--    и строка здесь.
--  * pgerp.users.theme — выбор пользователя (переключатель в шапке, действие session_theme_set);
--    NULL — как в системе (prefers-color-scheme).
--  * Браузер применяет тему до отрисовки страницы (js/theme.js) и запоминает её в localStorage —
--    страница входа тоже в выбранной теме.
-- =====================================================================

CREATE TABLE pgerp.themes (
    code       VARCHAR(20)  PRIMARY KEY CHECK (code ~ '^[a-z][a-z0-9-]*$'),
    title      VARCHAR(100) NOT NULL,
    sort_order INT          NOT NULL DEFAULT 0
);

INSERT INTO pgerp.themes (code, title, sort_order) VALUES
    ('light', 'Светлая', 1),
    ('dark',  'Тёмная',  2);

ALTER TABLE pgerp.users ADD COLUMN theme VARCHAR(20)
    REFERENCES pgerp.themes ON UPDATE CASCADE ON DELETE SET NULL;

-- Сеанс: пользователь, язык, тема и списки для переключателей в шапке
CREATE OR REPLACE FUNCTION pgerp.ui_session_get(p_data JSON)
RETURNS JSON AS $$
    SELECT json_build_object(
        'status', 'success',
        'user', json_build_object(
            'login', u.login,
            'full_name', u.full_name,
            'roles', ARRAY(SELECT r.role_name FROM pgerp.user_roles ur JOIN pgerp.roles r ON r.id = ur.role_id
                           WHERE ur.user_id = u.id ORDER BY r.role_name),
            'is_admin', pgerp.auth_is_admin(u.id),
            'must_change_password', u.must_change_password,
            'lang', pgerp.ui_lang(),
            'theme', u.theme),
        'languages', (SELECT json_agg(json_build_object('code', code, 'title', title) ORDER BY sort_order, code)
                      FROM pgerp.languages),
        'themes', (SELECT json_agg(json_build_object('code', code, 'title', pgerp.ui_t_exact(title))
                                   ORDER BY sort_order, code)
                   FROM pgerp.themes))
    FROM pgerp.users u
    WHERE u.id = pgerp.ui_user_id();
$$ LANGUAGE sql STABLE;

-- Тема пользователя из переключателя в шапке; пустое значение — как в системе
CREATE FUNCTION pgerp.ui_session_theme_set(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_theme VARCHAR := NULLIF(p_data->>'theme', '');
BEGIN
    PERFORM ui_require(v_theme IS NULL OR EXISTS (SELECT 1 FROM pgerp.themes WHERE code = v_theme),
                       format('Тема «%s» не поддерживается', v_theme));
    UPDATE pgerp.users SET theme = v_theme WHERE id = pgerp.ui_user_id();
    RETURN ui_ok();
END;
$$ LANGUAGE plpgsql;

INSERT INTO pgerp.ui_actions (action_name, function_name, description, is_system, everyone) VALUES
    ('session_theme_set', 'pgerp.ui_session_theme_set', 'Смена темы пользователя', TRUE, TRUE);

INSERT INTO pgerp.translations (lang, source, translation) VALUES
    ('en', 'Светлая',                    'Light'),
    ('en', 'Тёмная',                     'Dark'),
    ('en', 'Смена темы пользователя',    'Change user theme'),
    ('en', 'Тема «%s» не поддерживается', 'Theme “%s” is not supported')
ON CONFLICT (lang, source) DO UPDATE SET translation = EXCLUDED.translation;
