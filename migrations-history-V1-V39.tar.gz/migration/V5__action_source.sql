-- =====================================================================
-- Редактор форм: просмотр исходного кода PL/pgSQL-функции действия.
-- =====================================================================

-- {"action": "order_create"} -> {"action", "function", "description", "source"}
-- Отдаётся код только зарегистрированных в erp_ui_actions функций.
CREATE FUNCTION ui_action_source(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_action erp_ui_actions%ROWTYPE;
BEGIN
    SELECT * INTO v_action
    FROM erp_ui_actions
    WHERE action_name = p_data->>'action';

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Действие "%" не зарегистрировано', p_data->>'action';
    END IF;

    RETURN json_build_object(
        'status', 'success',
        'action', v_action.action_name,
        'function', v_action.function_name::REGPROCEDURE::TEXT,
        'description', v_action.description,
        'source', pg_get_functiondef(v_action.function_name));
END;
$$ LANGUAGE plpgsql;

INSERT INTO erp_ui_actions (action_name, function_name, description, is_system)
VALUES ('action_source', 'ui_action_source', 'Исходный код функции действия', TRUE);
