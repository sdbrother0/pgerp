-- =====================================================================
-- Отображение общей суммы в карточке заказа.
-- Новый тип компонента 'display' — поле только для чтения, значение задаёт база.
-- set_values с параметром form обновляет другую открытую форму (из формы позиции —
-- карточку заказа).
-- =====================================================================

CREATE OR REPLACE FUNCTION ui_component_types()
RETURNS VARCHAR[] AS $$
    SELECT ARRAY['label', 'input', 'hidden', 'display', 'lookup', 'button', 'grid']::VARCHAR[];
$$ LANGUAGE sql IMMUTABLE;


-- Инструкция: обновить сумму в открытой карточке заказа
CREATE FUNCTION order_total_update(p_order_id BIGINT)
RETURNS JSON AS $$
    SELECT json_build_object(
        'command', 'set_values',
        'form', 'order_new',
        'values', json_build_object('order_total', ui_format_money(COALESCE(total, 0))))
    FROM erp_orders_v
    WHERE id = p_order_id;
$$ LANGUAGE sql STABLE;


-- Новый заказ открывается с нулевой суммой
CREATE OR REPLACE FUNCTION order_new_open(p_data JSON)
RETURNS JSON AS $$
BEGIN
    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_object(
            'command', 'open_form',
            'form', 'order_new',
            'modal', TRUE,
            'data', json_build_object('order_total', ui_format_money(0))));
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION order_edit_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_order erp_orders_v%ROWTYPE;
BEGIN
    SELECT * INTO v_order FROM erp_orders_v WHERE id = ui_parse_id(p_data->>'id');
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Заказ №% не найден — возможно, он уже удалён', p_data->>'id';
    END IF;

    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_object(
            'command', 'open_form',
            'form', 'order_new',
            'modal', TRUE,
            'title', format('Заказ №%s', v_order.id),
            'data', json_build_object(
                'id', v_order.id::TEXT,
                'customer_id', v_order.customer_id::TEXT,
                'customer_id__display', v_order.customer,
                'order_total', ui_format_money(v_order.total))));
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION order_line_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_id_text  TEXT    := NULLIF(trim(p_data->>'id'), '');
    v_order    BIGINT  := ui_parse_id(p_data->>'order_id');
    v_product  BIGINT  := ui_parse_id(p_data->>'product_id');
    v_quantity TEXT    := trim(p_data->>'quantity');
    v_price    NUMERIC := ui_parse_money(p_data->>'price');
BEGIN
    IF v_order IS NULL OR NOT EXISTS (SELECT 1 FROM erp_orders WHERE id = v_order) THEN
        RAISE EXCEPTION 'Заказ не найден — возможно, он уже удалён';
    END IF;
    IF v_product IS NULL OR NOT EXISTS (SELECT 1 FROM erp_products WHERE id = v_product) THEN
        RAISE EXCEPTION 'Выберите товар';
    END IF;
    IF v_quantity IS NULL OR v_quantity !~ '^[1-9]\d{0,5}$' THEN
        RAISE EXCEPTION 'Количество — целое число больше нуля';
    END IF;
    IF v_price IS NULL THEN
        RAISE EXCEPTION 'Цена — число, например 1500 или 99,90';
    END IF;

    IF v_id_text IS NULL THEN
        INSERT INTO erp_order_lines (order_id, product_id, quantity, price)
        VALUES (v_order, v_product, v_quantity::INT, v_price);
    ELSE
        UPDATE erp_order_lines
        SET product_id = v_product, quantity = v_quantity::INT, price = v_price
        WHERE id = ui_parse_id(v_id_text) AND order_id = v_order;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'Позиция не найдена — возможно, она уже удалена';
        END IF;
    END IF;

    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_array(
            json_build_object('command', 'close_form'),
            json_build_object('command', 'refresh_grid', 'grid', 'order_lines_grid', 'keep_page', TRUE),
            json_build_object('command', 'refresh_grid', 'grid', 'orders_grid', 'keep_page', TRUE),
            order_total_update(v_order)));
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION order_line_delete(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_line erp_order_lines_v%ROWTYPE;
BEGIN
    SELECT * INTO v_line FROM erp_order_lines_v WHERE id = ui_parse_id(p_data->>'id');
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Позиция не найдена — возможно, она уже удалена';
    END IF;

    IF (p_data->>'confirmed') IS DISTINCT FROM 'true' THEN
        RETURN json_build_object(
            'status', 'success',
            'ui_instructions', json_build_object(
                'command', 'confirm',
                'text', format('Удалить позицию «%s», %s шт. на сумму %s?',
                               v_line.product, v_line.quantity, ui_format_money(v_line.total)),
                'confirm_label', 'Удалить',
                'action', 'order_line_delete',
                'data', json_build_object('id', v_line.id, 'confirmed', TRUE)));
    END IF;

    DELETE FROM erp_order_lines WHERE id = v_line.id;

    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_array(
            json_build_object('command', 'refresh_grid', 'grid', 'order_lines_grid', 'keep_page', TRUE),
            json_build_object('command', 'refresh_grid', 'grid', 'orders_grid', 'keep_page', TRUE),
            order_total_update(v_line.order_id)));
END;
$$ LANGUAGE plpgsql;


-- Поле суммы — сразу под клиентом
UPDATE erp_form_components SET sort_order = sort_order + 1
WHERE form_name = 'order_new' AND sort_order >= 3;

INSERT INTO erp_form_components (form_name, sort_order, component_type, component_name, label)
VALUES ('order_new', 3, 'display', 'order_total', 'Сумма заказа');

UPDATE erp_forms SET updated_at = now() WHERE form_name = 'order_new';
