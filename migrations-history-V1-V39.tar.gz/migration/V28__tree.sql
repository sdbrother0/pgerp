-- =====================================================================
-- Компонент "tree" — дерево для иерархических справочников.
--
--  * Источник данных — действие (action компонента). Получает значения полей формы и parent_id
--    (пусто — корневой уровень), возвращает один уровень:
--        {"status": "success", "nodes": [{"id": 1, "label": "Мебель", "has_children": true, ...}]}
--    Дочерние узлы запрашиваются при раскрытии — справочник не загружается целиком.
--    pgerp.ui_tree_level(p_data, 'таблица') строит ответ по любой таблице с колонкой parent_id.
--  * Значение компонента — id выбранного узла: уходит в действия кнопок формы, как значение поля.
--  * Таблица с master = имя дерева показывает строки выбранного узла и перечитывается при выборе.
--  * refresh_grid('имя дерева') перечитывает дерево, раскрытые узлы и выбор сохраняются.
--  * В режиме выбора (open_form с select) узел выбирается двойным щелчком, Enter или «Выбрать».
--
-- Пример: справочник "Группы товаров" (папка "Заказы") и поле "Группа" в карточке товара.
-- =====================================================================

-- ---------------------------------------------------------------------
-- Ядро
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION pgerp.ui_component_types()
RETURNS VARCHAR[] AS $$
    SELECT ARRAY['label', 'input', 'date', 'hidden', 'display', 'lookup', 'button', 'grid',
                 'board', 'timer', 'tree']::VARCHAR[];
$$ LANGUAGE sql IMMUTABLE;

-- Один уровень дерева: дети узла p_data->>'parent_id' (пусто — корни), по алфавиту.
-- Узел — строка таблицы целиком и поля label, has_children.
CREATE FUNCTION pgerp.ui_tree_level(p_data JSON, p_source REGCLASS,
                                    p_label_column VARCHAR DEFAULT 'name',
                                    p_parent_column VARCHAR DEFAULT 'parent_id')
RETURNS JSON AS $$
DECLARE
    v_nodes JSON;
BEGIN
    EXECUTE format(
        'SELECT json_agg(to_jsonb(t) || jsonb_build_object(
                    ''label'', t.%1$I,
                    ''has_children'', EXISTS (SELECT 1 FROM %2$s c WHERE c.%3$I = t.id))
                ORDER BY t.%1$I, t.id)
         FROM %2$s t
         WHERE t.%3$I IS NOT DISTINCT FROM $1',
        p_label_column, p_source, p_parent_column)
    INTO v_nodes
    USING pgerp.ui_parse_id(p_data->>'parent_id');

    RETURN json_build_object('status', 'success', 'nodes', COALESCE(v_nodes, '[]'::json));
END;
$$ LANGUAGE plpgsql STABLE;

-- Сохранение формы: дерево требует действие-источник и может быть мастером таблицы
CREATE OR REPLACE FUNCTION pgerp.ui_form_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_form_name  VARCHAR := p_data->>'name';
    v_title      VARCHAR := ui_text(p_data, 'title');
    v_folder     VARCHAR := ui_text(p_data, 'folder');
    v_components JSON    := COALESCE(p_data->'components', '[]'::json);
    v_comp       RECORD;
BEGIN
    PERFORM ui_require(v_form_name ~ '^[a-z_][a-z0-9_]*$',
                       'Имя формы: латинские буквы в нижнем регистре, цифры и "_"');

    FOR v_comp IN
        SELECT c->>'type' AS type, c->>'name' AS name, NULLIF(c->>'action', '') AS action,
               NULLIF(c->>'master', '') AS master, c->'options' AS options, n
        FROM json_array_elements(v_components) WITH ORDINALITY AS t(c, n)
    LOOP
        PERFORM ui_require(v_comp.type = ANY (ui_component_types()),
                           format('Компонент №%s: неизвестный тип "%s"', v_comp.n, v_comp.type));
        PERFORM ui_require(v_comp.name ~ '^[a-z_][a-z0-9_]*$',
                           format('Компонент №%s: имя — латинские буквы в нижнем регистре, цифры и "_"', v_comp.n));

        IF v_comp.type = 'grid' AND v_comp.action IS NULL THEN
            RAISE EXCEPTION 'Таблица "%": выберите действие-источник данных', v_comp.name;
        END IF;
        IF v_comp.type = 'tree' AND v_comp.action IS NULL THEN
            RAISE EXCEPTION 'Дерево "%": выберите действие-источник данных', v_comp.name;
        END IF;
        IF v_comp.type = 'lookup' AND v_comp.action IS NULL THEN
            RAISE EXCEPTION 'Поле выбора "%": выберите действие открытия списка', v_comp.name;
        END IF;
        IF v_comp.type = 'timer' AND v_comp.action IS NULL THEN
            RAISE EXCEPTION 'Таймер "%": выберите действие', v_comp.name;
        END IF;

        IF v_comp.action IS NOT NULL THEN
            PERFORM ui_require(
                EXISTS (SELECT 1 FROM pgerp.ui_actions WHERE action_name = v_comp.action AND NOT is_system),
                format('Компонент "%s": действие "%s" не зарегистрировано', v_comp.name, v_comp.action));
        END IF;
        IF v_comp.type = 'grid' AND v_comp.master IS NOT NULL THEN
            PERFORM ui_require(
                EXISTS (SELECT 1 FROM json_array_elements(v_components) c
                        WHERE c->>'name' = v_comp.master AND c->>'type' IN ('input', 'hidden', 'lookup', 'tree')),
                format('Таблица "%s": поле-мастер "%s" не найдено среди полей формы', v_comp.name, v_comp.master));
        END IF;
        IF v_comp.options IS NOT NULL AND json_typeof(v_comp.options) NOT IN ('object', 'null') THEN
            RAISE EXCEPTION 'Компонент "%": параметры должны быть объектом JSON', v_comp.name;
        END IF;
    END LOOP;

    PERFORM ui_require(
        (SELECT count(*) = count(DISTINCT c->>'name') FROM json_array_elements(v_components) c),
        'Имена компонентов должны быть уникальны');

    INSERT INTO pgerp.forms (form_name, title, folder)
    VALUES (v_form_name, COALESCE(v_title, v_form_name), v_folder)
    ON CONFLICT (form_name) DO UPDATE
        SET title = EXCLUDED.title, folder = EXCLUDED.folder, updated_at = now();

    DELETE FROM pgerp.form_components WHERE form_name = v_form_name;

    INSERT INTO pgerp.form_components
        (form_name, sort_order, component_type, component_name, label, action_event, master_field, tab, options)
    SELECT v_form_name, n, c->>'type', c->>'name', c->>'label', NULLIF(c->>'action', ''),
           CASE WHEN c->>'type' = 'grid' THEN NULLIF(c->>'master', '') END,
           CASE WHEN c->>'type' NOT IN ('hidden', 'timer') THEN NULLIF(trim(c->>'tab'), '') END,
           CASE WHEN json_typeof(c->'options') = 'object' AND (c->'options')::jsonb <> '{}' THEN (c->'options')::jsonb END
    FROM json_array_elements(v_components) WITH ORDINALITY AS t(c, n);

    RETURN ui_ok(ui_message(format('Форма "%s" сохранена', v_form_name)));
END;
$$ LANGUAGE plpgsql;


-- ---------------------------------------------------------------------
-- Группы товаров
-- ---------------------------------------------------------------------
CREATE TABLE product_groups (
    id        BIGSERIAL    PRIMARY KEY,
    parent_id BIGINT       REFERENCES product_groups,
    name      VARCHAR(200) NOT NULL
);
CREATE INDEX ON product_groups (parent_id);
-- Имена уникальны среди соседей одного уровня
CREATE UNIQUE INDEX product_groups_name_key ON product_groups (COALESCE(parent_id, 0), lower(name));

ALTER TABLE products ADD COLUMN group_id BIGINT REFERENCES product_groups;
CREATE INDEX ON products (group_id);

-- Полный путь группы: "Мебель / Столы"
CREATE FUNCTION product_group_path(p_id BIGINT)
RETURNS TEXT AS $$
    WITH RECURSIVE up AS (
        SELECT id, parent_id, name, 1 AS depth FROM product_groups WHERE id = p_id
        UNION ALL
        SELECT g.id, g.parent_id, g.name, up.depth + 1 FROM product_groups g JOIN up ON g.id = up.parent_id
    )
    SELECT string_agg(name, ' / ' ORDER BY depth DESC) FROM up;
$$ LANGUAGE sql STABLE;

-- Колонки добавляются в конец представления; price_input нужен полю выбора товара в позиции заказа
CREATE OR REPLACE VIEW products_v AS
SELECT id, name, price, ui_money_input(price) AS price_input,
       group_id, product_group_path(group_id) AS group_name
FROM products;

INSERT INTO product_groups (id, parent_id, name) VALUES
    (1, NULL, 'Мебель'),
    (2, 1,    'Столы'),
    (3, 1,    'Стулья и кресла'),
    (4, NULL, 'Техника'),
    (5, 4,    'Компьютеры'),
    (6, 5,    'Ноутбуки'),
    (7, 4,    'Периферия'),
    (8, NULL, 'Канцелярия');
SELECT setval('product_groups_id_seq', (SELECT max(id) FROM product_groups));


-- Товары выбранной группы (таблица-детали дерева)
CREATE FUNCTION group_products_page(p_data JSON)
RETURNS JSON AS $$
    SELECT ui_grid_page('group_products_page', p_data, 'products_v', 'group_id', 'name', 'asc');
$$ LANGUAGE sql;

-- "Добавить группу": подгруппа выбранной группы или корневая
CREATE FUNCTION product_group_new_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_parent BIGINT := ui_parse_id(p_data->>'group_tree');
BEGIN
    RETURN ui_ok(ui_open_form('product_group',
        p_title => CASE WHEN v_parent IS NULL THEN 'Новая группа' ELSE 'Новая подгруппа' END,
        p_data  => jsonb_build_object(
            'parent_id', COALESCE(v_parent::TEXT, ''),
            'parent_id__display', COALESCE(product_group_path(v_parent), ''))));
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION product_group_edit_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_group product_groups%ROWTYPE;
BEGIN
    SELECT * INTO v_group FROM product_groups WHERE id = ui_parse_id(p_data->>'group_tree');
    PERFORM ui_require(FOUND, 'Выберите группу в дереве');

    RETURN ui_ok(ui_open_form('product_group',
        p_title => v_group.name,
        p_data  => jsonb_build_object(
            'id', v_group.id::TEXT,
            'name', v_group.name,
            'parent_id', COALESCE(v_group.parent_id::TEXT, ''),
            'parent_id__display', COALESCE(product_group_path(v_group.parent_id), ''))));
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION product_group_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_id     BIGINT  := ui_parse_id(p_data->>'id');
    v_parent BIGINT  := ui_parse_id(p_data->>'parent_id');
    v_name   VARCHAR := ui_text(p_data, 'name');
BEGIN
    PERFORM ui_require(v_name IS NOT NULL, 'Укажите наименование группы');
    PERFORM ui_require(v_parent IS NULL OR EXISTS (SELECT 1 FROM product_groups WHERE id = v_parent),
                       'Родительская группа не найдена — возможно, она удалена');
    -- Группу нельзя вложить в саму себя или в свою подгруппу
    PERFORM ui_require(
        v_id IS NULL OR v_parent IS NULL OR NOT EXISTS (
            WITH RECURSIVE down AS (
                SELECT id FROM product_groups WHERE id = v_id
                UNION ALL
                SELECT g.id FROM product_groups g JOIN down ON g.parent_id = down.id
            )
            SELECT 1 FROM down WHERE id = v_parent),
        'Группу нельзя перенести в саму себя или в её подгруппу');
    PERFORM ui_require(
        NOT EXISTS (SELECT 1 FROM product_groups
                    WHERE parent_id IS NOT DISTINCT FROM v_parent AND lower(name) = lower(v_name)
                      AND id IS DISTINCT FROM v_id),
        format('Группа «%s» уже есть на этом уровне', v_name));

    IF ui_is_new(p_data) THEN
        INSERT INTO product_groups (parent_id, name) VALUES (v_parent, v_name);
    ELSE
        UPDATE product_groups SET parent_id = v_parent, name = v_name WHERE id = v_id;
        PERFORM ui_require(FOUND, 'Группа не найдена — возможно, она удалена');
    END IF;

    RETURN ui_ok(
        ui_close_form(),
        ui_refresh_grid('group_tree', p_keep_page => TRUE),
        ui_refresh_grid('products_grid', p_keep_page => TRUE));
END;
$$ LANGUAGE plpgsql;

CREATE FUNCTION product_group_delete(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_group product_groups%ROWTYPE;
BEGIN
    SELECT * INTO v_group FROM product_groups WHERE id = ui_parse_id(p_data->>'group_tree');
    PERFORM ui_require(FOUND, 'Выберите группу в дереве');
    PERFORM ui_require(NOT EXISTS (SELECT 1 FROM product_groups WHERE parent_id = v_group.id),
                       format('В группе «%s» есть подгруппы — сначала удалите или перенесите их', v_group.name));
    PERFORM ui_require(NOT EXISTS (SELECT 1 FROM products WHERE group_id = v_group.id),
                       format('В группе «%s» есть товары — сначала перенесите их в другую группу', v_group.name));

    IF NOT ui_confirmed(p_data) THEN
        RETURN ui_ok(ui_confirm(format('Удалить группу «%s»?', v_group.name), 'product_group_delete',
                                jsonb_build_object('group_tree', v_group.id::TEXT, 'confirmed', TRUE),
                                p_confirm_label => 'Удалить'));
    END IF;

    DELETE FROM product_groups WHERE id = v_group.id;

    RETURN ui_ok(
        ui_set_values(jsonb_build_object('group_tree', '')),
        ui_refresh_grid('group_tree', p_keep_page => TRUE));
END;
$$ LANGUAGE plpgsql;

-- Выбор группы в карточке товара и группы: дерево групп в режиме выбора
CREATE FUNCTION product_group_select_open(p_data JSON)
RETURNS JSON AS $$
BEGIN
    RETURN ui_ok(ui_open_form('product_groups',
        p_title  => 'Выбор группы',
        p_select => jsonb_build_object('value_field', 'id', 'display_field', 'path')));
END;
$$ LANGUAGE plpgsql;

-- Источник дерева. Узлу добавляется полный путь: при выборе группы в поле видно, где она
CREATE FUNCTION product_groups_tree(p_data JSON)
RETURNS JSON AS $$
    SELECT json_build_object('status', 'success', 'nodes', COALESCE(json_agg(
               n::jsonb || jsonb_build_object('path', product_group_path((n->>'id')::BIGINT))), '[]'::json))
    FROM json_array_elements(ui_tree_level(p_data, 'product_groups')->'nodes') AS n;
$$ LANGUAGE sql STABLE;


-- ---------------------------------------------------------------------
-- Товар: поле "Группа"
-- ---------------------------------------------------------------------
-- "Новый товар" со страницы групп сразу попадает в выбранную группу
CREATE OR REPLACE FUNCTION product_new_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_group BIGINT := ui_parse_id(p_data->>'group_tree');
BEGIN
    RETURN ui_ok(ui_open_form('product',
        p_title => 'Новый товар',
        p_data  => CASE WHEN v_group IS NOT NULL THEN jsonb_build_object(
                       'group_id', v_group::TEXT,
                       'group_id__display', product_group_path(v_group)) END));
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION product_edit_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_product products%ROWTYPE;
BEGIN
    SELECT * INTO v_product FROM products WHERE id = ui_parse_id(p_data->>'id');
    PERFORM ui_require(FOUND, 'Товар не найден — возможно, он удалён');

    RETURN ui_ok(ui_open_form('product',
        p_title => v_product.name,
        p_data  => jsonb_build_object(
            'id', v_product.id::TEXT,
            'name', v_product.name,
            'price', ui_money_input(v_product.price),
            'group_id', COALESCE(v_product.group_id::TEXT, ''),
            'group_id__display', COALESCE(product_group_path(v_product.group_id), ''))));
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION product_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_id    BIGINT  := ui_parse_id(p_data->>'id');
    v_name  VARCHAR := ui_text(p_data, 'name');
    v_price NUMERIC := ui_parse_money(p_data->>'price');
    v_group BIGINT  := ui_parse_id(p_data->>'group_id');
BEGIN
    PERFORM ui_require(v_name IS NOT NULL,  'Укажите наименование товара');
    PERFORM ui_require(v_price IS NOT NULL, 'Цена — число, например 1500 или 99,90');
    PERFORM ui_require(v_group IS NULL OR EXISTS (SELECT 1 FROM product_groups WHERE id = v_group),
                       'Группа не найдена — возможно, она удалена');
    PERFORM ui_require(
        NOT EXISTS (SELECT 1 FROM products WHERE lower(name) = lower(v_name) AND id IS DISTINCT FROM v_id),
        format('Товар «%s» уже есть в справочнике', v_name));

    IF ui_is_new(p_data) THEN
        INSERT INTO products (name, price, group_id) VALUES (v_name, v_price, v_group);
    ELSE
        UPDATE products SET name = v_name, price = v_price, group_id = v_group WHERE id = v_id;
        PERFORM ui_require(FOUND, 'Товар не найден — возможно, он удалён');
    END IF;

    RETURN ui_ok(
        ui_close_form(),
        ui_refresh_grid('products_grid', p_keep_page => NOT ui_is_new(p_data)));
END;
$$ LANGUAGE plpgsql;


-- ---------------------------------------------------------------------
-- Метаданные
-- ---------------------------------------------------------------------
INSERT INTO pgerp.ui_actions (action_name, function_name, description) VALUES
    ('product_groups_tree',       'product_groups_tree',       'Дерево: группы товаров'),
    ('group_products_page',       'group_products_page',       'Таблица: товары выбранной группы'),
    ('product_group_new_open',    'product_group_new_open',    'Новая группа товаров (подгруппа выбранной)'),
    ('product_group_edit_open',   'product_group_edit_open',   'Карточка выбранной группы товаров'),
    ('product_group_save',        'product_group_save',        'Сохранение группы товаров'),
    ('product_group_delete',      'product_group_delete',      'Удаление группы товаров'),
    ('product_group_select_open', 'product_group_select_open', 'Выбор группы товаров из дерева');

INSERT INTO pgerp.grid_columns (action_name, display_order, field_name, column_title, cell_type, sort_column) VALUES
    ('group_products_page', 1, 'name',  'Наименование', 'text',  'name'),
    ('group_products_page', 2, 'price', 'Цена',         'money', 'price'),
    ('products_page',       3, 'group_name', 'Группа',  'text',  'group_name');

INSERT INTO pgerp.grid_row_actions (source_action, sort_order, row_action, label, style)
SELECT 'group_products_page', sort_order, row_action, label, style
FROM pgerp.grid_row_actions
WHERE source_action = 'products_page';

INSERT INTO pgerp.forms (form_name, title, folder) VALUES
    ('product_groups', 'Группы товаров', 'Заказы'),
    ('product_group',  'Группа товаров', 'Заказы');

INSERT INTO pgerp.form_components (form_name, sort_order, component_type, component_name, label, action_event, master_field) VALUES
    ('product_groups', 1, 'tree',   'group_tree',       'Группы',          'product_groups_tree',     NULL),
    ('product_groups', 2, 'button', 'btn_group_new',    'Добавить группу', 'product_group_new_open',  NULL),
    ('product_groups', 3, 'button', 'btn_group_edit',   'Изменить',        'product_group_edit_open', NULL),
    ('product_groups', 4, 'button', 'btn_group_delete', 'Удалить',         'product_group_delete',    NULL),
    ('product_groups', 5, 'button', 'btn_product_new',  'Новый товар',     'product_new_open',        NULL),
    ('product_groups', 6, 'grid',   'products_grid',    'Товары группы',   'group_products_page',     'group_tree'),

    ('product_group',  1, 'hidden', 'id',               NULL,                   NULL,                        NULL),
    ('product_group',  2, 'input',  'name',             'Наименование',         NULL,                        NULL),
    ('product_group',  3, 'lookup', 'parent_id',        'Родительская группа',  'product_group_select_open', NULL),
    ('product_group',  4, 'button', 'btn_save',         'Сохранить',            'product_group_save',        NULL),
    ('product_group',  5, 'button', 'btn_cancel',       'Отмена',               'form_close',                NULL);

-- Карточка товара: "Группа" после цены
UPDATE pgerp.form_components SET sort_order = sort_order + 1
WHERE form_name = 'product' AND sort_order >= 4;
INSERT INTO pgerp.form_components (form_name, sort_order, component_type, component_name, label, action_event)
VALUES ('product', 4, 'lookup', 'group_id', 'Группа', 'product_group_select_open');

UPDATE pgerp.forms SET updated_at = now() WHERE form_name IN ('product', 'products');
