-- =====================================================================
-- Помощники для чтения формы и проверок ввода:
--
--     v_name VARCHAR := ui_text(p_data, 'name');        -- trim, пустая строка → NULL
--     PERFORM ui_require(v_name IS NOT NULL, 'Укажите наименование');
--     IF NOT ui_confirmed(p_data) THEN ... ui_confirm(...)
--
-- ui_require — для правил "должно быть так". Правила вида "если X, то ошибка"
-- (например, "таблица без действия") остаются явным IF ... RAISE EXCEPTION:
-- переворачивать их в положительное условие — хуже читается.
--
-- Обработчики переписаны на помощников; поведение не меняется
-- (кроме даты оплаты: принимается и ГГГГ-ММ-ДД, как дата заказа).
-- =====================================================================

-- ---------------------------------------------------------------------
-- Помощники
-- ---------------------------------------------------------------------

-- Текст поля формы без пробелов по краям; пустое поле — NULL
CREATE FUNCTION ui_text(p_data JSON, p_field TEXT)
RETURNS TEXT AS $$
    SELECT NULLIF(trim(p_data->>p_field), '');
$$ LANGUAGE sql IMMUTABLE;

-- Запись ещё не сохранялась: в форме нет id
CREATE FUNCTION ui_is_new(p_data JSON)
RETURNS BOOLEAN AS $$
    SELECT ui_text(p_data, 'id') IS NULL;
$$ LANGUAGE sql IMMUTABLE;

-- Пользователь уже согласился в окне подтверждения (см. ui_confirm)
CREATE FUNCTION ui_confirmed(p_data JSON)
RETURNS BOOLEAN AS $$
    SELECT COALESCE(p_data->>'confirmed' = 'true', FALSE);
$$ LANGUAGE sql IMMUTABLE;

-- Проверка ввода: если условие ложно или NULL — ошибка для пользователя (RAISE EXCEPTION).
-- NULL считается нарушением, поэтому v_text ~ '...' заодно проверяет, что поле заполнено.
CREATE FUNCTION ui_require(p_ok BOOLEAN, p_message TEXT)
RETURNS VOID AS $$
BEGIN
    IF p_ok IS NOT TRUE THEN
        RAISE EXCEPTION '%', p_message;
    END IF;
END;
$$ LANGUAGE plpgsql;


-- ---------------------------------------------------------------------
-- Системные действия
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION ui_form_delete(p_data JSON)
RETURNS JSON AS $$
BEGIN
    DELETE FROM erp_forms WHERE form_name = p_data->>'form';
    PERFORM ui_require(FOUND, format('Форма "%s" не найдена', p_data->>'form'));

    RETURN ui_ok();
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION ui_form_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_form_name  VARCHAR := p_data->>'name';
    v_title      VARCHAR := ui_text(p_data, 'title');
    v_folder     VARCHAR := ui_text(p_data, 'folder');
    v_components JSON    := COALESCE(p_data->'components', '[]'::json);
    v_comp       RECORD;
BEGIN
    PERFORM ui_require(v_form_name ~ '^[a-z_][a-z0-9_]*$',
                       'Имя формы: латинские буквы в нижнем регистре, цифры и "_"');

    FOR v_comp IN
        SELECT c->>'type' AS type, c->>'name' AS name, NULLIF(c->>'action', '') AS action,
               NULLIF(c->>'master', '') AS master, c->'options' AS options, n
        FROM json_array_elements(v_components) WITH ORDINALITY AS t(c, n)
    LOOP
        PERFORM ui_require(v_comp.type = ANY (ui_component_types()),
                           format('Компонент №%s: неизвестный тип "%s"', v_comp.n, v_comp.type));
        PERFORM ui_require(v_comp.name ~ '^[a-z_][a-z0-9_]*$',
                           format('Компонент №%s: имя — латинские буквы в нижнем регистре, цифры и "_"', v_comp.n));

        IF v_comp.type = 'grid' AND v_comp.action IS NULL THEN
            RAISE EXCEPTION 'Таблица "%": выберите действие-источник данных', v_comp.name;
        END IF;
        IF v_comp.type = 'lookup' AND v_comp.action IS NULL THEN
            RAISE EXCEPTION 'Поле выбора "%": выберите действие открытия списка', v_comp.name;
        END IF;
        IF v_comp.type = 'timer' AND v_comp.action IS NULL THEN
            RAISE EXCEPTION 'Таймер "%": выберите действие', v_comp.name;
        END IF;

        IF v_comp.action IS NOT NULL THEN
            PERFORM ui_require(
                EXISTS (SELECT 1 FROM erp_ui_actions WHERE action_name = v_comp.action AND NOT is_system),
                format('Компонент "%s": действие "%s" не зарегистрировано', v_comp.name, v_comp.action));
        END IF;
        IF v_comp.type = 'grid' AND v_comp.master IS NOT NULL THEN
            PERFORM ui_require(
                EXISTS (SELECT 1 FROM json_array_elements(v_components) c
                        WHERE c->>'name' = v_comp.master AND c->>'type' IN ('input', 'hidden', 'lookup')),
                format('Таблица "%s": поле-мастер "%s" не найдено среди полей формы', v_comp.name, v_comp.master));
        END IF;
        IF v_comp.options IS NOT NULL AND json_typeof(v_comp.options) NOT IN ('object', 'null') THEN
            RAISE EXCEPTION 'Компонент "%": параметры должны быть объектом JSON', v_comp.name;
        END IF;
    END LOOP;

    PERFORM ui_require(
        (SELECT count(*) = count(DISTINCT c->>'name') FROM json_array_elements(v_components) c),
        'Имена компонентов должны быть уникальны');

    INSERT INTO erp_forms (form_name, title, folder)
    VALUES (v_form_name, COALESCE(v_title, v_form_name), v_folder)
    ON CONFLICT (form_name) DO UPDATE
        SET title = EXCLUDED.title, folder = EXCLUDED.folder, updated_at = now();

    DELETE FROM erp_form_components WHERE form_name = v_form_name;

    INSERT INTO erp_form_components
        (form_name, sort_order, component_type, component_name, label, action_event, master_field, tab, options)
    SELECT v_form_name, n, c->>'type', c->>'name', c->>'label', NULLIF(c->>'action', ''),
           CASE WHEN c->>'type' = 'grid' THEN NULLIF(c->>'master', '') END,
           CASE WHEN c->>'type' NOT IN ('hidden', 'timer') THEN NULLIF(trim(c->>'tab'), '') END,
           CASE WHEN json_typeof(c->'options') = 'object' AND (c->'options')::jsonb <> '{}' THEN (c->'options')::jsonb END
    FROM json_array_elements(v_components) WITH ORDINALITY AS t(c, n);

    RETURN ui_ok(ui_message(format('Форма "%s" сохранена', v_form_name)));
END;
$$ LANGUAGE plpgsql;


-- ---------------------------------------------------------------------
-- Примеры
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION hello_run(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_name VARCHAR := ui_text(p_data, 'user_name');
BEGIN
    PERFORM ui_require(v_name IS NOT NULL, 'Введите имя');

    RETURN ui_ok(ui_message('Привет, ' || v_name));
END;
$$ LANGUAGE plpgsql;

-- Состояние игры из формы; NULL — игра не идёт
CREATE OR REPLACE FUNCTION game_current(p_data JSON)
RETURNS JSONB AS $$
    SELECT ui_text(p_data, 'state')::JSONB;
$$ LANGUAGE sql IMMUTABLE;

-- Пауза: таймер выключается или снова включается
CREATE OR REPLACE FUNCTION game_pause(p_data JSON)
RETURNS JSON AS $$
BEGIN
    IF game_current(p_data) IS NULL THEN
        RETURN ui_ok();
    END IF;
    RETURN ui_ok(ui_set_values(jsonb_build_object(
        'ticker', CASE WHEN ui_text(p_data, 'ticker') IS NULL THEN '1' ELSE '' END)));
END;
$$ LANGUAGE plpgsql;


-- ---------------------------------------------------------------------
-- Справочники: клиенты и товары
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION customer_edit_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_customer erp_customers%ROWTYPE;
BEGIN
    SELECT * INTO v_customer FROM erp_customers WHERE id = ui_parse_id(p_data->>'id');
    PERFORM ui_require(FOUND, 'Клиент не найден — возможно, он удалён');

    RETURN ui_ok(ui_open_form('customer',
        p_title => v_customer.name,
        p_data  => jsonb_build_object(
            'id', v_customer.id::TEXT,
            'name', v_customer.name,
            'phone', COALESCE(v_customer.phone, ''))));
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION customer_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_id    BIGINT  := ui_parse_id(p_data->>'id');
    v_name  VARCHAR := ui_text(p_data, 'name');
    v_phone VARCHAR := ui_text(p_data, 'phone');
BEGIN
    PERFORM ui_require(v_name IS NOT NULL, 'Укажите наименование клиента');
    PERFORM ui_require(
        NOT EXISTS (SELECT 1 FROM erp_customers WHERE lower(name) = lower(v_name) AND id IS DISTINCT FROM v_id),
        format('Клиент «%s» уже есть в справочнике', v_name));

    IF ui_is_new(p_data) THEN
        INSERT INTO erp_customers (name, phone) VALUES (v_name, v_phone);
    ELSE
        UPDATE erp_customers SET name = v_name, phone = v_phone WHERE id = v_id;
        PERFORM ui_require(FOUND, 'Клиент не найден — возможно, он удалён');
    END IF;

    RETURN ui_ok(
        ui_close_form(),
        ui_refresh_grid('customers_grid', p_keep_page => NOT ui_is_new(p_data)),
        ui_refresh_grid('orders_grid', p_keep_page => TRUE));
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION product_edit_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_product erp_products%ROWTYPE;
BEGIN
    SELECT * INTO v_product FROM erp_products WHERE id = ui_parse_id(p_data->>'id');
    PERFORM ui_require(FOUND, 'Товар не найден — возможно, он удалён');

    RETURN ui_ok(ui_open_form('product',
        p_title => v_product.name,
        p_data  => jsonb_build_object(
            'id', v_product.id::TEXT,
            'name', v_product.name,
            'price', ui_money_input(v_product.price))));
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION product_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_id    BIGINT  := ui_parse_id(p_data->>'id');
    v_name  VARCHAR := ui_text(p_data, 'name');
    v_price NUMERIC := ui_parse_money(p_data->>'price');
BEGIN
    PERFORM ui_require(v_name IS NOT NULL,  'Укажите наименование товара');
    PERFORM ui_require(v_price IS NOT NULL, 'Цена — число, например 1500 или 99,90');
    PERFORM ui_require(
        NOT EXISTS (SELECT 1 FROM erp_products WHERE lower(name) = lower(v_name) AND id IS DISTINCT FROM v_id),
        format('Товар «%s» уже есть в справочнике', v_name));

    IF ui_is_new(p_data) THEN
        INSERT INTO erp_products (name, price) VALUES (v_name, v_price);
    ELSE
        UPDATE erp_products SET name = v_name, price = v_price WHERE id = v_id;
        PERFORM ui_require(FOUND, 'Товар не найден — возможно, он удалён');
    END IF;

    RETURN ui_ok(
        ui_close_form(),
        ui_refresh_grid('products_grid', p_keep_page => NOT ui_is_new(p_data)));
END;
$$ LANGUAGE plpgsql;


-- ---------------------------------------------------------------------
-- Заказ (шапка)
-- ---------------------------------------------------------------------

-- Шапка заказа (клиент и дата): новый заказ создаётся черновиком; возвращает id
CREATE OR REPLACE FUNCTION order_upsert(p_data JSON)
RETURNS BIGINT AS $$
DECLARE
    v_customer BIGINT := ui_parse_id(p_data->>'customer_id');
    v_date     DATE   := ui_parse_date(p_data->>'order_date');
    v_id       BIGINT;
BEGIN
    PERFORM ui_require(v_customer IS NOT NULL, 'Выберите клиента');
    PERFORM ui_require(EXISTS (SELECT 1 FROM erp_customers WHERE id = v_customer),
                       'Клиент не найден — возможно, он удалён');
    PERFORM ui_require(v_date IS NOT NULL, 'Укажите дату заказа');

    IF ui_is_new(p_data) THEN
        INSERT INTO erp_orders (customer_id, order_date, status)
        VALUES (v_customer, v_date, 'DRAFT')
        RETURNING id INTO v_id;
        RETURN v_id;
    END IF;

    UPDATE erp_orders SET customer_id = v_customer, order_date = v_date
    WHERE id = ui_parse_id(p_data->>'id')
    RETURNING id INTO v_id;
    PERFORM ui_require(FOUND, format('Заказ №%s не найден — возможно, он уже удалён', ui_text(p_data, 'id')));

    RETURN v_id;
END;
$$ LANGUAGE plpgsql;

-- Открытие заказа запоминает его сохранённую версию (см. V15)
CREATE OR REPLACE FUNCTION order_edit_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_order erp_orders_v%ROWTYPE;
BEGIN
    SELECT * INTO v_order FROM erp_orders_v WHERE id = ui_parse_id(p_data->>'id');
    PERFORM ui_require(FOUND, format('Заказ №%s не найден — возможно, он уже удалён', p_data->>'id'));

    IF v_order.status <> 'DRAFT' THEN
        INSERT INTO erp_order_snapshots (order_id, state)
        VALUES (v_order.id, order_state(v_order.id))
        ON CONFLICT (order_id) DO NOTHING;
    END IF;

    RETURN ui_ok(ui_open_form('order_new',
        p_title => format(CASE WHEN v_order.status = 'DRAFT' THEN 'Заказ №%s (черновик)' ELSE 'Заказ №%s' END,
                          v_order.id),
        p_data  => jsonb_build_object(
            'id', v_order.id::TEXT,
            'customer_id', v_order.customer_id::TEXT,
            'customer_id__display', v_order.customer,
            'order_date', to_char(v_order.order_date_value, 'YYYY-MM-DD'),
            'order_total', ui_format_money(v_order.total))));
END;
$$ LANGUAGE plpgsql;

-- "Сохранить": шапка, проверка заказа целиком, черновик становится заказом; окно закрывается
CREATE OR REPLACE FUNCTION order_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_id BIGINT := order_upsert(p_data);
BEGIN
    PERFORM ui_require(EXISTS (SELECT 1 FROM erp_order_lines WHERE order_id = v_id),
                       'Добавьте в заказ хотя бы одну позицию');

    UPDATE erp_orders SET status = 'NEW' WHERE id = v_id AND status = 'DRAFT';
    DELETE FROM erp_order_snapshots WHERE order_id = v_id;

    RETURN ui_ok(
        ui_close_form(),
        ui_refresh_grid('orders_grid', p_keep_page => NOT ui_is_new(p_data)),
        ui_message(format('Заказ №%s сохранён', v_id)));
END;
$$ LANGUAGE plpgsql;

-- "Отмена" (и закрытие окна): черновик удаляется, сохранённый заказ возвращается к снимку.
-- Если что-то было изменено, сначала переспрашивает. Шапка (клиент и дата) берётся из формы —
-- её изменения ещё не записаны в базу.
CREATE OR REPLACE FUNCTION order_cancel(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_order    erp_orders%ROWTYPE;
    v_snapshot JSONB;
    v_changed  BOOLEAN;
    v_close    JSONB := jsonb_build_array(ui_close_form(), ui_refresh_grid('orders_grid', p_keep_page => TRUE));
BEGIN
    SELECT * INTO v_order FROM erp_orders WHERE id = ui_parse_id(p_data->>'id');
    IF NOT FOUND THEN
        -- Заказ ещё не создавался или уже удалён — отменять нечего
        RETURN ui_ok(v_close);
    END IF;

    SELECT state INTO v_snapshot FROM erp_order_snapshots WHERE order_id = v_order.id;

    v_changed := CASE
        WHEN v_order.status = 'DRAFT' THEN
            EXISTS (SELECT 1 FROM erp_order_lines WHERE order_id = v_order.id)
            OR EXISTS (SELECT 1 FROM erp_order_payments WHERE order_id = v_order.id)
        ELSE
            v_snapshot IS NOT NULL
            AND v_snapshot IS DISTINCT FROM order_state(v_order.id) || jsonb_build_object(
                'customer_id', ui_parse_id(p_data->>'customer_id'),
                'order_date', ui_parse_date(p_data->>'order_date'))
    END;

    IF v_changed AND NOT ui_confirmed(p_data) THEN
        RETURN ui_ok(ui_confirm(
            CASE WHEN v_order.status = 'DRAFT'
                THEN format('Закрыть без сохранения? Черновик заказа №%s с позициями и оплатами будет удалён.',
                            v_order.id)
                ELSE format('Закрыть без сохранения? Изменения в заказе №%s будут отменены.', v_order.id)
            END,
            'order_cancel',
            jsonb_build_object('id', v_order.id::TEXT, 'confirmed', TRUE),
            p_confirm_label => 'Не сохранять'));
    END IF;

    IF v_order.status = 'DRAFT' THEN
        DELETE FROM erp_orders WHERE id = v_order.id;  -- позиции и оплаты удаляются каскадно
    ELSIF v_snapshot IS NOT NULL THEN
        PERFORM order_restore(v_order.id, v_snapshot);
        DELETE FROM erp_order_snapshots WHERE order_id = v_order.id;
    END IF;

    RETURN ui_ok(v_close);
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION order_delete(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_order erp_orders_v%ROWTYPE;
BEGIN
    SELECT * INTO v_order FROM erp_orders_v WHERE id = ui_parse_id(p_data->>'id');
    PERFORM ui_require(FOUND, format('Заказ №%s не найден — возможно, он уже удалён', p_data->>'id'));

    IF NOT ui_confirmed(p_data) THEN
        RETURN ui_ok(ui_confirm(
            format('Удалить заказ №%s?' || E'\n' || '%s — позиций: %s, сумма %s',
                   v_order.id, v_order.customer, v_order.lines_count, ui_format_money(v_order.total)),
            'order_delete',
            jsonb_build_object('id', v_order.id, 'confirmed', TRUE),
            p_confirm_label => 'Удалить'));
    END IF;

    DELETE FROM erp_orders WHERE id = v_order.id;  -- позиции и оплаты удаляются каскадно

    RETURN ui_ok(
        ui_refresh_grid('orders_grid', p_keep_page => TRUE),
        ui_message(format('Заказ №%s удалён', v_order.id)));
END;
$$ LANGUAGE plpgsql;


-- ---------------------------------------------------------------------
-- Позиции заказа
-- ---------------------------------------------------------------------

-- "Добавить позицию": у нового заказа сначала сохраняется шапка (черновиком)
CREATE OR REPLACE FUNCTION order_line_new_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_id BIGINT := order_upsert(p_data);
BEGIN
    RETURN ui_ok(
        order_header_saved(ui_is_new(p_data), v_id),
        ui_open_form('order_line',
            p_title => 'Новая позиция',
            p_data  => jsonb_build_object('order_id', v_id::TEXT, 'quantity', '1')));
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION order_line_edit_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_line erp_order_lines_v%ROWTYPE;
BEGIN
    SELECT * INTO v_line FROM erp_order_lines_v WHERE id = ui_parse_id(p_data->>'id');
    PERFORM ui_require(FOUND, 'Позиция не найдена — возможно, она уже удалена');

    RETURN ui_ok(ui_open_form('order_line',
        p_title => format('Позиция: %s', v_line.product),
        p_data  => jsonb_build_object(
            'id', v_line.id::TEXT,
            'order_id', v_line.order_id::TEXT,
            'product_id', v_line.product_id::TEXT,
            'product_id__display', v_line.product,
            'quantity', v_line.quantity::TEXT,
            'price', ui_money_input(v_line.price))));
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION order_line_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_order    BIGINT  := ui_parse_id(p_data->>'order_id');
    v_product  BIGINT  := ui_parse_id(p_data->>'product_id');
    v_quantity TEXT    := trim(p_data->>'quantity');
    v_price    NUMERIC := ui_parse_money(p_data->>'price');
BEGIN
    PERFORM ui_require(EXISTS (SELECT 1 FROM erp_orders WHERE id = v_order),
                       'Заказ не найден — возможно, он уже удалён');
    PERFORM ui_require(EXISTS (SELECT 1 FROM erp_products WHERE id = v_product), 'Выберите товар');
    PERFORM ui_require(v_quantity ~ '^[1-9]\d{0,5}$', 'Количество — целое число больше нуля');
    PERFORM ui_require(v_price IS NOT NULL, 'Цена — число, например 1500 или 99,90');

    IF ui_is_new(p_data) THEN
        INSERT INTO erp_order_lines (order_id, product_id, quantity, price)
        VALUES (v_order, v_product, v_quantity::INT, v_price);
    ELSE
        UPDATE erp_order_lines
        SET product_id = v_product, quantity = v_quantity::INT, price = v_price
        WHERE id = ui_parse_id(p_data->>'id') AND order_id = v_order;
        PERFORM ui_require(FOUND, 'Позиция не найдена — возможно, она уже удалена');
    END IF;

    RETURN ui_ok(
        ui_close_form(),
        ui_refresh_grid('order_lines_grid', p_keep_page => TRUE),
        ui_refresh_grid('orders_grid', p_keep_page => TRUE),
        order_total_update(v_order));
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION order_line_delete(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_line erp_order_lines_v%ROWTYPE;
BEGIN
    SELECT * INTO v_line FROM erp_order_lines_v WHERE id = ui_parse_id(p_data->>'id');
    PERFORM ui_require(FOUND, 'Позиция не найдена — возможно, она уже удалена');

    IF NOT ui_confirmed(p_data) THEN
        RETURN ui_ok(ui_confirm(
            format('Удалить позицию «%s», %s шт. на сумму %s?',
                   v_line.product, v_line.quantity, ui_format_money(v_line.total)),
            'order_line_delete',
            jsonb_build_object('id', v_line.id, 'confirmed', TRUE),
            p_confirm_label => 'Удалить'));
    END IF;

    DELETE FROM erp_order_lines WHERE id = v_line.id;

    RETURN ui_ok(
        ui_refresh_grid('order_lines_grid', p_keep_page => TRUE),
        ui_refresh_grid('orders_grid', p_keep_page => TRUE),
        order_total_update(v_line.order_id));
END;
$$ LANGUAGE plpgsql;


-- ---------------------------------------------------------------------
-- Оплаты заказа
-- ---------------------------------------------------------------------

-- "Добавить оплату": по умолчанию предлагается неоплаченный остаток
CREATE OR REPLACE FUNCTION order_payment_new_open(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_id   BIGINT := order_upsert(p_data);
    v_rest NUMERIC;
BEGIN
    SELECT total - paid INTO v_rest FROM erp_orders_v WHERE id = v_id;

    RETURN ui_ok(
        order_header_saved(ui_is_new(p_data), v_id),
        ui_open_form('order_payment',
            p_title => format('Оплата заказа №%s', v_id),
            p_data  => jsonb_build_object(
                'order_id', v_id::TEXT,
                'paid_on', to_char(current_date, 'DD.MM.YYYY'),
                'amount', CASE WHEN v_rest > 0 THEN ui_money_input(v_rest) ELSE '' END)));
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION order_payment_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_order  BIGINT  := ui_parse_id(p_data->>'order_id');
    v_date   DATE    := ui_parse_date(p_data->>'paid_on');
    v_amount NUMERIC := ui_parse_money(p_data->>'amount');
BEGIN
    PERFORM ui_require(EXISTS (SELECT 1 FROM erp_orders WHERE id = v_order),
                       'Заказ не найден — возможно, он уже удалён');
    PERFORM ui_require(v_date IS NOT NULL, 'Дата оплаты — в формате ДД.ММ.ГГГГ');
    PERFORM ui_require(v_amount > 0, 'Сумма оплаты — число больше нуля');

    INSERT INTO erp_order_payments (order_id, paid_on, amount) VALUES (v_order, v_date, v_amount);

    RETURN ui_ok(
        ui_close_form(),
        ui_refresh_grid('order_payments_grid', p_keep_page => TRUE),
        ui_refresh_grid('orders_grid', p_keep_page => TRUE));
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION order_payment_delete(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_payment erp_order_payments_v%ROWTYPE;
BEGIN
    SELECT * INTO v_payment FROM erp_order_payments_v WHERE id = ui_parse_id(p_data->>'id');
    PERFORM ui_require(FOUND, 'Оплата не найдена — возможно, она уже удалена');

    IF NOT ui_confirmed(p_data) THEN
        RETURN ui_ok(ui_confirm(
            format('Удалить оплату от %s на сумму %s?', v_payment.paid_date, ui_format_money(v_payment.amount)),
            'order_payment_delete',
            jsonb_build_object('id', v_payment.id, 'confirmed', TRUE),
            p_confirm_label => 'Удалить'));
    END IF;

    DELETE FROM erp_order_payments WHERE id = v_payment.id;

    RETURN ui_ok(
        ui_refresh_grid('order_payments_grid', p_keep_page => TRUE),
        ui_refresh_grid('orders_grid', p_keep_page => TRUE));
END;
$$ LANGUAGE plpgsql;
