-- =====================================================================
-- Data-Driven UI: метаданные форм, реестр действий и маршрутизатор.
-- =====================================================================

-- Реестр действий: какое действие UI какой PL/pgSQL-функцией обрабатывается.
-- Функция-обработчик имеет сигнатуру: fn(p_data JSON) RETURNS JSON.
CREATE TABLE erp_ui_actions (
    action_name   VARCHAR(100) PRIMARY KEY,
    function_name REGPROC      NOT NULL,
    description   VARCHAR(255),
    is_system     BOOLEAN      NOT NULL DEFAULT FALSE  -- системные действия не показываются в редакторе
);

CREATE TABLE erp_forms (
    form_name  VARCHAR(50)  PRIMARY KEY,
    title      VARCHAR(200) NOT NULL,
    updated_at TIMESTAMPTZ  NOT NULL DEFAULT now()
);

CREATE TABLE erp_form_components (
    id             SERIAL PRIMARY KEY,
    form_name      VARCHAR(50)  NOT NULL REFERENCES erp_forms ON DELETE CASCADE,
    sort_order     INT          NOT NULL,
    component_type VARCHAR(20)  NOT NULL CHECK (component_type IN ('label', 'input', 'button')),
    component_name VARCHAR(50)  NOT NULL,
    label          VARCHAR(200),
    action_event   VARCHAR(100) REFERENCES erp_ui_actions (action_name),
    UNIQUE (form_name, component_name)
);


-- ---------------------------------------------------------------------
-- Маршрутизатор: единственная функция, которую вызывает Java-диспетчер.
-- ---------------------------------------------------------------------
CREATE FUNCTION handle_ui_event(p_action VARCHAR, p_form_data JSON)
RETURNS JSON AS $$
DECLARE
    v_function REGPROC;
    v_result   JSON;
BEGIN
    SELECT function_name INTO v_function
    FROM erp_ui_actions
    WHERE action_name = p_action;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Неизвестное действие: %', p_action;
    END IF;

    -- regproc при выводе даёт корректно экранированное имя функции
    EXECUTE format('SELECT %s($1)', v_function) INTO v_result USING p_form_data;
    RETURN v_result;
END;
$$ LANGUAGE plpgsql;


-- ---------------------------------------------------------------------
-- Системные действия редактора форм.
-- ---------------------------------------------------------------------

-- Структура формы: {"form": {"name", "title", "components": [...]}}
CREATE FUNCTION ui_form_get(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_form_name VARCHAR := p_data->>'form';
    v_form      JSON;
BEGIN
    SELECT json_build_object(
               'name', f.form_name,
               'title', f.title,
               'components', COALESCE((
                   SELECT json_agg(json_build_object(
                              'type', c.component_type,
                              'name', c.component_name,
                              'label', c.label,
                              'action', c.action_event)
                          ORDER BY c.sort_order)
                   FROM erp_form_components c
                   WHERE c.form_name = f.form_name), '[]'::json))
    INTO v_form
    FROM erp_forms f
    WHERE f.form_name = v_form_name;

    IF v_form IS NULL THEN
        RAISE EXCEPTION 'Форма "%" не найдена', v_form_name;
    END IF;

    RETURN json_build_object('status', 'success', 'form', v_form);
END;
$$ LANGUAGE plpgsql;


-- Список форм и доступных (несистемных) действий для кнопок.
CREATE FUNCTION ui_form_list(p_data JSON)
RETURNS JSON AS $$
BEGIN
    RETURN json_build_object(
        'status', 'success',
        'forms', COALESCE((
            SELECT json_agg(json_build_object('name', form_name, 'title', title) ORDER BY form_name)
            FROM erp_forms), '[]'::json),
        'actions', COALESCE((
            SELECT json_agg(json_build_object('name', action_name, 'description', description)
                            ORDER BY action_name)
            FROM erp_ui_actions
            WHERE NOT is_system), '[]'::json));
END;
$$ LANGUAGE plpgsql;


-- Сохранение формы целиком: {"name", "title", "components": [{"type","name","label","action"}, ...]}
CREATE FUNCTION ui_form_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_form_name VARCHAR := p_data->>'name';
    v_title     VARCHAR := NULLIF(trim(p_data->>'title'), '');
    v_comp      RECORD;
BEGIN
    IF v_form_name IS NULL OR v_form_name !~ '^[a-z_][a-z0-9_]*$' THEN
        RAISE EXCEPTION 'Имя формы: латинские буквы в нижнем регистре, цифры и "_"';
    END IF;

    -- Валидация компонентов с понятными пользователю сообщениями
    FOR v_comp IN
        SELECT c->>'type' AS type, c->>'name' AS name, NULLIF(c->>'action', '') AS action, n
        FROM json_array_elements(COALESCE(p_data->'components', '[]'::json)) WITH ORDINALITY AS t(c, n)
    LOOP
        IF v_comp.type IS NULL OR v_comp.type NOT IN ('label', 'input', 'button') THEN
            RAISE EXCEPTION 'Компонент №%: неизвестный тип "%"', v_comp.n, v_comp.type;
        END IF;
        IF v_comp.name IS NULL OR v_comp.name !~ '^[a-z_][a-z0-9_]*$' THEN
            RAISE EXCEPTION 'Компонент №%: имя — латинские буквы в нижнем регистре, цифры и "_"', v_comp.n;
        END IF;
        IF v_comp.action IS NOT NULL
           AND NOT EXISTS (SELECT 1 FROM erp_ui_actions WHERE action_name = v_comp.action AND NOT is_system) THEN
            RAISE EXCEPTION 'Компонент "%": действие "%" не зарегистрировано', v_comp.name, v_comp.action;
        END IF;
    END LOOP;

    IF (SELECT count(*) <> count(DISTINCT c->>'name')
        FROM json_array_elements(COALESCE(p_data->'components', '[]'::json)) c) THEN
        RAISE EXCEPTION 'Имена компонентов должны быть уникальны';
    END IF;

    INSERT INTO erp_forms (form_name, title)
    VALUES (v_form_name, COALESCE(v_title, v_form_name))
    ON CONFLICT (form_name) DO UPDATE
        SET title = EXCLUDED.title, updated_at = now();

    DELETE FROM erp_form_components WHERE form_name = v_form_name;

    INSERT INTO erp_form_components (form_name, sort_order, component_type, component_name, label, action_event)
    SELECT v_form_name, n, c->>'type', c->>'name', c->>'label', NULLIF(c->>'action', '')
    FROM json_array_elements(COALESCE(p_data->'components', '[]'::json)) WITH ORDINALITY AS t(c, n);

    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_object(
            'command', 'show_message',
            'text', format('Форма "%s" сохранена', v_form_name)));
END;
$$ LANGUAGE plpgsql;


CREATE FUNCTION ui_form_delete(p_data JSON)
RETURNS JSON AS $$
BEGIN
    DELETE FROM erp_forms WHERE form_name = p_data->>'form';
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Форма "%" не найдена', p_data->>'form';
    END IF;
    RETURN json_build_object('status', 'success');
END;
$$ LANGUAGE plpgsql;


INSERT INTO erp_ui_actions (action_name, function_name, description, is_system) VALUES
    ('form_get',    'ui_form_get',    'Структура формы',            TRUE),
    ('form_list',   'ui_form_list',   'Список форм и действий',     TRUE),
    ('form_save',   'ui_form_save',   'Сохранение формы',           TRUE),
    ('form_delete', 'ui_form_delete', 'Удаление формы',             TRUE);
