-- =====================================================================
-- Чат: автор — вошедший пользователь, а не поле «Имя» на форме.
-- Подменить автора из браузера нельзя: логин в базу передаёт сервер из сессии (ui_user()).
-- =====================================================================

-- Имя пользователя для показа: имя из учётной записи, иначе логин
CREATE FUNCTION pgerp.ui_user_name()
RETURNS VARCHAR AS $$
    SELECT COALESCE(NULLIF(trim(full_name), ''), login) FROM pgerp.users WHERE id = pgerp.ui_user_id();
$$ LANGUAGE sql STABLE;

CREATE OR REPLACE FUNCTION chat_send(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_author TEXT := ui_user_name();
    v_text   TEXT := ui_text(p_data, 'message');
BEGIN
    PERFORM ui_require(v_text IS NOT NULL, 'Напишите сообщение');

    INSERT INTO chat_messages (author, text) VALUES (left(v_author, 50), left(v_text, 500));

    -- Таблица обновится у всех, где открыт чат, в том числе у отправителя.
    -- Команда уйдёт при фиксации транзакции — когда сообщение уже видно в базе.
    PERFORM ui_push_to('chat', ui_refresh_grid('chat_grid'));

    RETURN ui_ok(ui_clear_fields('message'));
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION chat_announce(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_author TEXT := ui_user_name();
    v_text   TEXT := ui_text(p_data, 'message');
BEGIN
    PERFORM ui_require(v_text IS NOT NULL, 'Напишите текст объявления');

    PERFORM ui_push(ui_message(format('Объявление от %s: %s', v_author, left(v_text, 500))));

    RETURN ui_ok(ui_clear_fields('message'));
END;
$$ LANGUAGE plpgsql;

-- Поле «Имя» больше не нужно
DELETE FROM pgerp.form_components WHERE form_name = 'chat' AND component_name = 'author';
UPDATE pgerp.forms SET updated_at = now() WHERE form_name = 'chat';

-- Сообщение «Представьтесь — укажите имя» больше не используется
DELETE FROM pgerp.translations WHERE source = 'Представьтесь — укажите имя';
