-- =====================================================================
-- Ошибка с инструкциями UI и очистка полей.
--
--     PERFORM ui_error('Деление на ноль невозможно', ui_clear_fields('result'));
--
-- ui_error — это RAISE EXCEPTION с кодом U0001, инструкции передаются в DETAIL.
-- Маршрутизатор перехватывает только этот код: изменения обработчика откатываются
-- (блок EXCEPTION — подтранзакция), клиент получает
-- {"status": "error", "message": ..., "ui_instructions": [...]}, выполняет инструкции
-- и показывает текст ошибки. Остальные ошибки проходят как раньше (HTTP 422 / 500).
-- =====================================================================

-- Очистить поля этой формы (или другой открытой формы — через ui_set_values)
CREATE FUNCTION ui_clear_fields(VARIADIC p_fields TEXT[])
RETURNS JSONB AS $$
    SELECT ui_set_values(jsonb_object_agg(f, '')) FROM unnest(p_fields) AS f;
$$ LANGUAGE sql IMMUTABLE;

-- Ошибка для пользователя; инструкции выполняются клиентом перед показом текста
CREATE FUNCTION ui_error(p_message TEXT, VARIADIC p_instructions JSONB[] DEFAULT '{}')
RETURNS VOID AS $$
BEGIN
    RAISE EXCEPTION USING
        MESSAGE = p_message,
        ERRCODE = 'U0001',
        DETAIL  = (ui_ok(VARIADIC p_instructions)->'ui_instructions')::TEXT;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION handle_ui_event(p_action VARCHAR, p_form_data JSON)
RETURNS JSON AS $$
DECLARE
    v_function     REGPROC;
    v_result       JSON;
    v_message      TEXT;
    v_instructions TEXT;
BEGIN
    SELECT function_name INTO v_function
    FROM erp_ui_actions
    WHERE action_name = p_action;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Неизвестное действие: %', p_action;
    END IF;

    BEGIN
        -- regproc при выводе даёт корректно экранированное имя функции
        EXECUTE format('SELECT %s($1)', v_function) INTO v_result USING p_form_data;
    EXCEPTION WHEN SQLSTATE 'U0001' THEN
        GET STACKED DIAGNOSTICS v_message = MESSAGE_TEXT, v_instructions = PG_EXCEPTION_DETAIL;
        RETURN json_build_object(
            'status', 'error',
            'message', v_message,
            'ui_instructions', v_instructions::JSON);
    END;
    RETURN v_result;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION division_run(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_a NUMERIC := division_parse(p_data->>'a', 'a');
    v_b NUMERIC := division_parse(p_data->>'b', 'b');
BEGIN
    IF v_b = 0 THEN
        PERFORM ui_error('Деление на ноль невозможно', ui_clear_fields('result'));
    END IF;

    RETURN ui_ok(ui_set_values(jsonb_build_object(
        'result', replace(trim_scale(round(v_a / v_b, 10))::TEXT, '.', ','))));
END;
$$ LANGUAGE plpgsql;
