-- =====================================================================
-- Тип ячейки 'datetime': дата и время выводятся без переноса строки.
-- =====================================================================

ALTER TABLE erp_grid_columns DROP CONSTRAINT erp_grid_columns_cell_type_check;
ALTER TABLE erp_grid_columns ADD CONSTRAINT erp_grid_columns_cell_type_check
    CHECK (cell_type IN ('text', 'datetime', 'number', 'money', 'badge'));

UPDATE erp_grid_columns SET cell_type = 'datetime'
WHERE action_name = 'orders_page' AND field_name = 'order_date';
