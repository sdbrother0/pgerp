-- =====================================================================
-- Исправление: «Перевести» в списке «Без перевода» отвечало «Текст уже переведён или больше
-- не используется». id строки был 60-битным хешем (до 19 цифр): ui_parse_id принимает не больше
-- 18 цифр, а браузер точно хранит целые числа только до 2^53 и округлял id. Теперь хеш — 52 бита
-- (не больше 16 цифр): проходит ui_parse_id и не теряет точность в JavaScript.
-- =====================================================================

CREATE OR REPLACE VIEW pgerp.translation_missing_v AS
SELECT ('x' || substr(md5(l.code || chr(1) || t.source), 1, 13))::BIT(52)::BIGINT AS id,
       l.code AS lang, t.source, t.origin
FROM pgerp.languages l
CROSS JOIN pgerp.translatable_texts t
WHERE NOT l.is_source
  AND NOT EXISTS (SELECT 1 FROM pgerp.translations tr WHERE tr.lang = l.code AND tr.source = t.source);
