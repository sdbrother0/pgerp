-- =====================================================================
-- Схема erp: ядро платформы — маршрутизатор, помощники ответов и проверок,
-- источник данных таблиц, редактор форм. В public остаётся прикладной код:
-- заказы, справочники, примеры.
--
-- Прикладной код по-прежнему вызывает помощники без схемы — ui_ok(...), ui_require(...),
-- потому что search_path = public, erp:
--  * у базы — для новых подключений (миграции, psql);
--  * у маршрутизатора — обработчики находят ui_* при любом search_path подключения,
--    в том числе в пуле, открытом до этой миграции.
--
-- Новая функция ядра создаётся с явной схемой: CREATE FUNCTION erp.ui_...;
-- без схемы функция попадает в public.
--
-- Функции переносятся вместе с OID, поэтому ссылки на них остаются рабочими:
-- erp_ui_actions.function_name (REGPROC), проверка типа компонента, представление erp_products_v.
-- Таблицы остаются в public.
-- =====================================================================

CREATE SCHEMA erp;

-- Маршрутизатор и системные действия редактора форм
ALTER FUNCTION handle_ui_event(VARCHAR, JSON) SET SCHEMA erp;
ALTER FUNCTION ui_form_list(JSON)             SET SCHEMA erp;
ALTER FUNCTION ui_form_get(JSON)              SET SCHEMA erp;
ALTER FUNCTION ui_form_save(JSON)             SET SCHEMA erp;
ALTER FUNCTION ui_form_delete(JSON)           SET SCHEMA erp;
ALTER FUNCTION ui_form_close(JSON)            SET SCHEMA erp;
ALTER FUNCTION ui_component_types()           SET SCHEMA erp;

-- Ответы действий и инструкции UI
ALTER FUNCTION ui_instruction(TEXT, JSONB)                                SET SCHEMA erp;
ALTER FUNCTION ui_ok(JSONB[])                                             SET SCHEMA erp;
ALTER FUNCTION ui_error(TEXT, JSONB[])                                    SET SCHEMA erp;
ALTER FUNCTION ui_message(TEXT)                                           SET SCHEMA erp;
ALTER FUNCTION ui_confirm(TEXT, VARCHAR, JSONB, TEXT)                     SET SCHEMA erp;
ALTER FUNCTION ui_open_form(VARCHAR, JSONB, TEXT, JSONB, BOOLEAN)         SET SCHEMA erp;
ALTER FUNCTION ui_close_form()                                            SET SCHEMA erp;
ALTER FUNCTION ui_clear_form()                                            SET SCHEMA erp;
ALTER FUNCTION ui_set_values(JSONB, VARCHAR)                              SET SCHEMA erp;
ALTER FUNCTION ui_clear_fields(TEXT[])                                    SET SCHEMA erp;
ALTER FUNCTION ui_set_title(TEXT)                                         SET SCHEMA erp;
ALTER FUNCTION ui_refresh_grid(VARCHAR, BOOLEAN)                          SET SCHEMA erp;

-- Чтение формы и проверки ввода
ALTER FUNCTION ui_text(JSON, TEXT)      SET SCHEMA erp;
ALTER FUNCTION ui_is_new(JSON)          SET SCHEMA erp;
ALTER FUNCTION ui_confirmed(JSON)       SET SCHEMA erp;
ALTER FUNCTION ui_require(BOOLEAN, TEXT) SET SCHEMA erp;
ALTER FUNCTION ui_parse_id(TEXT)        SET SCHEMA erp;
ALTER FUNCTION ui_parse_money(TEXT)     SET SCHEMA erp;
ALTER FUNCTION ui_parse_date(TEXT)      SET SCHEMA erp;
ALTER FUNCTION ui_money_input(NUMERIC)  SET SCHEMA erp;
ALTER FUNCTION ui_format_money(NUMERIC) SET SCHEMA erp;

-- Таблицы: страницы, сортировка, колонки, действия строк
ALTER FUNCTION ui_grid_page(VARCHAR, JSON, REGCLASS, VARCHAR, VARCHAR, VARCHAR) SET SCHEMA erp;
ALTER FUNCTION ui_page_param(JSON, VARCHAR, INT, INT)                           SET SCHEMA erp;
ALTER FUNCTION ui_grid_sort(VARCHAR, JSON, VARCHAR, VARCHAR)                    SET SCHEMA erp;
ALTER FUNCTION ui_grid_columns(VARCHAR)                                         SET SCHEMA erp;
ALTER FUNCTION ui_grid_row_actions(VARCHAR)                                     SET SCHEMA erp;
ALTER FUNCTION ui_action_source(JSON)                                           SET SCHEMA erp;


-- ---------------------------------------------------------------------
-- search_path
-- ---------------------------------------------------------------------
DO $$
BEGIN
    EXECUTE format('ALTER DATABASE %I SET search_path = public, erp', current_database());
END;
$$;

ALTER FUNCTION erp.handle_ui_event(VARCHAR, JSON) SET search_path = public, erp;
