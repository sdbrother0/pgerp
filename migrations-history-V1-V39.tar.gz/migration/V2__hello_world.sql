-- =====================================================================
-- Пример Hello World: поле ввода имени и кнопка "Run".
-- =====================================================================

-- Обработчик кнопки: получает значения полей формы, возвращает инструкцию UI.
CREATE FUNCTION hello_run(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_name VARCHAR := NULLIF(trim(p_data->>'user_name'), '');
BEGIN
    IF v_name IS NULL THEN
        RAISE EXCEPTION 'Введите имя';
    END IF;

    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_object(
            'command', 'show_message',
            'text', 'Привет, ' || v_name));
END;
$$ LANGUAGE plpgsql;

INSERT INTO erp_ui_actions (action_name, function_name, description)
VALUES ('hello_run', 'hello_run', 'Приветствие по имени из поля user_name');

INSERT INTO erp_forms (form_name, title)
VALUES ('hello_world', 'Hello World');

INSERT INTO erp_form_components (form_name, sort_order, component_type, component_name, label, action_event) VALUES
    ('hello_world', 1, 'input',  'user_name', 'Имя', NULL),
    ('hello_world', 2, 'button', 'btn_run',   'Run', 'hello_run');
