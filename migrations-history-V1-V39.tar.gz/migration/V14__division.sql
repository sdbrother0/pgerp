-- =====================================================================
-- Пример "Деление": поля a и b, кнопка "Разделить" записывает a / b
-- в поле только для чтения "result of division".
-- =====================================================================

-- Число из поля ввода: допускается запятая или точка как разделитель дробной части
CREATE FUNCTION division_parse(p_value TEXT, p_field VARCHAR)
RETURNS NUMERIC AS $$
DECLARE
    v_text TEXT := replace(replace(trim(p_value), ' ', ''), ',', '.');
BEGIN
    IF v_text IS NULL OR v_text = '' THEN
        RAISE EXCEPTION 'Введите значение поля %', p_field;
    END IF;
    IF v_text !~ '^[+-]?(\d+\.?\d*|\.\d+)$' THEN
        RAISE EXCEPTION 'Поле %: "%" — не число', p_field, trim(p_value);
    END IF;
    RETURN v_text::NUMERIC;
END;
$$ LANGUAGE plpgsql IMMUTABLE;


CREATE FUNCTION division_run(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_a NUMERIC := division_parse(p_data->>'a', 'a');
    v_b NUMERIC := division_parse(p_data->>'b', 'b');
BEGIN
    IF v_b = 0 THEN
        RETURN json_build_object(
            'status', 'success',
            'ui_instructions', json_build_array(
                json_build_object('command', 'set_values',
                                  'values', json_build_object('result', '')),
                json_build_object('command', 'show_message',
                                  'text', 'Деление на ноль невозможно')));
    END IF;

    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_object(
            'command', 'set_values',
            'values', json_build_object(
                'result', replace(trim_scale(round(v_a / v_b, 10))::TEXT, '.', ','))));
END;
$$ LANGUAGE plpgsql;

INSERT INTO erp_ui_actions (action_name, function_name, description)
VALUES ('division_run', 'division_run', 'Деление a на b, результат в поле result');

INSERT INTO erp_forms (form_name, title)
VALUES ('division', 'Деление');

INSERT INTO erp_form_components (form_name, sort_order, component_type, component_name, label, action_event) VALUES
    ('division', 1, 'input',   'a',          'a',                  NULL),
    ('division', 2, 'input',   'b',          'b',                  NULL),
    ('division', 3, 'display', 'result',     'result of division', NULL),
    ('division', 4, 'button',  'btn_divide', 'Разделить',          'division_run');
