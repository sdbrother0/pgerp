-- =====================================================================
-- Hello World: тексты обработчика — из переводов, явно.
--
-- Шаблон сначала переводится (ui_t), затем в него подставляется значение (format). Так переводчик
-- видит целую фразу «Привет, %s» и может поставить имя в любое место, а не кусок «Привет, »,
-- к которому имя приклеивается в коде. Это образец для обработчиков: ui_t('шаблон') → format(…).
-- Переведённый ответ маршрутизатор больше не меняет: для английского текста перевода нет.
-- =====================================================================

CREATE OR REPLACE FUNCTION hello_run(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_name VARCHAR := ui_text(p_data, 'user_name');
BEGIN
    PERFORM ui_require(v_name IS NOT NULL, ui_t('Введите имя'));

    RETURN ui_ok(ui_message(format(ui_t('Привет, %s'), v_name)));
END;
$$ LANGUAGE plpgsql;

INSERT INTO pgerp.translations (lang, source, translation) VALUES
    ('en', 'Введите имя', 'Enter a name'),
    ('en', 'Привет, %s',  'Hello, %s')
ON CONFLICT (lang, source) DO UPDATE SET translation = EXCLUDED.translation;

-- Кусок «Привет, » больше нигде не используется
DELETE FROM pgerp.translations WHERE source = 'Привет, ';
