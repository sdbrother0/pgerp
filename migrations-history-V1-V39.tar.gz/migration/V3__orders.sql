-- =====================================================================
-- Пример "Заказы": создание заказа и постраничный просмотр списка.
-- Новый тип компонента 'grid' — таблица с данными из действия-источника.
-- =====================================================================

ALTER TABLE erp_form_components DROP CONSTRAINT erp_form_components_component_type_check;
ALTER TABLE erp_form_components ADD CONSTRAINT erp_form_components_component_type_check
    CHECK (component_type IN ('label', 'input', 'button', 'grid'));

-- Колонки таблиц. Привязаны к действию-источнику данных: любая таблица,
-- использующая это действие, получает одинаковый набор колонок.
CREATE TABLE erp_grid_columns (
    action_name   VARCHAR(100) NOT NULL REFERENCES erp_ui_actions ON DELETE CASCADE,
    display_order INT          NOT NULL,
    field_name    VARCHAR(50)  NOT NULL,
    column_title  VARCHAR(100) NOT NULL,
    cell_type     VARCHAR(20)  NOT NULL DEFAULT 'text' CHECK (cell_type IN ('text', 'number', 'money', 'badge')),
    PRIMARY KEY (action_name, field_name)
);

CREATE FUNCTION ui_grid_columns(p_action VARCHAR)
RETURNS JSON AS $$
    SELECT COALESCE(json_agg(json_build_object(
               'field', field_name,
               'title', column_title,
               'type', cell_type)
           ORDER BY display_order), '[]'::json)
    FROM erp_grid_columns
    WHERE action_name = p_action;
$$ LANGUAGE sql STABLE;

-- Параметры пагинации из запроса таблицы: {"page": 1, "limit": 10}
CREATE FUNCTION ui_page_param(p_data JSON, p_key VARCHAR, p_default INT, p_max INT)
RETURNS INT AS $$
    SELECT CASE
               WHEN p_data->>p_key ~ '^\d{1,6}$' THEN LEAST(GREATEST((p_data->>p_key)::INT, 1), p_max)
               ELSE p_default
           END;
$$ LANGUAGE sql IMMUTABLE;


-- Сохранение формы: тот же код, что в V1, плюс тип 'grid'.
CREATE OR REPLACE FUNCTION ui_form_save(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_form_name VARCHAR := p_data->>'name';
    v_title     VARCHAR := NULLIF(trim(p_data->>'title'), '');
    v_comp      RECORD;
BEGIN
    IF v_form_name IS NULL OR v_form_name !~ '^[a-z_][a-z0-9_]*$' THEN
        RAISE EXCEPTION 'Имя формы: латинские буквы в нижнем регистре, цифры и "_"';
    END IF;

    FOR v_comp IN
        SELECT c->>'type' AS type, c->>'name' AS name, NULLIF(c->>'action', '') AS action, n
        FROM json_array_elements(COALESCE(p_data->'components', '[]'::json)) WITH ORDINALITY AS t(c, n)
    LOOP
        IF v_comp.type IS NULL OR v_comp.type NOT IN ('label', 'input', 'button', 'grid') THEN
            RAISE EXCEPTION 'Компонент №%: неизвестный тип "%"', v_comp.n, v_comp.type;
        END IF;
        IF v_comp.name IS NULL OR v_comp.name !~ '^[a-z_][a-z0-9_]*$' THEN
            RAISE EXCEPTION 'Компонент №%: имя — латинские буквы в нижнем регистре, цифры и "_"', v_comp.n;
        END IF;
        IF v_comp.type = 'grid' AND v_comp.action IS NULL THEN
            RAISE EXCEPTION 'Таблица "%": выберите действие-источник данных', v_comp.name;
        END IF;
        IF v_comp.action IS NOT NULL
           AND NOT EXISTS (SELECT 1 FROM erp_ui_actions WHERE action_name = v_comp.action AND NOT is_system) THEN
            RAISE EXCEPTION 'Компонент "%": действие "%" не зарегистрировано', v_comp.name, v_comp.action;
        END IF;
    END LOOP;

    IF (SELECT count(*) <> count(DISTINCT c->>'name')
        FROM json_array_elements(COALESCE(p_data->'components', '[]'::json)) c) THEN
        RAISE EXCEPTION 'Имена компонентов должны быть уникальны';
    END IF;

    INSERT INTO erp_forms (form_name, title)
    VALUES (v_form_name, COALESCE(v_title, v_form_name))
    ON CONFLICT (form_name) DO UPDATE
        SET title = EXCLUDED.title, updated_at = now();

    DELETE FROM erp_form_components WHERE form_name = v_form_name;

    INSERT INTO erp_form_components (form_name, sort_order, component_type, component_name, label, action_event)
    SELECT v_form_name, n, c->>'type', c->>'name', c->>'label', NULLIF(c->>'action', '')
    FROM json_array_elements(COALESCE(p_data->'components', '[]'::json)) WITH ORDINALITY AS t(c, n);

    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_object(
            'command', 'show_message',
            'text', format('Форма "%s" сохранена', v_form_name)));
END;
$$ LANGUAGE plpgsql;


-- ---------------------------------------------------------------------
-- Заказы
-- ---------------------------------------------------------------------
CREATE TABLE erp_orders (
    id            BIGSERIAL     PRIMARY KEY,
    created_at    TIMESTAMPTZ   NOT NULL DEFAULT now(),
    customer_name VARCHAR(200)  NOT NULL,
    product_name  VARCHAR(200)  NOT NULL,
    quantity      INT           NOT NULL CHECK (quantity > 0),
    price         NUMERIC(12,2) NOT NULL CHECK (price >= 0),
    status        VARCHAR(20)   NOT NULL DEFAULT 'NEW' CHECK (status IN ('NEW', 'PAID', 'SHIPPED'))
);


-- Кнопка "Создать заказ": поля формы customer_name, product_name, quantity, price.
CREATE FUNCTION order_create(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_customer VARCHAR := NULLIF(trim(p_data->>'customer_name'), '');
    v_product  VARCHAR := NULLIF(trim(p_data->>'product_name'), '');
    v_quantity VARCHAR := trim(p_data->>'quantity');
    v_price    VARCHAR := replace(replace(trim(p_data->>'price'), ' ', ''), ',', '.');
    v_id       BIGINT;
BEGIN
    IF v_customer IS NULL THEN
        RAISE EXCEPTION 'Укажите клиента';
    END IF;
    IF v_product IS NULL THEN
        RAISE EXCEPTION 'Укажите товар';
    END IF;
    IF v_quantity IS NULL OR v_quantity !~ '^[1-9]\d{0,5}$' THEN
        RAISE EXCEPTION 'Количество — целое число больше нуля';
    END IF;
    IF v_price IS NULL OR v_price !~ '^\d{1,10}(\.\d{1,2})?$' THEN
        RAISE EXCEPTION 'Цена — число, например 1500 или 99,90';
    END IF;

    INSERT INTO erp_orders (customer_name, product_name, quantity, price)
    VALUES (v_customer, v_product, v_quantity::INT, v_price::NUMERIC)
    RETURNING id INTO v_id;

    -- Несколько инструкций UI выполняются по порядку
    RETURN json_build_object(
        'status', 'success',
        'ui_instructions', json_build_array(
            json_build_object('command', 'clear_form'),
            json_build_object('command', 'refresh_grid', 'grid', 'orders_grid'),
            json_build_object('command', 'show_message', 'text', format('Заказ №%s создан', v_id))));
END;
$$ LANGUAGE plpgsql;


-- Источник данных таблицы: страница заказов (LIMIT/OFFSET), новые сверху.
CREATE FUNCTION orders_page(p_data JSON)
RETURNS JSON AS $$
DECLARE
    v_limit       INT := ui_page_param(p_data, 'limit', 10, 100);
    v_page        INT := ui_page_param(p_data, 'page', 1, 1000000);
    v_total_rows  INT;
    v_total_pages INT;
    v_rows        JSON;
BEGIN
    SELECT count(*) INTO v_total_rows FROM erp_orders;

    v_total_pages := GREATEST(CEIL(v_total_rows::NUMERIC / v_limit)::INT, 1);
    v_page := LEAST(v_page, v_total_pages);

    SELECT json_agg(t) INTO v_rows
    FROM (
        SELECT id,
               to_char(created_at, 'DD.MM.YYYY HH24:MI') AS order_date,
               customer_name                            AS customer,
               product_name                             AS product,
               quantity,
               quantity * price                         AS total,
               status
        FROM erp_orders
        ORDER BY id DESC
        LIMIT v_limit
        OFFSET (v_page - 1) * v_limit
    ) t;

    RETURN json_build_object(
        'status', 'success',
        'meta', json_build_object(
            'current_page', v_page,
            'limit', v_limit,
            'total_rows', v_total_rows,
            'total_pages', v_total_pages),
        'columns', ui_grid_columns('orders_page'),
        'rows', COALESCE(v_rows, '[]'::json));
END;
$$ LANGUAGE plpgsql;


INSERT INTO erp_ui_actions (action_name, function_name, description) VALUES
    ('order_create', 'order_create', 'Создание заказа из полей формы'),
    ('orders_page',  'orders_page',  'Таблица: страница списка заказов');

INSERT INTO erp_grid_columns (action_name, display_order, field_name, column_title, cell_type) VALUES
    ('orders_page', 1, 'id',         '№',          'number'),
    ('orders_page', 2, 'order_date', 'Дата',       'text'),
    ('orders_page', 3, 'customer',   'Клиент',     'text'),
    ('orders_page', 4, 'product',    'Товар',      'text'),
    ('orders_page', 5, 'quantity',   'Кол-во',     'number'),
    ('orders_page', 6, 'total',      'Сумма',      'money'),
    ('orders_page', 7, 'status',     'Статус',     'badge');

INSERT INTO erp_forms (form_name, title)
VALUES ('orders', 'Заказы');

INSERT INTO erp_form_components (form_name, sort_order, component_type, component_name, label, action_event) VALUES
    ('orders', 1, 'label',  'lbl_new',       'Новый заказ',     NULL),
    ('orders', 2, 'input',  'customer_name', 'Клиент',          NULL),
    ('orders', 3, 'input',  'product_name',  'Товар',           NULL),
    ('orders', 4, 'input',  'quantity',      'Количество',      NULL),
    ('orders', 5, 'input',  'price',         'Цена',            NULL),
    ('orders', 6, 'button', 'btn_create',    'Создать заказ',   'order_create'),
    ('orders', 7, 'grid',   'orders_grid',   'Список заказов',  'orders_page');

-- Демо-данные, чтобы было что листать
INSERT INTO erp_orders (created_at, customer_name, product_name, quantity, price, status)
SELECT now() - (46 - g) * interval '7 hours',
       (ARRAY['ООО Вектор', 'ИП Иванов', 'АО Север', 'ООО Ромашка', 'ЗАО Техно'])[1 + g % 5],
       (ARRAY['Ноутбук', 'Монитор', 'Принтер', 'Клавиатура', 'Кресло офисное', 'Бумага А4'])[1 + g % 6],
       1 + g % 7,
       (ARRAY[85000, 24000, 18500, 3200, 14900, 450])[1 + g % 6],
       (ARRAY['NEW', 'PAID', 'SHIPPED'])[1 + g % 3]
FROM generate_series(1, 45) AS g;
