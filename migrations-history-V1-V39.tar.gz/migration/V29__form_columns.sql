-- =====================================================================
-- Колонки на форме: options.column у компонента (1, 2, …). Компоненты с одним номером стоят
-- друг под другом, колонки — рядом; первая колонка уже остальных, на узком экране — друг под другом.
-- Раскладка целиком на клиенте; в базе — только параметр компонента.
--
-- "Группы товаров": дерево и кнопки групп — слева, товары группы — справа.
-- =====================================================================

UPDATE pgerp.form_components
SET options = COALESCE(options, '{}'::jsonb) || jsonb_build_object('column', 1)
WHERE form_name = 'product_groups'
  AND component_name IN ('group_tree', 'btn_group_new', 'btn_group_edit', 'btn_group_delete');

UPDATE pgerp.form_components
SET options = COALESCE(options, '{}'::jsonb) || jsonb_build_object('column', 2)
WHERE form_name = 'product_groups'
  AND component_name IN ('btn_product_new', 'products_grid');

UPDATE pgerp.forms SET updated_at = now() WHERE form_name = 'product_groups';
